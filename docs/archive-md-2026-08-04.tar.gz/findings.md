# Findings

## Vorheriger Character-Setup-Schnitt
- Root Roadmap priorisiert Character Setup als Phase 4; H5 legt 18/18, Budget 30, NeutralCenter 25 und Neutralzone [-5,+3] fest.
- `CharacterSetup.FixAge` setzt Alter nachträglich; direkter PawnGenerator-Hook bleibt unbestätigt.
- Character-Pure-Trait-Auswahl und kostenbewusste Skillbudget-Logik wurden bereits implementiert.

## 2026-08-04 Falsifizierungsbefunde
- `CreditsLedger.ApplyTransaction`: `_idempotencyKeys` überlebt `TrimHistory`, aber Replay sucht den originalen TxId noch in `Transactions` (Cap 256). Nach >256 Folgetransaktionen fällt der bereits bekannte Key in die Neuanlage durch.
- `CreditsLedger.PruneIdempotencyKeys`: baut bei >4096 Keys aus maximal 256 retained Transactions neu auf und zerstört damit das behauptete 4096er-Fenster.
- `StoryState.RebuildAfterLoad`: rekonstruiert `_idempotencyInsertionOrder` mit Tick 0; ab Spieltick >1.800.000 entfernt der nächste Alters-Prune alle restaurierten Keys.
- `FoundationSaveData.PipeEscape/PipeUnescape`: globale sequenzielle Replace-Aufrufe sind bei Backslash-/Escape-Sequenzen nicht roundtrip-sicher; zusätzlich wird vor dem Unescape mit `Split('|')` nicht escape-aware geparst.
- Locale-/ActualAmount-Clamping-Fixes wurden im Befund als sauber bewertet und werden nicht unnötig verändert.

## 2026-08-04 Build & Root Cause Befunde
- **Fehler:** CS0246 in `StoryStateRegressionTests.cs` (Kompilierungsfehler bei `InvalidOperationException`).
- **Root Cause:** Die Klasse war im Namespace `Verse` und `Rimconemy.InfectedAutomation.Story` eingebunden, aber das Basis-Namespace `System` fehlte (`using System;`), wodurch `InvalidOperationException` von Roslyn nicht aufgelöst werden konnte.
- **Behebung:** `using System;` hinzugefügt. Build aller 5 Pakete verifiziert (0W/0E).

