# Rimconemy — Tasks (H1–H5 Status)

> **Erstellt:** 2026-08-04 (als `HANDOFF.md`)  
> **Umbenannt:** 2026-08-04 → `docs/tasks.md`  
> **Kanonische Begleitdokumente:** [`AUDIT.md`](../AUDIT.md), [`ROADMAP.md`](../ROADMAP.md)  
> **Aktueller Modus:** Coding-Schnitt §1–§7 abgeschlossen. 9 GESAMTREPORT-Bugfixes erledigt. Siehe [`HANDOFF.md`](../HANDOFF.md) für aktive TODOs.
> 
> **H1–H5 Ergebnisse:** Siehe §5 und `docs/H1-api-def-gate.md` – `docs/H5-character-setup-formula.md`

## 1. Nutzerentscheidung

Die nächste Produktphase ist:

1. **Story Writer** als höchste Priorität,
2. benannte **Schwierigkeitsprofile** und eine dynamische Eventliste,
3. **Setting-Ideologie** als zentrale Verhaltens-/Erfahrungslogik,
4. später Character Setup mit Bio-Remap, festem Skillbudget, Startalter 18 und Trait-Ausgleich,
5. Survivor-Ressourcen ausschließlich aus echten Lager-/Storage-Beständen.

Die Ideologie soll das Setting ersetzen. RimWorlds vorhandene Ideology-Systeme werden technisch genutzt, aber nicht als eigenständige zusätzliche Religion behandelt. Das Ideology-Fenster dient als Setting-/Erfahrungsfenster.

## 2. Was der nächste Agent nicht annehmen darf

- Kein eigener Storyteller ist aktuell geliefert.
- `InfectedRaidWorker` ist kein funktionierender Raid: `CanFireNowSub()` liefert `false`, `TryExecuteWorker()` meldet dennoch Erfolg ohne Spawn.
- `ProgressionGameComponent` ist kein validiertes Output-XP-System; es nutzt Jobdauer-Sampling.
- Das Single-Survivor-Szenario erzwingt aktuell weder Startalter 18 noch feste Skillpunkte noch Trait-Ausgleich.
- Assembly-String-Treffer beweisen keine 1.6-Signaturen oder Runtime-Semantik.
- `WorldObjectComp`, `IdeoDef`, `PawnGenerationRequest` oder `PawnsFinder` sind dadurch keine automatisch nutzbaren Implementierungsanker.
- Credits-/Market-/Outpost-Stubs sind kein Ersatz für einen physischen Storage-Snapshot.
- README- und Roadmap-Aussagen über Storyteller, Mechadroids, Countdown oder Produktionslogik dürfen nicht als Runtime-Beleg verwendet werden.

## 3. Aktueller überprüfter Zustand

### Repository

- 43 Markdown-Dateien
- 46 C#-Dateien
- 28 XML-Dateien
- 0 `*/Patches/*.xml`
- 0 vorhandene Falsifizierungsberichte
- 5 `obj/`-Verzeichnisse
- `_invbuild/` enthält fünf Paketordner plus `foundation/`
- Deploy-Skript liegt unter `mods/scripts/deploy_all_to_local_mods.sh`
- Alle fünf Projekte wurden zuletzt mit Exit 0, 0 Warnungen und 0 Fehlern kompiliert; dies ist nur ein Compile-Beleg.

### Relevante Dateien

| Bereich | Pfad | Wahrheit |
|---|---|---|
| Story-/Incident-Scaffold | `mods/05-Rimconemy-Infected-Automation/Source/Incidents/InfectedRaidWorker.cs` | No-op-Gate; kein echter Spawn |
| Incident-Def | `mods/05-Rimconemy-Infected-Automation/Defs/Incidents/InfectedRaid.xml` | `baseChance=0.0` |
| Story-/Incident-Vertrag | `mods/05-Rimconemy-Infected-Automation/Tests/Spikes/API-INCIDENT-01.md` | `UNVERIFIED`; keine Signaturfreigabe |
| Current Progression | `mods/02-Rimconemy-Survival-Progression/Source/Progression/ProgressionGameComponent.cs` | Runtime-Komponente, 250-Tick-XP-Sampling, fragiler Map-only Game-Over-Pfad |
| Current Scenario | `mods/02-Rimconemy-Survival-Progression/Defs/Scenarios/SingleSurvivor.xml` | 1 Pawn, 8 Kandidaten, Vanilla Storyteller |
| Needs-/Ideology-Spike | `mods/02-Rimconemy-Survival-Progression/Tests/Spikes/API-NEED-01.md` | `UNVERIFIED`; Einflussmatrix noch offen |
| Job-/Skill-Spike | `mods/02-Rimconemy-Survival-Progression/Tests/Spikes/API-JOB-01.md` | `UNVERIFIED`; Output-Hook offen |
| Foundation Def-Inventur | `mods/01-Rimconemy-Foundation/Source/Catalog/FoundationDefInventory.cs` | read-only Def-Zählung, kein Story-/Ideology-Director |
| Economy-Stubs | `mods/04-Rimconemy-Economy-Territory/Source/Wallet/`, `Source/Market/`, `Source/Outposts/` | Datenrecords/Stubs, kein Storage-Vertrag |

## 4. Zielarchitektur der Übergabe

```text
RimWorld Maps/Storages/Pawns/Ideology
             ↓ read-only adapters
SituationSnapshot + StorageSnapshot + IdeologySnapshot
             ↓
SettingProfile + DifficultyRules
             ↓
StoryEventCatalog → deterministic selection → StoryState
             ↓                         ↓
Ideology reactions                 event adapter
             ↓                         ↓
UI/Setting window                 Incident/Letter/choice
```

### Kernobjekte

#### `SettingProfile`

- stabile ID und Version,
- Difficulty-Regeln,
- erlaubte Eventfamilien,
- Ruhe-/Eskalationsfenster,
- Ideologieprofil-ID,
- deterministische Seed-Regel.

#### `SituationSnapshot`

Nur aggregierte, speicher-/testbare Werte:

- Spielzeit,
- Survivor-Anzahl und Zustand,
- Bedrohungs-/Eskalationswert,
- Ideologie-Spannung,
- Forschungs-/Storyfortschritt,
- `StorageSnapshot`.

Keine Pawn-/Thing-/Map-Objektreferenzen im Story-State.

#### `StoryEventSpec`

- ID/Version,
- Eventfamilie,
- Voraussetzungen und Ausschlüsse,
- Gewicht,
- Cooldown,
- Eskalationsstufe,
- Textschlüssel,
- Choice-/Follow-up-IDs,
- deklarierte Effekte,
- DeterminismKey.

#### `StorageSnapshot`

- kanonische Ressource-/ThingDef-ID,
- aggregierte Menge,
- Ort/Map/Storage-Bereich,
- Availability-Status,
- Snapshot-Zeitpunkt,
- optionale Qualitäts-/Verderbsklasse.

Dieser Snapshot ist die einzige Quelle für Survivor-Ressourcen. Keine zweite abstrakte Survivor-Inventarliste erstellen.

#### `IdeologySnapshot`

- aktives Setting-Ideologieprofil,
- Regel-IDs,
- Rollen-/Ritualstatus,
- Spannung/Konformität,
- erklärte Pawn-Reaktionen,
- Adapter-/DLC-Status.

## 5. Erster Arbeitsauftrag: Research/Design, noch kein Runtime-Code

Statuswortschatz für die Übergabe: `PLANNED` = beschlossen, `SCAFFOLD` = Gerüst vorhanden, `UNVERIFIED` = statisch/offen, `IMPLEMENTED` = Code vorhanden ohne Runtime-Gate, `RUNTIME-VERIFIED` = Def-Load, Spielstart und relevanter Verhaltenstest belegt.

### Schritt H1 — API- und Def-Gate ✅

> **Ergebnis:** [`docs/H1-api-def-gate.md`](H1-api-def-gate.md)  
> **Status:** `PLANNED` — Symboltabelle mit 50+ Einträgen, 6 Sektionen (Storyteller, Ideology, Pawn, Storage, Save, Sonstige).  
> 15 Symbole `COMPILES`, 27 `STRING`, 5 `OPEN`.  
> Kritischer offener Spike: `IdeoDef` (in DLC-Assembly, lokal nicht prüfbar).  
> Nächster User-Schritt: `IdeoDef`-Signatur lokal verifizieren; `IncidentWorker_RaidEnemy`-Erbung kompilieren.

### Schritt H2 — Story-Vertrag festschreiben ✅

> **Ergebnis:** [`docs/H2-story-contract.md`](H2-story-contract.md)  
> **Status:** `PLANNED` — Konkrete Zahlen für alle 3 Profile (18 Parameter pro Profil) + 3 MVP-Events (je mit Prerequisites, Weights, Cooldowns, Choices, FollowUps, DeterminismKey).  
> Auswahlalgorithmus als Pseudocode + `StoryState`-Save-Schema definiert.  
> Vanilla-/DLC-Policy: Wealth-Raids nicht deaktivieren, Quest-Incidents nicht unterdrücken.  
> Nächster User-Schritt: Zahlen im Collapse-Profil prüfen; `DeterministicRng`-Implementierung vorbereiten.

### Schritt H3 — Ideology-Einflussmatrix ✅

> **Ergebnis:** [`docs/H3-ideology-influence-matrix.md`](H3-ideology-influence-matrix.md)  
> **Status:** `PLANNED` — 3 Setting-Regeln vollständig spezifiziert:  
> 1. `ResourceFairness` (Ressourcen-Gerechtigkeit) — `PreceptDef` + `ThoughtDef`  
> 2. `CollectiveDefense` (Kollektive Verteidigungspflicht) — `RoleDef` + `ThoughtDef` + `RitualDef`  
> 3. `Transparency` (Wahrheit und Transparenz) — `PreceptDef` + `ThoughtDef`  
> Jede mit Mood/Social/AI-Wirkung, Trigger, UI-Erklärung, Save-Key, Falsifikationsfall.  
> Vanilla-Precept-Policy definiert (Beobachten/Neutralisieren).  
> Nächster User-Schritt: `IdeoDef` lokal prüfen; `ThoughtWorker_ResourceFairness` kompilieren und testen.

### Schritt H4 — Storage-Query-Vertrag ✅

> **Ergebnis:** [`docs/H4-storage-query-contract.md`](H4-storage-query-contract.md)  
> **Status:** `PLANNED` — Vollständige C#-Signatur + Datenstrukturen (`StorageSnapshot`, `StorageEntry`, `StorageScope`, `ResourceFilter`).  
> Implementierungsskizze mit `Map.listerThings.AllThings`-Enumeration, Quality/Rot-Aggregation, ContentHash.  
> 11 Randfälle dokumentiert (unloaded map, caravan, cache, credits, etc.).  
> Konsumenten-Vertrag: Story Writer, UI, Economy lesen; Scavenger besitzt Read.  
> Nächster User-Schritt: `listerThings.AllThings`-Enumeration kompilieren; Hash-Vergleich mit Test-Map.

### H5 — Character Setup-Formel (Teilabnahme)

> **Ergebnis:** [`docs/H5-character-setup-formula.md`](H5-character-setup-formula.md)  
> **Status:** `PARTIALLY IMPLEMENTED` — SkillBudget 30, NeutralCenter 25, Neutralzone [-5, +3], kostenbewusste UI-/Runtime-Allocation und deterministische Pure-Trait-Auswahl sind implementiert. Startalter-Generator-Hook, CharacterSetupState, Save/Load- und Runtime-Gates bleiben offen.  
> Progressive Kostenfunktion ab Stufe 10, 12 Skills und Trait-Zonen sind umgesetzt; vollständige Trait-Pools/Ausschlüsse und DLC-Laufzeitbeleg bleiben offen.  
> Bio-Remap-Ablauf: Bio-Text generieren → Skills resetten → Spieler verteilt → Trait-Berechnung bleibt Phase A-2.  
> Pure-Reproduzierbarkeits-Gates für gleiche Seeds, Seed-Variation, Grenzen und Pool-Randfälle sind vorhanden.  
> Nächster User-Schritt: `API-START-01` konkret verifizieren; danach `CharacterSetupState` und Save/Load testen.

## 6. Coding-Schnitt — Fortschritt

> **Status:** §1–§7 erledigt ✅ | 9 Bugfixes erledigt ✅

### §1 — Pure Datenmodelle und Auswahlfunktion ✅

> **Ergebnis:** 7 Dateien in `mods/05-Rimconemy-Infected-Automation/Source/Story/`:
> - `SettingProfile.cs` — 18 Parameter, 3 Built-in-Profile (Refuge, Survival, Collapse)
> - `StoryEventSpec.cs` — Event-Spec + `EventCondition` + `EventChoice` Helpers
> - `SituationSnapshot.cs` — Aggregierter Lage-Snapshot (keine Game-Objekte)
> - `StoryState.cs` — Save-/Schema-Modell, Cooldowns, Idempotency-Keys
> - `DeterministicRng.cs` — Splitmix64-PRNG + FNV-1a-Hash (pure Funktionen)
> - `StoryEventCatalog.cs` — Hardcodierte 3 MVP-Events
> - `StorySelector.cs` — Pure deterministische Auswahlfunktion mit Idempotency-Check
>
> Build: **0 Warnungen, 0 Fehler.** Code-Review: 2 Bugs gefunden und behoben.

### §2 — Save-/Schema-Modell mit Scribe-Anbindung ✅

> `StoryState` implementiert `IExposable` + `ExposeData()` (13 Felder, Dict/HashSet via parallele Listen, Schema-Migration, Pruning). Build 0W/0E.

### §3 — Drei Event-Defs als XML ✅

> 3 `StoryEventDef`-XMLs in `Defs/StoryEvents/` (SupplyShortage, IdeologyConflict, ExternalThreat) + TEMPLATE + README.

### §4 — Read-only StorageSnapshot-Adapter ✅

> 3 Dateien in `mods/03/.../Source/Storage/`: `StorageSnapshot.cs`, `StorageScope.cs`, `StorageQuery.cs`. `listerThings.AllThings` kompiliert ✅. Build 0W/0E.

### §5 — Ideology-Adapter für eine Regel ✅

> `ThoughtWorker_ResourceFairness.cs` + 2 ThoughtDef-XMLs (Fair/Unfair Distribution). Build 0W/0E.

### §6 — Test-/Diagnostics-Ausgabe ✅

> `StorySelectorTests.cs` mit 12 Tests (Determinismus, Idempotenz, Profile, RNG, Edge-Cases). `RunAll()` via Bootstrap. Build 0W/0E.

### §7 — Incident-/Storyteller-Ausführung ✅

> `StoryDirector` GameComponent in `mods/05/.../Source/Story/StoryDirector.cs`:
> 250-Tick-Intervall, baut `SituationSnapshot`, ruft `StorySelector`, managed Event-Queue.
> `InfectedRaidWorker` rewritten: `CanFireNowSub`→`StoryDirector.HasPendingEvent()`,
> `TryExecuteWorker`→`Find.LetterStack.ReceiveLetter()` mit Event-Daten. Build 0W/0E.

### Bugfixes (GESAMTREPORT F1–E3) ✅

> 9 von 9 Findings behoben:
> - **F1:** `TerritoryNode.cs` Tick-Kommentar (30.000 = 0,5 Tage)
> - **B1:** `InfectedRaidWorker` Erfolgs-Lüge entfernt (rewritten)
> - **F6:** `GameOverDetector` nutzt `PawnsFinder.AllMapsCaravansAndTravellingTransportPods`
> - **F2:** Tick-XP dokumentiert, `ClassifyJob` Def-basiert
> - **C2:** `FoundationServiceBus` Thread-Maschinerie dokumentiert
> - **C3:** `FoundationSaveData` Base64→Scribe-Notation
> - **C4:** `EventLog` catch(ArgumentException/InvalidOperationException)
> - **E2:** `_invbuild/` gelöscht
> - **E3:** `.gitignore` für `obj/` angelegt

Alle 5 Pakete: Build 0W/0E.

Kein direkter Eingriff in `ProgressionGameComponent` oder Vanilla-Storyteller, bevor die Vertrags- und API-Gates erfüllt sind.

## 7. Prüfungen und Exit-Gates

### Gate G1 — Struktur

- Root-Dokumente auffindbar,
- keine toten Pflichtreferenzen ohne `OPEN/MISSING`-Kennzeichnung,
- README/Blueprint/Code stimmen über `IMPLEMENTED`, `SCAFFOLD`, `PLANNED`, `UNVERIFIED` überein,
- fehlende `../INTERFACE_CONTRACT.md`, `../SAVE_CONTRACT.md` und ähnliche Dateien werden nicht als vorhanden behandelt.

### Gate G2 — Determinismus

- gleicher Snapshot + Profil + Seed → gleicher Eventkandidat und Auswahlgrund,
- keine Doppelauflösung nach Save/Load,
- stabile Sortierung und gespeicherte IDs.

### Gate G3 — Ideology

- mindestens drei Regeln mit nachgewiesener Wirkung,
- UI zeigt Grund und Folge,
- Vanilla-/DLC-Interaktionen klassifiziert.

### Gate G4 — Storage

- Story, UI und Economy lesen dieselbe Storage-Quelle,
- kein zweites Ressourcen-Ledger,
- Bestand bleibt nach Kartenwechsel/Save-Load konsistent.

### Gate G5 — Character

- Startalter 18 reproduzierbar,
- Skillbudget wird exakt eingehalten,
- Neutralzone erzeugt keinen Trait-Bonus/-Malus,
- Unter-/Überbudget erzeugt nur erlaubte Traits,
- gleiche Eingabe erzeugt gleiches Ergebnis.

### Gate G6 — Runtime

Erst mit Spielstart-, Def-Load-, Save-/Load- und UI-Belegen gilt ein Gameplay-Gate als bestanden. Kompilierung und Assembly-String-Scan reichen nicht.

## 8. Nicht Teil dieses Handoffs

- keine Codeänderung,
- kein vollständiger Infected-Raid,
- kein Mechadroid-Arbeitsystem,
- kein Outpost-/Wallet-Produktionssystem,
- kein Bauschutt-Patch,
- kein Game-Over-Fix,
- keine globale Vanilla-Raid-Deaktivierung,
- kein LLM-/Cloud-Story-System im Spielkern,
- keine Aussage, dass die vorgeschlagenen RimWorld-1.6-Signaturen bereits runtime-verifiziert sind.

## 9. Übergabeentscheidung

**Nächster Schritt:** Coding-Schnitt §7 (Incident-/Storyteller-Ausführung). Die direkte Vanilla-Storyteller-Integration bleibt bis dahin eine Option, nicht eine Vorbedingung und nicht ein behaupteter API-Fakt.
