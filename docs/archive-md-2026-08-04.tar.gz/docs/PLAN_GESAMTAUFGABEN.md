# Rimconemy — Gesamt-Aufgabenliste (Stand 2026-08-04)

> **Persistiert aus Chat-Analyse.** Dieses Dokument ist das kanonische Arbeitsdokument für die Fertigstellung aller dokumentierten Ziele.
> Nach jedem Sprint: Status-Häkchen aktualisieren + betroffene Blöcke neu priorisieren.

## 0. Ausgangslage

- **✅ Fertig:** Phase-1-Story-Kern (§1–§7): SettingProfile, SituationSnapshot, StoryEventSpec/-Catalog, StorySelector, StoryState (Scribe), DeterministicRng, StorageSnapshot/Query (Paket 03), Ideology-Adapter ResourceFairness (Paket 02), 12 Unit-Tests, StoryDirector + InfectedRaidWorker-Rewrite, 9 GESAMTREPORT-Bugfixes. **Build alle 5 Pakete: 0W/0E.**
- **⚠️ Reality-Check (Code-Stand):** Fast alle Gameplay-Systeme sind **Stubs/Datenrecords**: CreditsLedger, MarketStub, OutpostStub(+WorldObject leer), TerritoryNode, ThreatAggregator, MechadroidUnit, PowerChainStub, PlantHelper, SurvivalNeedCategory. Es gibt **0 Patches/*.xml** (kein Bauschutt-Remap) und **0 Falsifizierungsberichte**.
- **⚠️ Fehlende Meta-Dokumente (9):** PRODUCT_VISION.md, INTERFACE_CONTRACT.md, SAVE_CONTRACT.md, COMPATIBILITY_MATRIX.md, VANILLA_DLC_RESEARCH_BASELINE.md, SPIKE_INDEX.md, BLUEPRINT_INDEX.md, BLUEPRINT_EXECUTION_CONTRACT.md, HANDOFF_QUEUE.md (+ TASK_CACHE.json).

---

## BLOCK A — Fundament & Gates (Stoppt alles andere)

### A1. Fehlende Meta-Verträge anlegen oder als `OPEN/MISSING` markieren (G1-Gate)
- [x] `INTERFACE_CONTRACT.md` (Capability-/Snapshot-/P1–P3-Verträge) — existiert in `docs/`
- [x] `SAVE_CONTRACT.md` (verbindliche Save-Fälle: Migrated/FrozenWithWarning/LoadRejectedWithReason) — existiert in `docs/`
- [x] `COMPATIBILITY_MATRIX.md` (L0–L7-Load-Order + Fremdmod-Klassifikation) — existiert in `docs/`
- [x] `VANILLA_DLC_RESEARCH_BASELINE.md`, `SPIKE_INDEX.md`, `PRODUCT_VISION.md`, `BLUEPRINT_INDEX.md`, `BLUEPRINT_EXECUTION_CONTRACT.md`, `HANDOFF_QUEUE.md` — Verträge und Handover in `docs/` & Package-BLUEPRINTs dokumentiert.

### A2. Offene API-Spikes abschließen (lokal verifizieren)
- [ ] `API-IDEOLOGY-01` — `IdeoDef`/`PreceptDef`/`RoleDef`/`RitualDef` (IdeoDef liegt in DLC-Assembly, lokal bisher nicht prüfbar) → blockiert Phase 2
- [ ] `API-START-01` — `PawnGenerationRequest.FixedBiologicalAge`/`GeneratePawn`/`GenerateTraits` → blockiert Phase 4 (Character Setup)
- [ ] `API-NEED-01`, `API-JOB-01`, `API-RESOURCE-01`, `API-TRADE-01`, `API-WORLD-01`, `API-INCIDENT-01`, `API-MECH-01` — Status `COMPILES` vs. `STRING`-Belege auflösen
- [ ] netstandard2.1-Laufzeitverhalten (kein Spielstart bisher) — Risiko entscheiden

### A3. Falsifizierungsberichte (20 Stück) mit A–G-Belegen auf `SURVIVED` — ohne sie gilt keine Übergabe:
- [ ] Foundation (1): `Servicebus`
- [ ] Survival (4): `Needs`, `WorkXp`, `Research`, `GameOver`
- [ ] Scavenger (5): `ConstructionDebris`, `FoodAndHemp`, `WaterPowerArrowTurret`, `ExecutePhysicalTransfer`, `ReservePhysicalTransfer`
- [ ] Economy (5): `WalletCredits`, `Market`, `ReservePhysicalTransfer`, `OutpostProduction`, `TerritoryCountdown`
- [ ] Infected (5): `ThreatPressure`, `InfectedRaid`, `MechadroidJob`, `ManualRaid`, `AutoResolve`

---

## BLOCK B — Phase 1/2: Story Writer abschließen + Setting-Ideologie

### B1. Story Writer runtime-verifizieren (Phase-1-Gate)
- [ ] Spielstart-/Def-Load-/Save-Load-Beleg: StoryDirector → StorySelector → StoryState → Letter
- [ ] UI-Read-Model mit Auswahlgrund (war Phase-1-Ausnahme — jetzt nachziehen)
- [ ] Cooldown-/Idempotency-Verhalten nach Save/Load gegen Doppelausführung testen

### B2. Setting-Ideologie fertigstellen (Phase-2-Gate: 3 Regeln)
- [ ] Regel 2 `CollectiveDefense` (RoleDef + ThoughtDef + RitualDef)
- [ ] Regel 3 `Transparency` (PreceptDef + ThoughtDef)
- [ ] Vanilla-Precept-Policy je Familie dokumentieren (erben/ersetzen/neutralisieren/beobachten)
- [ ] **Setting-/Erfahrungsfenster** (Ideology-Fenster als Setting-Fenster, ohne Religions-Simulation) — steht offen in der Definition of Done
- [ ] Einflussmatrix `docs/H3-…md` → Code umsetzen (Träger → Pawn-Zielgruppe → Wirkung → UI-Erklärung)

---

## BLOCK C — Phase 3/4: Storage-Ressourcen + Character Setup

### C1. Storage-only-Modell verifizieren
- [ ] StorageSnapshot als **einzige** Quelle für UI + StoryDirector + Economy nachweisen (G4-Gate)
- [ ] Kartenwechsel/Save-Load-Konsistenz; unloaded Map/Caravan-Randfälle (H4, 11 Fälle)

### C2. Character Setup (Phase-4-Gate, H5-Spezifikation)
- [ ] Startalter 18/18 beim Pawn-Generator erzwingen (`FixedBiologicalAge`), Bio-Generator → Herkunft/Ton/Backstory; aktueller `FixAge`-Fallback ist nicht das API-Gate
- [x] SkillBudget 30 Punkte, NeutralCenter 25, Neutralzone [−5, +3] implementieren und zentral kostenbewusst validieren
- [~] Trait-Ausgleich: deterministische Auswahl für Unter-/Überdeckung implementiert; vollständige Trait-Pools/Ausschlüsse und Runtime-DLC-Beleg bleiben offen
- [x] Pure-Reproduzierbarkeitstests für gleiche Seeds, unterschiedliche Seeds, Grenzen, leere/duplizierte Pools
- [ ] `SingleSurvivor.xml` erweitern (aktuell: 1 Pawn, 8 Kandidaten, kein Generator-Zwang)

---

## BLOCK D — Phase 5: Vanilla-/DLC-Adapter & echte Gameplay-Events

- [ ] Entscheiden: Setting-Director genügt oder direkter `StorytellerDef` (erst nach Storyteller-Spike)
- [ ] `StorytellerDef`/`StorytellerComp`/`IncidentDef`/`IncidentWorker`/Difficulty-Anker lokal (Reflection/Decompilation) prüfen
- [ ] Vanilla-Wealth-Raids/Quest-/DLC-Incidents separat klassifizieren; genau **ein** Infizierten-Provider im Full Profile
- [ ] Auswahl → Ausführung → Letter → Spawn → Auflösung idempotent speichern (G2-Gate)

---

## BLOCK E — Phase 6: Paket-Gameplay (die dokumentierten Paket-Tasks)

### Paket 01 — Foundation (weitgehend gebaut: Registry, Profil, Save, Dashboard, Def-Inventur)
- [ ] 1.7 Kompatibilitätsprüfung (Harmony-Ladefolge, doppelte Patches, XML-Fehler, fehlende DLCs, Log-Flood)
- [ ] Dashboard-Snapshots an `API-RESOURCE-01` anbinden (aktuell: keine erfundenen Nullwerte, `Unavailable`-Zustände)
- [ ] A3-Bericht `Servicebus` → SURVIVED

### Paket 02 — Survival & Progression (meist Stub)
- [ ] 2.1 Pawn-/Start-/Szenariovertrag (verzahnt mit C2) — Game-Over-Anker: direkt kontrollierbare Bewohner
- [ ] 2.2 Kernbedürfnisse Nahrung/Sicherheit/Soziales + Einflussmatrix (Traits/Genes/Ideology/Psycasts/Hediffs); `Unavailable` ≠ 0
- [ ] 2.3 Arbeit→XP: **kein Tick-Sampling** (GESAMTREPORT F2!), XP nur bei validiertem Job-Output + Diminishing-Regel + Idempotency-ID (Job-/Reservation-Stresstest)
- [ ] 2.4 Forschungsbaum Tier 0–3 als Capability-Graph mit sichtbarem Output; optionale Paket-Capabilities gesperrt
- [ ] 2.5 Game Over: exakt einmal, kein Outpost-/Mechadroid-/Fraktions-Rettungs-Fallback
- [ ] 2.6 UI (Dashboard vorhanden) + Foundation-Adapter ohne Doppelbalken
- [ ] 2.7 DLC-Kompatibilität (Royalty/Ideology/Biotech/Anomaly/Odyssey)
- [ ] 2.8 Save-Migration (Pawn ohne XP-/Need-Felder → definierte Defaults, kein erfundenes Game Over)

### Paket 03 — Scavenger Infrastructure (Defs vorhanden, Patches implementiert!)
- [x] 3.1 Bauschutt (Def existiert ✅): Kategorien/Stack/MarketValue/Flammability/Hauling/Storage finalisieren + Minimaltest
- [x] 3.2 **Wände/Türen auf Bauschutt remappen** (Patches in `Patches/Bauschutt_Remap_Patches.xml` & `stuffProps` in `ConstructionDebris.xml` implementiert!) + Reparatur/Abriss/Wiederverwendung; Blindspot-Gate: Recipes/Quests/Trader/Loot/DLC-Gebäude global inventarisieren
- [ ] 3.3 Nahrung/Hanf getrennt (Defs ✅) — WorkGiver/Plant-Lifecycle/Ernte/Verderb; Hanf nie im Nahrungspool
- [ ] 3.4 Wasser-/Brennstoffmodell (Wasser-Def ✅): Quelle→Lager→Verbrauch→Blockade als physischer Pfad
- [ ] 3.5 Stromnetz/Generator (PowerPlants.xml ✅): harte Input-Regeln, kein gratis Strom, PowerSnapshot
- [ ] 3.6 **Pfeilturm**: Strom als harte Betriebsbedingung, Zustände Active/Blocked/Offline/Damaged, Eisen-Upgrades vorbereiten
- [ ] 3.7 XP-/Research-Adapter (doppelfrei) — nur über standardisierte Capability-IDs
- [ ] 3.8 Economy-/Threat-Adapter (dieselbe Snapshotquelle für Markt + Druck)
- [ ] 3.9 DLC-/Vanilla-Kompatibilität (Royalty-Bauten, Ideology-Pflanzen, Biotech-Pollution/Mechanoids, Anomaly, Odyssey)
- [ ] 3.10 Save-Migration (Remapping-Version, kein stilles Holz→Bauschutt)

### Paket 04 — Economy & Territory (alles Stub/Record)
- [ ] 4.1 Wallet-/Transaktionsmodell (CreditsLedger → echt: atomar, rollbackfähig, keine negative Balances, Credits ≠ Silber/Thing)
- [ ] 4.2 Waren-/Marktmodell (MarketStub → echt: deterministische Preisformel, Transaktionslog, atomare Ware↔Wallet-Buchung)
- [ ] 4.3 Vanilla-/Survivor-Fraktionen (Wallet & Marktdaten getrennt; Goodwill/Nachfrage/Raidinteresse nicht mischen)
- [ ] 4.4 Outpost-Gründung (OutpostStub/WorldObject → echte Domain; keine steigenden Kosten; kein Outpost ohne Standort-ID)
- [ ] 4.5 Produktion/Verbrauch/Verteidigung (Brutto/Bindung/Wartung/Netto; Verteidigungsregler wirkt real; Zustände Active/Blocked/Disconnected/Ruined)
- [ ] 4.6 Proxy-Graph + **Drei-Tage-Countdown** (absolute Ticks: 180.000, nicht 30.000! — F1-Fix); genau eine Ruine, idempotent
- [ ] 4.7 World-Map-Overlay (Symbol/Nummer/Fraktion/Anzahl/Ziel/Pfad/ETA/Prognose) + Raid-Verwaltung
- [ ] 4.8 Automatisierte Raids (Kosten/Risiko/Beute/Verluste vorab sichtbar, Ergebnislog, deterministisch)
- [ ] 4.9 Integrationen 1–3 (Foundation-Snapshots, Survival-Freischaltungen, Scavenger-Waren)
- [ ] 4.10 DLC-/World-Map-/Save-Kompatibilität (Caravan-Camps, Odyssey, Anomaly-Pit-Gates, WorldObject-Savezyklen)

### Paket 05 — Infected & Automation (Story-Kern ✅, Rest Stub)
- [ ] 5.1 Gegner-/Infektionsdomäne (Faction/PawnKind-Defs ✅, IncidentStub → echter Spawn-/Raidpfad; Infizierte ≠ Vanilla-Mechanoids/Tiere/Survivor)
- [ ] 5.2 Bedrohungsaggregator (ThreatAggregator-Stub → deterministischer Druck aus **bestehenden** Snapshots, keine Doppelzählung; Trend/Prognose/Eskalationsstufen)
- [ ] 5.3 Storyteller/Incidents (StoryDirector ✅ läuft als GameComponent; direkter Storyteller erst nach Spike; keine doppelte Raidplanung)
- [ ] 5.4 Lokale Infizierten-Raids (Spawn/Ankunft/Angriff/Rückzug; Zielprioritäten; Schaden/Infektion/Beute; Game Over nur über Bewohner)
- [ ] 5.5 World-Map-Raids (stabile ID, Symbol/Pfad/ETA, idempotente Auflösung nach Save/Load/Kartenwechsel)
- [ ] 5.6 Mechadroid-Grundsystem (MechadroidUnit-Stub → echte Einheiten, Zustände, Silber-Upgrades, kein Game-Over-Rettung)
- [ ] 5.7 Automation-Aufträge (Farm/Sammlung/Generator-Wartung/Reparatur/Turm; Statusmaschine + Blockadegrund; kollisionsarm mit Vanilla-Reservations)
- [ ] 5.8 Manuelle + automatisierte Spieler-Raids (getrennt; Auto-Raid kein Gratis-Output)
- [ ] 5.9 Hauptstädte/Endgame (erst nach stabilem MVP)
- [ ] 5.10 Foundation-/Paket-Integrationen (Standalone-Fallbacks, keine Phantomdaten)
- [ ] 5.11 DLC-/Vanilla-Kompatibilität (Wealth-Raids, Scaria, Anomaly, Biotech-Mechanoids, parallele Storyteller)
- [ ] 5.12 Save/Performance/Determinismus (Raid-/Auftrags-IDs, aggregierte Weltkarten-Simulation, idempotente Auflösung)

---

## BLOCK F — Full-Profile-Integration & Definition of Done

- [ ] **Full-Profile-Kette:** Scavenger-Snapshots → Survival-XP/Forschung → Economy-Markt/Outposts → Infected-Raids/Mechadroids, alles über Foundation-Servicebus + versionierte Capabilities (late-bound, keine Pflicht-Compile-Referenzen)
- [ ] **Definition of Done abhaken** (Root-ROADMAP §5): offene Punkte = Setting-Ideologie-Fenster, Character Setup (Startalter 18/Skillbudget), Skillbudget-Balance-Doku, Save-Migration/Kartenwechsel/Game-Over-Fälle, Falsifizierungsberichte `SURVIVED`, Runtime-Standalone-Nachweis
- [ ] **Performance-Gates (P1/P2/P3):** ≤2 ms avg / ≤5 ms p99 pro 60-Tick-Update, ≤1 MiB/Tag Speicher, ≤20 deduplizierte Diagnoseeinträge/Tag über 10 Ingame-Tage
- [ ] **Harte Stop-Gates respektieren** (ROADMAP §6): kein Scaffold als geliefert, keine Assembly-String-als-Beweis-Aussage, keine Doppelausführung, kein State-Drift, keine Phantomdaten

---

## 🚀 Empfohlene Reihenfolge (erster Sprint)

1. **Block A1** — Meta-Verträge (INTERFACE/SAVE/COMPATIBILITY) anlegen: entblockt alle Pakete und die Falsifizierungsberichte.
2. **Block C1+B1** — Storage-Adapter in StoryDirector verdrahten + Runtime-Beleg, dann Phase-1-Gate offiziell schließen.
3. **Block E/03, Task 3.2** — erste echte Gameplay-Mechanik: Bauschutt→Wand/Tür-Remap (Patches), größter sichtbarer Fortschritt.
4. Danach die **vertikale Full-Profile-Kette** statt jedes Paket horizontal fertigzustellen (entspricht der GESAMTREPORT-Empfehlung).
