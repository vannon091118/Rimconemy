# Vorgehen: H1–H5 Research/Design + Coding-Cut Sprint

> **Erstellt:** 2026-08-04
> **Zweck:** Dokumentiert den Prozess, mit dem H1–H5 und der Coding-Cut §1 abgearbeitet wurden.

## Ablauf

### 1. Ausgangslage

Das ursprüngliche `HANDOFF.md` (heute `docs/tasks.md`) definierte 5 Research/Design-Schritte (H1–H5) als Voraussetzung für jeglichen Code. Keiner war bearbeitet.

### 2. Sprint 1 — H1–H5 Research/Design

**Reihenfolge:** H1 → H2 → H3 → H4 → H5 (sequenziell, aber ohne echte Abhängigkeit)

**Schreibweise:** Jedes H-Dokument ist eine reine Spezifikation. Kein Code wurde geschrieben oder verändert. Der Status ist durchgängig `PLANNED`.

#### Ergebnisse Sprint 1

| Schritt | Dokument | Inhalt | Status |
|---|---|---|---|
| H1 | `docs/H1-api-def-gate.md` | 50+ API-Symbole in 6 Sektionen; Status `COMPILES`/`STRING`/`OPEN` | `PLANNED` |
| H2 | `docs/H2-story-contract.md` | 3 Profile mit 18 Parametern; 3 Events mit Gewichten/Cooldowns/Choices/Folgeevents | `PLANNED` |
| H3 | `docs/H3-ideology-influence-matrix.md` | 3 Setting-Regeln mit voller Träger/Wirkung/Trigger/UI-Matrix | `PLANNED` |
| H4 | `docs/H4-storage-query-contract.md` | C#-Signatur + Datenstrukturen + Implementierungsskizze; 11 Randfälle | `PLANNED` |
| H5 | `docs/H5-character-setup-formula.md` | Startalter 18, SkillBudget 30, Neutralzone [-5,+3], 8 pos./6 neg. Traits | `PLANNED` |

#### Dateiänderungen Sprint 1

| Datei | Aktion |
|---|---|
| `docs/H1-api-def-gate.md` | Neu erstellt |
| `docs/H2-story-contract.md` | Neu erstellt |
| `docs/H3-ideology-influence-matrix.md` | Neu erstellt |
| `docs/H4-storage-query-contract.md` | Neu erstellt |
| `docs/H5-character-setup-formula.md` | Neu erstellt |
| `HANDOFF.md` | Verschoben nach `docs/tasks.md`; H1-H5-Status aktualisiert |
| `AUDIT.md` | Aktualisiert — Referenzen auf `docs/tasks.md`; H1-H5-Hinweis ergänzt |
| `ROADMAP.md` | Aktualisiert — `HANDOFF.md` → `docs/tasks.md` |
| `docs/VORGEHEN-H1-H5.md` | Neu erstellt |

### 3. Sprint 2 — Coding-Cut §1 (Story-Datenmodelle + Auswahlfunktion)

**Auftrag:** tasks.md §6 Item 1: pure Datenmodelle und Auswahlfunktion.

**Besitzer:** Paket 05 (Infected & Automation) als Story-Domäne.

**Methode:** 7 Dateien in `mods/05-Rimconemy-Infected-Automation/Source/Story/` implementiert. Spezifikation aus `docs/H2-story-contract.md` direkt in C#-Code umgesetzt. Keine RimWorld-Abhängigkeiten — pure Datenklassen + Algorithmen.

#### Ergebnisse Sprint 2

| Datei | Inhalt |
|---|---|
| `SettingProfile.cs` | 18 Parameter, 3 Built-in-Profile (Refuge, Survival, Collapse), `GetBuiltIn()` |
| `StoryEventSpec.cs` | Event-Spezifikation + `EventCondition` (Factory-Methoden) + `EventChoice` |
| `SituationSnapshot.cs` | Aggregierter Lage-Snapshot (Survivor/Threat/Ideology/Storage/Progress), `HasActiveEventOfFamily()` |
| `StoryState.cs` | Save-/Schema-Modell, Cooldowns, Idempotency-Keys, `PruneExpiredCooldowns()` |
| `DeterministicRng.cs` | Splitmix64-PRNG + FNV-1a-Hash, `BuildSeed()` mit Template-Resolution |
| `StoryEventCatalog.cs` | Hardcodierte 3 MVP-Events (SupplyShortage, IdeologyConflict, ExternalThreat) |
| `StorySelector.cs` | Pure Auswahlfunktion mit 8-Schritt-Algorithmus, Idempotency-Check, `SelectionResult` |

**Build:** 0 Warnungen, 0 Fehler (2 Builds: initial + nach Review-Fixes).

**Code-Review:** 2 Bugs gefunden und behoben:
1. `HasActiveEventOfFamily(null)` → Auf `ActiveEventFamilies`-Liste umgestellt
2. `NextInt()` Rejection-Sampling-Formel → Korrigiert auf Standard-Threshold-Pattern

#### Dateiänderungen Sprint 2

| Datei | Aktion |
|---|---|
| `mods/05-Rimconemy-Infected-Automation/Source/Story/SettingProfile.cs` | Neu erstellt |
| `mods/05-Rimconemy-Infected-Automation/Source/Story/StoryEventSpec.cs` | Neu erstellt |
| `mods/05-Rimconemy-Infected-Automation/Source/Story/SituationSnapshot.cs` | Neu erstellt |
| `mods/05-Rimconemy-Infected-Automation/Source/Story/StoryState.cs` | Neu erstellt |
| `mods/05-Rimconemy-Infected-Automation/Source/Story/DeterministicRng.cs` | Neu erstellt |
| `mods/05-Rimconemy-Infected-Automation/Source/Story/StoryEventCatalog.cs` | Neu erstellt |
| `mods/05-Rimconemy-Infected-Automation/Source/Story/StorySelector.cs` | Neu erstellt |
| `AUDIT.md` | Aktualisiert — Coding-Cut-Status, Dateizählung |
| `ROADMAP.md` | Aktualisiert — Phase-1-Status |
| `docs/tasks.md` | Aktualisiert — §6 Fortschritts-Status |
| `docs/VORGEHEN-H1-H5.md` | Aktualisiert — Sprint 2 dokumentiert |

### 4. Sprint-Archivierung

Root `HANDOFF.md` wurde als TODO-Liste für den nächsten Sprint neu erstellt. Sprint-Protokoll archiviert als `docs/handoff-2026-08-04-story-models.md`.

### 5. Nächste Schritte

Offen aus tasks.md §6: §2 (Save/Scribe), §3 (Event-XML-Defs), §4 (Storage-Adapter), §5 (Ideology-Adapter), §6 (Tests), §7 (Ausführung).
