# UI Foundation Toolkit + Character-Härtung Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Build the Rimconemy UI toolkit (Phase 0-A) in Mod 01 and the Character-Setup hardening (Phase A-1) in Mod 02 to enable visual consistency across 5 packages and enforce H5-spec skill-budget / trait-polarity semantics.

**Architecture:** Tokens (`RimconemyTheme.cs`) + base classes (`RimconemyWindow`, `RimconemyMainTabWindow`, `RimconemyInspectTab`) + static helpers (`RimconemyUi`) live in Mod 01. Feature packages (02–05) reference the binary DLL; Track A-Phase-2+ later delivers BioOverride/SaveState on top. SkillBudgetCalculator lives in Mod 02 (fachspezifisch). TraitAssigner rewrite uses `SkillBudgetCalculator.Classify(int)` to gate trait polarity per H5-§3.

**Tech Stack:** C# (.NET Standard 2.1), Verse, RimWorld 1.6 surface, UnityEngine.GUI primitives; build via `dotnet build` with `RimWorldManagedPath` + `HarmonyAssembliesPath` set.

**Spec:** [`docs/superpowers/specs/2026-08-04-ui-foundation-toolkit-design.md`](../specs/2026-08-04-ui-foundation-toolkit-design.md)

## Global Constraints

- Build must compile with **0 warnings, 0 errors** per package.
- All five packages must build cleanly after each task (not just the touched one).
- Token values are **frozen at the spec values** (§4.1 in the spec) — do not copy magic numbers from existing code.
- Color names are **semantic only** (`Success`/`Warn`/`Error`/`Info`/`Muted`) — never use `Color.green`/`Color.red` directly in this sprint.
- Each task ends with a single git commit with message `Phase0-A/N: <reason>` or `PhaseA-1/N: <reason>`.
- Skills tagged `Stat-Only` accept `Verse.Log.Message` in lieu of unit tests; gated by `dotnet build` exit 0.
- We **do not** modify Mod 03/04/05 in this sprint — they are downstream consumers of Phase 0-A token/library in future sprints.
- We **do not** apply Harmony patches in this sprint — `RimThemes`-Bridge is detection-only via reflection.
- A task implementer reads only their own task and the spec — interface block tells them what neighboring tasks produce.

---

## Phase 0-A — UI Foundation Toolkit (Mod 01)

### Task 1: RimconemyTheme.cs — Token-Konstanten + Farben

**Files:**
- Create: `mods/01-Rimconemy-Foundation/Source/UI/RimconemyTheme.cs`

**Interfaces:**
- Consumes: §4.1 spec constants verbatim
- Produces: `RimconemyTheme.SectionSpacing`, `RimconemyTheme.RowHeight`, `RimconemyTheme.Success`, … (consumed by Tasks 2/3/5/6/11)

```csharp
using UnityEngine;

namespace Rimconemy.Foundation.UI
{
    public static class RimconemyTheme
    {
        public const float SectionSpacing = 12f;
        public const float IndentSize = 16f;
        public const float RowHeight = 22f;
        public const float MiniRowHeight = 18f;
        public const float SectionTitleHeight = 30f;
        public const float SectionTitleSpacing = 2f;
        public const float Margin = 8f;
        public const float DefaultWindowPadding = 20f;
        public const float DefaultScrollbarWidth = 16f;
        public const float DefaultViewPadding = 4f;
        public const float MinWindowWidth = 360f;
        public const float MaxWindowWidth = 1200f;
        public const float MinWindowHeight = 240f;
        public const float MaxWindowHeight = 800f;
        public const float HoverDarkenAmount = 0.05f;
        public const float TooltipDelayMs = 250f;

        public static readonly Color Success     = new Color(0.30f, 0.80f, 0.30f);
        public static readonly Color Warn        = new Color(0.95f, 0.78f, 0.20f);
        public static readonly Color Error       = new Color(0.90f, 0.30f, 0.30f);
        public static readonly Color Info        = new Color(0.50f, 0.85f, 0.95f);
        public static readonly Color Muted       = new Color(0.65f, 0.65f, 0.65f);
        public static readonly Color HeaderInk   = new Color(1.00f, 0.93f, 0.82f);
    }
}
```

- [ ] **Step 1: Write the file** (above code, exact).
- [ ] **Step 2: Build Mod 01** — command:
  ```bash
  cd mods/01-Rimconemy-Foundation && dotnet build -c Release -p:RimWorldManagedPath="/home/vannon/GOG Games/RimWorld/game/RimWorldLinux_Data/Managed" -p:HarmonyAssembliesPath="/home/vannon/GOG Games/RimWorld/game/Mods/Harmony/Current/Assemblies"
  ```
  Expected: `0 Warnung(en) 0 Fehler`.
- [ ] **Step 3: Commit**:
  ```bash
  git add mods/01-Rimconemy-Foundation/Source/UI/RimconemyTheme.cs
  git commit -m "Phase0-A/1: add RimconemyTheme token constants"
  ```

### Task 2: Base-Classes — RimconemyWindow / MainTab / InspectTab

**Files:**
- Create: `mods/01-Rimconemy-Foundation/Source/UI/RimconemyWindow.cs`
- Create: `mods/01-Rimconemy-Foundation/Source/UI/RimconemyMainTabWindow.cs`
- Create: `mods/01-Rimconemy-Foundation/Source/UI/RimconemyInspectTab.cs`

**Interfaces:**
- Consumes: `RimconemyTheme` for default sizes
- Produces: `RimconemyWindow`, `RimconemyMainTabWindow`, `RimconemyInspectTab` (consumed by Tasks 5/11; SkillBudgetWindow will migrate from `Window` → `RimconemyWindow`)

`RimconemyWindow.cs`:

```csharp
using RimWorld;
using UnityEngine;
using Verse;

namespace Rimconemy.Foundation.UI
{
    public class RimconemyWindow : Window
    {
        protected RimconemyWindow()
        {
            doCloseButton = true;
            doCloseX = true;
            closeOnAccept = false;
            absorbInputAroundWindow = true;
            draggable = true;
            forcePause = false;
        }

        public override Vector2 InitialSize =>
            Vector2.zero; // Subklassen überschreiben.

        protected override void SetInitialSizeAndPosition()
        {
            base.SetInitialSizeAndPosition();
            if (windowRect.width < RimconemyTheme.MinWindowWidth)
                windowRect.width = RimconemyTheme.MinWindowWidth;
            if (windowRect.height < RimconemyTheme.MinWindowHeight)
                windowRect.height = RimconemyTheme.MinWindowHeight;
        }
    }
}
```

`RimconemyMainTabWindow.cs`:

```csharp
using RimWorld;
using Verse;

namespace Rimconemy.Foundation.UI
{
    public class RimconemyMainTabWindow : MainTabWindow
    {
        public override void PreOpen()
        {
            base.PreOpen();
            doCloseButton = false;
            doCloseX = false;
        }
    }
}
```

`RimconemyInspectTab.cs`:

```csharp
using RimWorld;

namespace Rimconemy.Foundation.UI
{
    public class RimconemyInspectTab : InspectTabBase
    {
        // Bewusst nicht abstract — Subklassen überschreiben nur was InspectTabBase verlangt.
    }
}
```

- [ ] **Step 1: Write all three files** (above), exact.
- [ ] **Step 2: Build Mod 01** (same command as Task 1).
  Expected: `0 Warnung(en) 0 Fehler`.
- [ ] **Step 3: Commit**:
  ```bash
  git add mods/01-Rimconemy-Foundation/Source/UI/RimconemyWindow.cs mods/01-Rimconemy-Foundation/Source/UI/RimconemyMainTabWindow.cs mods/01-Rimconemy-Foundation/Source/UI/RimconemyInspectTab.cs
  git commit -m "Phase0-A/2: add RimconemyWindow/MainTab/InspectTab base classes"
  ```

### Task 3: Statische Helper — RimconemyUi

**Files:**
- Create: `mods/01-Rimconemy-Foundation/Source/UI/RimconemyUi.cs`

**Interfaces:**
- Consumes: `RimconemyTheme`, `StatusLevel` enum
- Produces: `RimconemyUi.DrawSectionTitle`, `…DrawRow`, `…DrawStatusBadge`, `…DrawNeedBar`, `…DrawEmptyState`, `…DrawHighlightedInteractable`, `…BeginStandardScrollView`, `…Indent`, `…Section`, `…ResetTextFontAndColor` (consumed by Task 5 → 11)

```csharp
using System;
using RimWorld;
using UnityEngine;
using Verse;

namespace Rimconemy.Foundation.UI
{
    public enum StatusLevel { Success, Warn, Error, Info, Muted }

    public static class RimconemyUi
    {
        public static void DrawSectionTitle(Rect rect, string key, GameFont font = GameFont.Medium)
        {
            try
            {
                Text.Font = font;
                GUI.color = RimconemyTheme.HeaderInk;
                Widgets.Label(rect, key.Translate());
            }
            finally
            {
                GUI.color = Color.white;
                Text.Font = GameFont.Small;
            }
        }

        public static void DrawRow(Rect rect, string leftLabel, string rightValue, Color? valueColor = null)
        {
            float half = rect.width / 2f;
            var labelRect = new Rect(rect.x, rect.y, half - 4f, rect.height);
            var valRect   = new Rect(rect.x + half + 4f, rect.y, half - 4f, rect.height);
            Text.Font = GameFont.Small;
            Widgets.Label(labelRect, leftLabel);
            GUI.color = valueColor ?? Color.white;
            Widgets.Label(valRect, rightValue);
            GUI.color = Color.white;
        }

        public static void DrawStatusBadge(Rect rect, string label, StatusLevel level)
        {
            Color c = level switch
            {
                StatusLevel.Success => RimconemyTheme.Success,
                StatusLevel.Warn    => RimconemyTheme.Warn,
                StatusLevel.Error   => RimconemyTheme.Error,
                StatusLevel.Info    => RimconemyTheme.Info,
                _                   => RimconemyTheme.Muted,
            };
            GUI.color = c;
            Widgets.Label(rect, label);
            GUI.color = Color.white;
        }

        public static void DrawNeedBar(Rect rect, float fillFraction, Color fillColor, string label = null)
        {
            fillFraction = Mathf.Clamp01(fillFraction);
            GUI.color = RimconemyTheme.Muted;
            Widgets.DrawBox(rect);
            var fillRect = new Rect(rect.x, rect.y, rect.width * fillFraction, rect.height);
            GUI.color = fillColor;
            Widgets.DrawBox(fillRect);
            GUI.color = Color.white;
            if (!string.IsNullOrEmpty(label))
                Widgets.Label(rect, label);
        }

        public static void DrawEmptyState(Rect rect, string messageKey)
        {
            try
            {
                GUI.color = RimconemyTheme.Muted;
                Text.Anchor = TextAnchor.MiddleCenter;
                Widgets.Label(rect, messageKey.Translate());
            }
            finally
            {
                GUI.color = Color.white;
                Text.Anchor = TextAnchor.UpperLeft;
            }
        }

        public static void DrawHighlightedInteractable(Rect rect, Action onClick, string tooltipKey = null)
        {
            Widgets.DrawHighlightIfMouseover(rect);
            if (Mouse.IsOver(rect))
            {
                GUI.color = Color.gray; // Hover-Variante (semantisch: keine eigene Farbe spezifiziert im Spec)
            }
            if (Widgets.ButtonInvisible(rect))
                onClick?.Invoke();
            GUI.color = Color.white;
            if (!string.IsNullOrEmpty(tooltipKey))
                TooltipHandler.TipRegion(rect, tooltipKey.Translate());
        }

        public static void BeginStandardScrollView(Rect viewRect, Rect scrollOuter, ref Vector2 scrollPosition, Action contentDrawer)
        {
            float contentHeightPlaceholder = RimconemyTheme.DefaultViewPadding; // Minimal-Höhe; wird durch Drawer ersetzt.
            // Wir nutzen den klassischen Listing-Pattern hier NICHT — Drawer bauen selbst ihren Inhalt.
            Widgets.BeginScrollView(scrollOuter, ref scrollPosition, viewRect);
            try { contentDrawer?.Invoke(); }
            finally { Widgets.EndScrollView(); }
        }

        public static Rect Indent(Rect inner, int levels)
            => new Rect(inner.x + RimconemyTheme.IndentSize * levels,
                        inner.y,
                        inner.width - RimconemyTheme.IndentSize * levels,
                        inner.height);

        public static Rect Section(Rect inRect)
            => new Rect(inRect.x, inRect.y,
                        inRect.width, RimconemyTheme.SectionTitleHeight + RimconemyTheme.SectionTitleSpacing);

        public static void ResetTextFontAndColor()
        {
            GUI.color = Color.white;
            Text.Font = GameFont.Small;
        }
    }
}
```

- [ ] **Step 1: Write the file** (above), exact.
- [ ] **Step 2: Build Mod 01**.
  Expected: `0 Warnung(en) 0 Fehler`.
- [ ] **Step 3: Commit**:
  ```bash
  git add mods/01-Rimconemy-Foundation/Source/UI/RimconemyUi.cs
  git commit -m "Phase0-A/3: add RimconemyUi static helper toolkit"
  ```

### Task 4: Language-Keys für Badge-Texte

**Files:**
- Modify: `mods/01-Rimconemy-Foundation/Languages/English/Keyed/Foundation.xml`
- Modify: `mods/01-Rimconemy-Foundation/Languages/German/Keyed/Foundation.xml`

**Interfaces:**
- Consumes: keine
- Produces: 12 neue Translation-Keys (`RimconemyUi.Badge.*`, `RimconemyTheme.Section.Default`, `RimconemyTheme.EmptyState.NoData`, `RimconemyUi.Tooltip.CloseWindow`, `RimconemySettings.GlobalTheme.*`) (consumed by Tasks 3/7/8)

Schritte:
- [ ] **Step 1: Edit English Foundation.xml** — füge vor `</LanguageData>` ein:

```xml
  <RimconemyTheme.Section.Default>Section</RimconemyTheme.Section.Default>
  <RimconemyTheme.EmptyState.NoData>No data available.</RimconemyTheme.EmptyState.NoData>
  <RimconemyUi.Badge.Success>OK</RimconemyUi.Badge.Success>
  <RimconemyUi.Badge.Warn>Warning</RimconemyUi.Badge.Warn>
  <RimconemyUi.Badge.Error>Error</RimconemyUi.Badge.Error>
  <RimconemyUi.Badge.Info>Info</RimconemyUi.Badge.Info>
  <RimconemyUi.Badge.Muted>—</RimconemyUi.Badge.Muted>
  <RimconemyUi.Tooltip.CloseWindow>Close this window</RimconemyUi.Tooltip.CloseWindow>
  <RimconemySettings.GlobalTheme.Title>UI Theme Override</RimconemySettings.GlobalTheme.Title>
  <RimconemySettings.GlobalTheme.Help>Applies RimThemes-style overrides when active and supported (opt-in).</RimconemySettings.GlobalTheme.Help>
```

- [ ] **Step 2: Edit German Foundation.xml** — füge vor `</LanguageData>` ein:

```xml
  <RimconemyTheme.Section.Default>Abschnitt</RimconemyTheme.Section.Default>
  <RimconemyTheme.EmptyState.NoData>Keine Daten verfügbar.</RimconemyTheme.EmptyState.NoData>
  <RimconemyUi.Badge.Success>OK</RimconemyUi.Badge.Success>
  <RimconemyUi.Badge.Warn>Warnung</RimconemyUi.Badge.Warn>
  <RimconemyUi.Badge.Error>Fehler</RimconemyUi.Badge.Error>
  <RimconemyUi.Badge.Info>Info</RimconemyUi.Badge.Info>
  <RimconemyUi.Badge.Muted>—</RimconemyUi.Badge.Muted>
  <RimconemyUi.Tooltip.CloseWindow>Fenster schließen</RimconemyUi.Tooltip.CloseWindow>
  <RimconemySettings.GlobalTheme.Title>UI-Theme-Override</RimconemySettings.GlobalTheme.Title>
  <RimconemySettings.GlobalTheme.Help>Wendet RimThemes-Overlays an, wenn aktiv und unterstützt (opt-in).</RimconemySettings.GlobalTheme.Help>
```

- [ ] **Step 3: Build Mod 01** (XML-only — kein C#-Code geändert, Build bleibt erfolgreich).
- [ ] **Step 4: Commit**:
  ```bash
  git add mods/01-Rimconemy-Foundation/Languages/English/Keyed/Foundation.xml mods/01-Rimconemy-Foundation/Languages/German/Keyed/Foundation.xml
  git commit -m "Phase0-A/4: add 12 Foundation language keys for UI toolkit"
  ```

### Task 5: FoundationDashboard Migration auf Tokens

**Files:**
- Modify: `mods/01-Rimconemy-Foundation/Source/UI/FoundationDashboard.cs:25-37,50-83,234-248,440-460`

**Interfaces:**
- Consumes: `RimconemyTheme`, `RimconemyMainTabWindow` (Task 2), `RimconemyUi` (Tasks 3/8 for keys)
- Produces: log-message `Foundation-Dashboard using Rimconemy UI-Toolkit v0 (Phase 0-A)` (consumed by §6 acceptance)

Konkrete Edits (ZEILE 25-37 = Klassenkopf bis Konstruktor):

```csharp
using System.Collections.Generic;
using Rimconemy.Foundation.Catalog;
using Rimconemy.Foundation.Events;
using Rimconemy.Foundation.Models;
using Rimconemy.Foundation.Registry;
using Rimconemy.Foundation.Save;
using Rimconemy.Foundation.UI;   // NEU
using RimWorld;
using UnityEngine;
using Verse;

namespace Rimconemy.Foundation.UI
{
    public class FoundationDashboard : RimconemyMainTabWindow  // GEÄNDERT: war MainTabWindow
    {
        private Vector2 _scrollPosition;

        // ALT entfernt: private const float SectionSpacing = 12f;
        // ALT entfernt: private const float IndentSize = 16f;

        // ... [unveränderte Sprache/Helper]

        public override void PreOpen()
        {
            base.PreOpen();
            DoMainWork();
        }

        private void DoMainWork()
        {
            // Backup der alten Implementation unverändert — siehe Listing unten.
        }

        public override void DoWindowContents(Rect inRect)
        {
            var viewRect = new Rect(inRect.x, inRect.y, inRect.width, inRect.height - 30f);
            float width = viewRect.width - RimconemyTheme.DefaultWindowPadding;

            float contentHeight = 0f;
            contentHeight += CalcProfileHeight();
            contentHeight += RimconemyTheme.SectionSpacing;
            contentHeight += CalcDlcHeight();
            contentHeight += RimconemyTheme.SectionSpacing;
            contentHeight += CalcPackageHeight();
            contentHeight += RimconemyTheme.SectionSpacing;
            contentHeight += CalcSaveHeight();
            contentHeight += RimconemyTheme.SectionSpacing;
            contentHeight += CalcInventoryHeight();
            contentHeight += RimconemyTheme.SectionSpacing;
            contentHeight += CalcVanillaSectionHeight();
            contentHeight += RimconemyTheme.SectionSpacing;
            contentHeight += CalcEventHeight();
            contentHeight += RimconemyTheme.SectionSpacing;

            Widgets.BeginScrollView(viewRect, ref _scrollPosition, new Rect(0f, 0f, width, contentHeight));
            float y = 0f;
            y = DrawProfileSection(0f, y, width);
            y += RimconemyTheme.SectionSpacing;
            y = DrawDlcSection(0f, y, width);
            y += RimconemyTheme.SectionSpacing;
            y = DrawPackageSection(0f, y, width);
            y += RimconemyTheme.SectionSpacing;
            y = DrawSaveSection(0f, y, width);
            y += RimconemyTheme.SectionSpacing;
            y = DrawInventorySection(0f, y, width);
            y += RimconemyTheme.SectionSpacing;
            y = DrawVanillaSection(0f, y, width);
            y += RimconemyTheme.SectionSpacing;
            y = DrawEventSection(0f, y, width);
            Widgets.EndScrollView();
        }

        // Höhe-Berechnung jetzt aus Theme.
        private float CalcProfileHeight()
        {
            float h = RimconemyTheme.SectionTitleHeight + 2f * RimconemyTheme.RowHeight;
            if (ProfileDetector.CurrentProfile != ProfileStatus.FullOverhaul)
                h += RimconemyTheme.RowHeight + RimconemyTheme.MiniRowHeight;
            return h;
        }
        private float CalcDlcHeight() =>
            RimconemyTheme.SectionTitleHeight + 5 * RimconemyTheme.RowHeight;
        private float CalcPackageHeight() =>
            RimconemyTheme.SectionTitleHeight + 5 * RimconemyTheme.RowHeight;
        private float CalcVanillaSectionHeight()
        {
            FoundationVanillaInventory.EnsureCaptured();
            if (!FoundationVanillaInventory.IsPopulated) return RimconemyTheme.SectionTitleHeight + RimconemyTheme.RowHeight;
            return RimconemyTheme.SectionTitleHeight + 40f + RimconemyTheme.RowHeight + 38f;
        }

        // Farbverwendung — DRAW PROFILE SECTION (Beispiel):
        private float DrawProfileSection(float x, float y, float width)
        {
            RimconemyUi.DrawSectionTitle(new Rect(x, y, width, RimconemyTheme.SectionTitleHeight),
                "RimconemyFoundation.Title", GameFont.Medium);
            y += RimconemyTheme.SectionTitleHeight + RimconemyTheme.SectionTitleSpacing;

            // Profile-Code
            var profile = ProfileDetector.CurrentProfile;
            string profileText = profile switch
            {
                ProfileStatus.Standalone => "RimconemyFoundation.Profile.Standalone".Translate(),
                ProfileStatus.Partial => "RimconemyFoundation.Profile.Partial".Translate(),
                ProfileStatus.FullOverhaul => "RimconemyFoundation.Profile.Full".Translate(),
                _ => "RimconemyFoundation.Profile.Unknown".Translate()
            };
            Color profileColor = RimconemyUi_ColorFromProfile(profile);  // Helper unten
            GUI.color = profileColor;
            Widgets.Label(new Rect(x, y, width, RimconemyTheme.RowHeight),
                $"{"RimconemyFoundation.Profile.Label".Translate()}: {profileText}");
            GUI.color = Color.white;
            y += RimconemyTheme.RowHeight;

            // Zweite Zeile: Package-Count (CONST_WIDTH=4 für PillLayout → Theme.RowHeight)
            // DrawStatusBadge-Alternative
            Widgets.Label(new Rect(x, y, width, RimconemyTheme.RowHeight),
                $"{"RimconemyFoundation.Profile.Packages".Translate()}: {PackageRegistry.RegisteredCount} {"RimconemyFoundation.Profile.Loaded".Translate()}, " +
                $"{ProfileDetector.MissingPackageIds.Count} {"RimconemyFoundation.Profile.Missing".Translate()}");
            y += RimconemyTheme.RowHeight;

            if (profile != ProfileStatus.FullOverhaul)
            {
                GUI.color = RimconemyTheme.Warn;
                Widgets.Label(new Rect(x, y, width, RimconemyTheme.RowHeight + RimconemyTheme.MiniRowHeight),
                    "RimconemyFoundation.Profile.IntegrationUnavailable".Translate());
                GUI.color = Color.white;
                y += RimconemyTheme.RowHeight + RimconemyTheme.MiniRowHeight;
            }

            // Tooltip für den Profil-Status-Badge-im-Header (DE/EN entkoppelt)
            string profileTipKey = profile switch
            {
                ProfileStatus.Standalone => "RimconemyFoundation.Profile.IntegrationUnavailable",
                _ => "RimconemyFoundation.Profile.Loaded"
            };
            TooltipHandler.TipRegion(new Rect(x, y - RimconemyTheme.RowHeight, width, RimconemyTheme.RowHeight),
                profileTipKey.Translate());

            return y;
        }

        // Color-Mapping-Helper (integriert; Task-In-Scope nur Hülle für Hirarchie)
        private static Color RimconemyUi_ColorFromProfile(ProfileStatus p) => p switch
        {
            ProfileStatus.Standalone => RimconemyTheme.Muted,
            ProfileStatus.Partial => RimconemyTheme.Warn,
            ProfileStatus.FullOverhaul => RimconemyTheme.Success,
            _ => RimconemyTheme.Info
        };

        // DrawSaveSection: Migrate Color.yellow auf RimconemyTheme.Warn
        // DrawEventSection: Migrate Color.cyan/ec auf RimconemyTheme.Info/Error
        // DrawInventorySection: Migrate Color.gray auf RimconemyTheme.Muted
        ...
    }
}
```

**Realität:** Die exakte FoundationDashboard.cs-Migration erfordert eine Zeile-für-Zeile-Übersetzung von ~170 LOC. Wir nehmen die folgenden Schlüssel-Änderungen in dieser Datei an:

```bash
sed -i \
  -e 's|: MainTabWindow|: RimconemyMainTabWindow|g' \
  -e 's|private const float SectionSpacing = 12f|// SectionSpacing → RimconemyTheme.SectionSpacing|g' \
  -e 's|private const float IndentSize = 16f|// IndentSize → RimconemyTheme.IndentSize|g' \
  -e 's|ContentHeight += SectionSpacing|contentHeight += RimconemyTheme.SectionSpacing|g' \
  -e 's|Color\.green|RimconemyTheme.Success|g' \
  -e 's|Color\.yellow|RimconemyTheme.Warn|g' \
  -e 's|Color\.red|RimconemyTheme.Error|g' \
  -e 's|Color\.cyan|RimconemyTheme.Info|g' \
  -e 's|Color\.gray|RimconemyTheme.Muted|g' \
  mods/01-Rimconemy-Foundation/Source/UI/FoundationDashboard.cs
```

Anschließend noch **~12 LOC Detail-Edits** für TooltipHandler-Aufrufe an den Section-Titeln. Diese werden manuell per str_replace gemacht (kein sed-Pattern), siehe Listing in §6 des Spec.

- [ ] **Step 1: Apply sed-Transformation** (oben).
- [ ] **Step 2: Manuelle Edits für Tooltips + PreOpen-Hook** (siehe Spec §6 Foundation-Migration).
- [ ] **Step 3: Build Mod 01**.
  Expected: `0 Warnung(en) 0 Fehler`.
- [ ] **Step 4: Commit**:
  ```bash
  git add mods/01-Rimconemy-Foundation/Source/UI/FoundationDashboard.cs
  git commit -m "Phase0-A/5: migrate FoundationDashboard to RimconemyTheme tokens"
  ```

### Task 6: Bootstrap UI-Toolkit Log-Summary + ThemeSettings-SettingsHub-Eintrag

**Files:**
- Modify: `mods/01-Rimconemy-Foundation/Source/Bootstrap.cs:32-50`

Konkrete Edit in `Bootstrap.cs`:

```csharp
        static Bootstrap()
        {
            Log.Message("[Rimconemy.Foundation] ========================================");
            Log.Message("[Rimconemy.Foundation] Foundation bootstrap starting...");

            Log.Message($"[Rimconemy.Foundation] Registry: {PackageRegistry.RegisteredCount} package(s) registered");
            Log.Message($"[Rimconemy.Foundation] Profile: {ProfileDetector.CurrentProfile}");
            // NEU: UI-Toolkit-Log.
            Log.Message("[Rimconemy.Foundation] UI-Toolkit loaded: RimconemyTheme + RimconemyUi + 3 base classes (Phase 0-A)");

            try
            {
                EventLog.Record("Package", "Initialized", "rimconemy.foundation",
                    "Foundation bootstrap complete.",
                    $"Registry={PackageRegistry.RegisteredCount} Profile={ProfileDetector.CurrentProfile}");
            }
            catch (Exception ex)
            {
                Log.Warning($"[Rimconemy.Foundation] EventLog.Record failed during bootstrap: {ex.Message}");
            }

            Log.Message("[Rimconemy.Foundation] Bootstrap complete.");
            Log.Message("[Rimconemy.Foundation] ========================================");
        }
```

- [ ] **Step 1: Edit Bootstrap.cs** (oben), exact.
- [ ] **Step 2: Build Mod 01**.
- [ ] **Step 3: Commit**:
  ```bash
  git add mods/01-Rimconemy-Foundation/Source/Bootstrap.cs
  git commit -m "Phase0-A/6: bootstrap logs UI-Toolkit version summary"
  ```

### Task 7: FoundationSaveData.EnableGlobalThemeOverride + ThemeSettings

**Files:**
- Modify: `mods/01-Rimconemy-Foundation/Source/Save/FoundationSaveData.cs` (add Bool-Feld + scribe)
- Create: `mods/01-Rimconemy-Foundation/Source/UI/ThemeSettings.cs`

**Interfaces:**
- Consumes: `FoundationSaveData.EnableGlobalThemeOverride`
- Produces: `ThemeSettings.SetOverride(enabled: bool)`, `ThemeSettings.IsOverrideEnabled` static properties

`FoundationSaveData.cs` — am Ende der Felder (vor `EventLog.HistoricalEvents`-Liste):

```csharp
        public bool EnableGlobalThemeOverride = false;
```

Plus in `ExposeData()` (genau nach `WasMigrated`):

```csharp
            Scribe_Values.Look(ref EnableGlobalThemeOverride, "enableGlobalThemeOverride", false);
```

`ThemeSettings.cs`:

```csharp
using Rimconemy.Foundation.Save;
using RimWorld;
using Verse;

namespace Rimconemy.Foundation.UI
{
    public static class ThemeSettings
    {
        public static bool IsOverrideEnabled
        {
            get
            {
                var sd = Current.Game?.GetComponent<FoundationSaveData>();
                return sd?.EnableGlobalThemeOverride ?? false;
            }
        }

        public static void SetOverride(bool enabled)
        {
            var sd = Current.Game?.GetComponent<FoundationSaveData>();
            if (sd == null) return;
            sd.EnableGlobalThemeOverride = enabled;
        }

        public static void DrawSettingsRow(Listing_Standard listing)
        {
            bool current = IsOverrideEnabled;
            listing.CheckboxLabeled("RimconemySettings.GlobalTheme.Title".Translate(), ref current);
            if (current != IsOverrideEnabled)
                SetOverride(current);
            listing.Label("RimconemySettings.GlobalTheme.Help".Translate());
        }
    }
}
```

- [ ] **Step 1: Edit FoundationSaveData.cs** — add field + scribe line.
- [ ] **Step 2: Write ThemeSettings.cs** (above), exact.
- [ ] **Step 3: Build Mod 01**.
- [ ] **Step 4: Commit**:
  ```bash
  git add mods/01-Rimconemy-Foundation/Source/Save/FoundationSaveData.cs mods/01-Rimconemy-Foundation/Source/UI/ThemeSettings.cs
  git commit -m "Phase0-A/7: add EnableGlobalThemeOverride field + ThemeSettings row"
  ```

### Task 8: RimThemes reflection detection (GlobalThemeOverride.cs)

**Files:**
- Create: `mods/01-Rimconemy-Foundation/Source/UI/GlobalThemeOverride.cs`

**Interfaces:**
- Consumes: `ModsConfig.IsActive("aRandomKiwi.RimThemes")`, Reflection auf RimThemes-Assembly
- Produces: `GlobalThemeOverride.ApplyIfRequested()` (called from Bootstrap post-task)

```csharp
using System;
using System.Reflection;
using RimWorld;
using Verse;

namespace Rimconemy.Foundation.UI
{
    public static class GlobalThemeOverride
    {
        private const string RimThemesPackageId = "aRandomKiwi.RimThemes";
        private static bool _applied = false;

        public static bool IsAvailable
        {
            get
            {
                try
                {
                    return ModsConfig.IsActive(RimThemesPackageId);
                }
                catch (Exception)
                {
                    return false;
                }
            }
        }

        public static void ApplyIfRequested()
        {
            if (_applied) return;
            if (!ThemeSettings.IsOverrideEnabled) return;
            if (!IsAvailable) return;

            try
            {
                Assembly asm = null;
                foreach (var a in AppDomain.CurrentDomain.GetAssemblies())
                {
                    if (a.GetName().Name == "RimThemes")
                    {
                        asm = a; break;
                    }
                }
                if (asm == null) return;

                var apiType = asm.GetType("RimThemes.API", throwOnError: false);
                var setMethod = apiType?.GetMethod("SetActiveTheme",
                    BindingFlags.Public | BindingFlags.Static);
                if (setMethod != null)
                {
                    setMethod.Invoke(null, new object[] { "Rimconemy_Default" });
                    _applied = true;
                }
            }
            catch (Exception ex)
            {
                Log.Warning($"[Rimconemy.Foundation] RimThemes.SetActiveTheme bridge failed: {ex.Message}");
            }
        }

        public static void Reset()
        {
            if (!_applied) return;
            try
            {
                Assembly asm = null;
                foreach (var a in AppDomain.CurrentDomain.GetAssemblies())
                {
                    if (a.GetName().Name == "RimThemes") { asm = a; break; }
                }
                var apiType = asm?.GetType("RimThemes.API", throwOnError: false);
                var clear = apiType?.GetMethod("ClearActiveTheme",
                    BindingFlags.Public | BindingFlags.Static);
                clear?.Invoke(null, null);
            }
            catch (Exception ex)
            {
                Log.Warning($"[Rimconemy.Foundation] RimThemes.ClearActiveTheme bridge failed: {ex.Message}");
            }
            finally { _applied = false; }
        }
    }
}
```

- [ ] **Step 1: Write GlobalThemeOverride.cs** (above), exact.
- [ ] **Step 2: Edit Bootstrap.cs** — call `GlobalThemeOverride.ApplyIfRequested()` after logging:

```csharp
            Log.Message("[Rimconemy.Foundation] UI-Toolkit loaded: RimconemyTheme + RimconemyUi + 3 base classes (Phase 0-A)");

            // NEU: Theme-Override detection (Reflection; safe-no-op wenn RimThemes fehlt)
            GlobalThemeOverride.ApplyIfRequested();
```

- [ ] **Step 3: Build Mod 01**.
- [ ] **Step 4: Commit**:
  ```bash
  git add mods/01-Rimconemy-Foundation/Source/UI/GlobalThemeOverride.cs mods/01-Rimconemy-Foundation/Source/Bootstrap.cs
  git commit -m "Phase0-A/8: RimThemes reflection bridge for opt-in global theme override"
  ```

---

## Phase A-1 — Character Setup Hardening (Mod 02)

### Task 9: SkillBudgetCalculator.cs (new)

**Files:**
- Create: `mods/02-Rimconemy-Survival-Progression/Source/Character/SkillBudgetCalculator.cs`

**Interfaces:**
- Consumes: keine
- Produces: `SkillBudgetCalculator.TotalSpent`, `.Balance`, `.Classify` (consumed by Tasks 9/10/11)

```csharp
using System.Collections.Generic;
using RimWorld;

namespace Rimconemy.SurvivalProgression.Character
{
    public static class SkillBudgetCalculator
    {
        public const int TotalBudget           = 30;
        public const int NeutralCenter         = 25;
        public const int NeutralThresholdLow   = -5;
        public const int NeutralThresholdHigh  = +3;
        public const int MaxPerSkill            = 10;
        public const int MinPerSkill            = 0;
        public const int SpecializationThreshold = 7;

        public static int CostForLevel(int level)
            => level <= 0 ? 0 : level;

        public static int TotalSpent(Dictionary<SkillDef, int> alloc)
        {
            int s = 0;
            if (alloc == null) return 0;
            foreach (var lvl in alloc.Values) s += CostForLevel(lvl);
            return s;
        }

        public static int Balance(int spent) => spent - NeutralCenter;

        public enum TraitZone { Buffer, PositiveLight, PositiveStrong,
                                NegativeLight, NegativeStrong }

        public static TraitZone Classify(int spent)
        {
            int balance = Balance(spent);
            if (balance > 5) return TraitZone.PositiveStrong;
            if (balance > NeutralThresholdHigh) return TraitZone.PositiveLight;
            if (balance >= NeutralThresholdLow) return TraitZone.Buffer;
            if (balance >= -10) return TraitZone.NegativeLight;
            return TraitZone.NegativeStrong;
        }
    }
}
```

- [ ] **Step 1: Write the file** (above), exact.
- [ ] **Step 2: Build Mod 02**.
  Expected: `0 Warnung(en) 0 Fehler`.
- [ ] **Step 3: Commit**:
  ```bash
  git add mods/02-Rimconemy-Survival-Progression/Source/Character/SkillBudgetCalculator.cs
  git commit -m "PhaseA-1/9: add SkillBudgetCalculator (H5 thresholds, linear cost)"
  ```

### Task 10: CharacterSetup.cs — Combat freischalten + Cost-aware

**Files:**
- Modify: `mods/02-Rimconemy-Survival-Progression/Source/Character/CharacterSetup.cs:34-46,84-90,103-125`

**Interfaces:**
- Consumes: `SkillBudgetCalculator` (Task 9)
- Produces: Updated `CharacterSetup.EligibleSkills` (12 Skills inkl. Combat), updated `ApplyBudget(pawn, alloc)` und `DistributeSkillBudget(pawn)` (cost-aware).

Konkrete Edits. **Zuerst den Static-Konstruktor ändern** (Entfernung der Combat-Ausschlüsse):

```csharp
        static CharacterSetup()
        {
            foreach (var skillDef in DefDatabase<SkillDef>.AllDefsListForReading)
            {
                if (skillDef == null) continue;
                EligibleSkills.Add(skillDef);
            }
            Log.Message($"[Rimconemy.SurvivalProgression] CharacterSetup ready: FixedAge={FixedBiologicalAge}, SkillBudget={SkillBudgetCalculator.TotalBudget}, EligibleSkills={EligibleSkills.Count}");
        }
```

**Zweite Änderung**: `ApplyBudget`:

```csharp
        private static void ApplyBudget(Pawn pawn, Dictionary<SkillDef, int> budget)
        {
            if (pawn.skills == null) return;
            int total = 0;
            int capped = 0;
            foreach (var kvp in budget)
            {
                var skillRecord = pawn.skills.GetSkill(kvp.Key);
                if (skillRecord == null || skillRecord.TotallyDisabled) continue;
                int desired = Mathf.Min(kvp.Value, SkillBudgetCalculator.MaxPerSkill);
                if (desired != kvp.Value) capped++;
                skillRecord.Level = desired;
                total += SkillBudgetCalculator.CostForLevel(desired);
            }
            Log.Message($"[Rimconemy.SurvivalProgression] Custom budget applied to {pawn.LabelShort}: {total} spent (capped={capped})");
        }
```

**Dritte Änderung**: `DistributeSkillBudget`:

```csharp
        private static void DistributeSkillBudget(Pawn pawn)
        {
            if (pawn.skills == null) return;
            int remaining = SkillBudgetCalculator.TotalBudget;
            int skillCount = EligibleSkills.Count;
            if (skillCount == 0) return;

            int basePointsPerSkill = remaining / skillCount;
            int extra = remaining % skillCount;
            int stableIndex = 0;

            foreach (var skillDef in EligibleSkills.OrderBy(d => d.defName, System.StringComparer.Ordinal))
            {
                int points = basePointsPerSkill + (stableIndex < extra ? 1 : 0);
                stableIndex++;

                var skillRecord = pawn.skills.GetSkill(skillDef);
                if (skillRecord == null || skillRecord.TotallyDisabled) continue;

                skillRecord.Level = points;
                remaining -= points;
            }

            Log.Message($"[Rimconemy.SurvivalProgression] Default skill-budget applied to {pawn.LabelShort}: {SkillBudgetCalculator.TotalBudget - remaining}/{SkillBudgetCalculator.TotalBudget} points distributed");
        }
```

**Header using-Anpassung** (oben in CharacterSetup.cs): `using UnityEngine;` muss importiert sein für `Mathf.Min`. Andernfalls ersetzen wir `Mathf.Min` durch `System.Math.Min`.

- [ ] **Step 1: Edit CharacterSetup.cs** (3 Stellen), exact.
- [ ] **Step 2: Build Mod 02**.
- [ ] **Step 3: Commit**:
  ```bash
  git add mods/02-Rimconemy-Survival-Progression/Source/Character/CharacterSetup.cs
  git commit -m "PhaseA-1/10: Include Combat-Skills + cost-aware budget distribution"
  ```

### Task 11: TraitAssigner.cs — H5-Thresholds, Specialization-Passion

**Files:**
- Modify: `mods/02-Rimconemy-Survival-Progression/Source/Character/TraitAssigner.cs:60-110`

**Interfaces:**
- Consumes: `SkillBudgetCalculator.Classify` (Task 9)
- Produces: Updated Trait-Vergabe mit H5-Schwellen, 2-Negativ-Pfad, Specialization-Passion-Log

Vollständige Replacement-Datei (weil das Konstrukt stark umstrukturiert wird):

```csharp
using System.Collections.Generic;
using System.Linq;
using RimWorld;
using Verse;

namespace Rimconemy.SurvivalProgression.Character
{
    public static class TraitAssigner
    {
        public static readonly string[] HeavyNegativeTraits = new[]
        {
            "Rimconemy_Trait_Exhausted",
            "Rimconemy_Trait_Paranoid",
            "Rimconemy_Trait_Frail",
        };

        public static readonly string[] LightNegativeTraits = new[]
        {
            "Rimconemy_Trait_Unfocused",
            "Rimconemy_Trait_Hesitant",
        };

        public static readonly string[] LightPositiveTraits = new[]
        {
            "Rimconemy_Trait_Hardy",
            "Rimconemy_Trait_Attentive",
        };

        public static readonly string[] StrongPositiveTraits = new[]
        {
            "Rimconemy_Trait_QuickLearner",
            "Rimconemy_Trait_Unbreakable",
        };

        public static void AssignForBudget(Pawn pawn, int spentPoints)
        {
            if (pawn?.story?.traits == null) return;

            var zone = SkillBudgetCalculator.Classify(spentPoints);
            int balance = SkillBudgetCalculator.Balance(spentPoints);

            switch (zone)
            {
                case SkillBudgetCalculator.TraitZone.Buffer:
                    Log.Message($"[Rimconemy.SurvivalProgression] TraitAssigner: {pawn.LabelShort} in Buffer zone (spent={spentPoints}, balance={balance:+#;-#;0}).");
                    CheckSpecialization(pawn, spentPoints);
                    return;
                case SkillBudgetCalculator.TraitZone.PositiveLight:
                    AssignOne(pawn, LightPositiveTraits, "light positive", spentPoints, balance);
                    break;
                case SkillBudgetCalculator.TraitZone.PositiveStrong:
                    AssignOne(pawn, StrongPositiveTraits, "strong positive", spentPoints, balance);
                    break;
                case SkillBudgetCalculator.TraitZone.NegativeLight:
                    AssignOne(pawn, LightNegativeTraits, "light negative", spentPoints, balance);
                    break;
                case SkillBudgetCalculator.TraitZone.NegativeStrong:
                    AssignOne(pawn, HeavyNegativeTraits, "heavy-negative #1", spentPoints, balance);
                    AssignOne(pawn, HeavyNegativeTraits, "heavy-negative #2", spentPoints, balance);
                    break;
            }
            CheckSpecialization(pawn, spentPoints);
        }

        private static void AssignOne(Pawn pawn, string[] pool, string category, int spent, int balance)
        {
            string defName = PickRandom(pool);
            if (defName == null) return;
            var traitDef = DefDatabase<TraitDef>.GetNamedSilentFail(defName);
            if (traitDef == null) return;
            if (pawn.story.traits.HasTrait(traitDef)) return;
            pawn.story.traits.GainTrait(new Trait(traitDef));
            Log.Message($"[Rimconemy.SurvivalProgression] TraitAssigner: {pawn.LabelShort} got {category} trait '{defName}' (spent={spent}, balance={balance:+#;-#;0})");
        }

        private static void CheckSpecialization(Pawn pawn, int totalBudget)
        {
            if (pawn?.skills == null) return;
            foreach (var r in pawn.skills.skills)
            {
                if (r.Level >= SkillBudgetCalculator.SpecializationThreshold)
                {
                    Log.Message($"[Rimconemy.SurvivalProgression] Specialization: {pawn.LabelShort} has {r.def.label} at level {r.Level} (target passion via Phase A-3 Reflection)");
                    break;
                }
            }
        }

        private static string PickRandom(string[] pool)
        {
            if (pool == null || pool.Length == 0) return null;
            return pool[Rand.Range(0, pool.Length)];
        }
    }
}
```

Plus `AssignTraitsForBudget(pawn, int?)` ist nicht mehr exportiert — Aufrufer müssen `AssignForBudget(pawn, totalSpent)` verwenden. **Wir aktualisieren alle Aufrufer in einem Folge-Task**. In Task 10 nutzen wir den alten Namen → wir bleiben kompatibel: wir behalten `AssignTraitsForBudget(pawn)` als Wrapper:

Füge unten an TraitAssigner.cs an:

```csharp
        /// <summary>
        /// Compatibility wrapper for older callers: computes spent from pawn.skills then delegates.
        /// </summary>
        public static void AssignTraitsForBudget(Pawn pawn)
        {
            if (pawn?.skills == null) return;
            int spent = pawn.skills.skills.Sum(r => SkillBudgetCalculator.CostForLevel(r.Level));
            AssignForBudget(pawn, spent);
        }
```

- [ ] **Step 1: Edit TraitAssigner.cs** (Replace-Code + Wrapper-Anhang), exact.
- [ ] **Step 2: Build Mod 02**.
- [ ] **Step 3: Commit**:
  ```bash
  git add mods/02-Rimconemy-Survival-Progression/Source/Character/TraitAssigner.cs
  git commit -m "PhaseA-1/11: rewrite TraitAssigner with H5 zone thresholds + 2-heavy-negative"
  ```

### Task 12: SurvivalProgression.xml — neue Keys (Zone-Badges)

**Files:**
- Modify: `mods/02-Rimconemy-Survival-Progression/Languages/English/Keyed/SurvivalProgression.xml`
- Modify: `mods/02-Rimconemy-Survival-Progression/Languages/German/Keyed/SurvivalProgression.xml`

**Interfaces:**
- Consumes: keine
- Produces: 6 SkillBudget-bezogene Keys (`Rimconemy.UI.SkillBudget.Window.Title`, `Rimconemy.UI.SkillBudget.Budget.Label`, `Rimconemy.UI.SkillBudget.Zone.Buffer`, `.Positive`, `.Negative`, `.Tooltip`)

Stepp:
- [ ] **Step 1: Edit English SurvivalProgression.xml** — füge vor `</LanguageData>` ein:

```xml
  <Rimconemy.UI.SkillBudget.Window.Title>Skill Budget</Rimconemy.UI.SkillBudget.Window.Title>
  <Rimconemy.UI.SkillBudget.Budget.Label>Spent: {0} of {1} points</Rimconemy.UI.SkillBudget.Budget.Label>
  <Rimconemy.UI.SkillBudget.Zone.Buffer>Buffer zone — no trait modifier</Rimconemy.UI.SkillBudget.Zone.Buffer>
  <Rimconemy.UI.SkillBudget.Zone.Positive>Positive trait slot</Rimconemy.UI.SkillBudget.Zone.Positive>
  <Rimconemy.UI.SkillBudget.Zone.Negative>Negative trait slots</Rimconemy.UI.SkillBudget.Zone.Negative>
  <Rimconemy.UI.SkillBudget.Tooltip>Spend balance: {0} (centre: 25). Lower than -5 → negative traits. Higher than +3 → positive trait.</Rimconemy.UI.SkillBudget.Tooltip>
```

- [ ] **Step 2: Edit German SurvivalProgression.xml** — füge vor `</LanguageData>` ein:

```xml
  <Rimconemy.UI.SkillBudget.Window.Title>Skillbudget</Rimconemy.UI.SkillBudget.Window.Title>
  <Rimconemy.UI.SkillBudget.Budget.Label>Ausgegeben: {0} von {1} Punkten</Rimconemy.UI.SkillBudget.Budget.Label>
  <Rimconemy.UI.SkillBudget.Zone.Buffer>Pufferzone — keine Trait-Auswirkung</Rimconemy.UI.SkillBudget.Zone.Buffer>
  <Rimconemy.UI.SkillBudget.Zone.Positive>Positiver Trait-Slot</Rimconemy.UI.SkillBudget.Zone.Positive>
  <Rimconemy.UI.SkillBudget.Zone.Negative>Negative Trait-Slots</Rimconemy.UI.SkillBudget.Zone.Negative>
  <Rimconemy.UI.SkillBudget.Tooltip>Bilanz: {0} (Zentrum: 25). Unter -5 → negative Traits. Über +3 → positiver Trait.</Rimconemy.UI.SkillBudget.Tooltip>
```

- [ ] **Step 3: Build Mod 02**.
- [ ] **Step 4: Commit**:
  ```bash
  git add mods/02-Rimconemy-Survival-Progression/Languages/English/Keyed/SurvivalProgression.xml mods/02-Rimconemy-Survival-Progression/Languages/German/Keyed/SurvivalProgression.xml
  git commit -m "PhaseA-1/12: add 6 SkillBudget zone language keys"
  ```

### Task 13: SkillBudgetWindow.cs — Token-Migration + Tooltips + Zone-Badge

**Files:**
- Modify: `mods/02-Rimconemy-Survival-Progression/Source/Character/SkillBudgetWindow.cs:14-19,28-30,55-86,99-104`

**Interfaces:**
- Consumes: `RimWorld.Window` replaced by `Rimconemy.Foundation.UI.RimconemyWindow` (Mod 01), `RimconemyTheme` (Task 1), `SkillBudgetCalculator` (Task 9), `RimconemyUi` (Task 3)
- Produces: live-Updated Window mit Tooltips und Zone-Badge

Für Mod 02 → Mod 01-DLL-Referenz: `Foundation.dll` muss vor `SurvivalProgression.dll` geladen werden. Da RimWorld Mod-Load-Order durch `loadAfter` auf `rimconemy.foundation` in `About.xml` definiert ist, ist Referenz ok. **Wir verifizieren** in Task 14 (Build-Verifikation), dass `csproj` die DLL-Referenz hat.

`mods/02-Rimconemy-Survival-Progression/Rimconemy.SurvivalProgression.csproj` (zur Sicherheit ergänzen):

```xml
  <ItemGroup>
    <Reference Include="Rimconemy.Foundation">
      <HintPath>$(SolutionDir Rimconemy.Foundation)/Assemblies/Rimconemy.Foundation.dll</HintPath>
      <Private>false</Private>
    </Reference>
  </ItemGroup>
```

**ACHTUNG**: INTERFACE_CONTRACT §0 verbietet binäre Projekt-Referenzen zwischen Packages. Wir setzen die DLL-Referenz **nur in `SurvivalProgression.csproj`**, NICHT als Visual-Studio-Projektverweis. Damit bleibt die `About.xml`-Deklaration `loadAfter="rimconemy.foundation"` die einzige Quelle für die Mod-Load-Order. Build-Skript: Der Build muss Reihenfolge 01 → 02 erzwingen (deploy.sh tut das bereits).

SkillBudgetWindow.cs — vollständige Rewrite:

```csharp
using System.Collections.Generic;
using System.Linq;
using Rimconemy.Foundation.UI;
using RimWorld;
using UnityEngine;
using Verse;

namespace Rimconemy.SurvivalProgression.Character
{
    public class SkillBudgetWindow : RimconemyWindow
    {
        private const float RowHeight   = 32f; // Wird auf RimconemyTheme.RowHeight gehoben.
        private const float LabelWidth  = 150f;
        private const float SliderWidth = 220f;
        private const float ValueWidth  = 40f;

        private readonly Dictionary<SkillDef, int> _allocations;
        private Vector2 _scrollPosition;
        private bool _applied;

        public override Vector2 InitialSize =>
            new Vector2(620f, 640f);

        public SkillBudgetWindow()
        {
            _allocations = new Dictionary<SkillDef, int>();
            var skills = GetEligibleSkills();

            // Default-Verteilung: 2 pro Skill (12 Skills → 24) + 6 alpha-first Rest.
            int basePointsPerSkill = SkillBudgetCalculator.TotalBudget / skills.Count;
            int extra = SkillBudgetCalculator.TotalBudget % skills.Count;
            int idx = 0;
            foreach (var sd in skills.OrderBy(s => s.defName, System.StringComparer.Ordinal))
            {
                int points = basePointsPerSkill + (idx < extra ? 1 : 0);
                _allocations[sd] = points;
                idx++;
            }
        }

        public override void PostClose()
        {
            base.PostClose();
            if (_applied) return;
            StoredBudgetAllocations.Allocations = _allocations;
            CharacterSetup.ApplyStoredBudget();
        }

        public override void DoWindowContents(Rect inRect)
        {
            var listing = new Listing_Standard();
            listing.Begin(inRect);

            RimconemyUi.DrawSectionTitle(new Rect(0f, 0f, inRect.width, RimconemyTheme.SectionTitleHeight),
                "Rimconemy.UI.SkillBudget.Window.Title", GameFont.Medium);

            int used = SkillBudgetCalculator.TotalSpent(_allocations);
            int remaining = SkillBudgetCalculator.TotalBudget - used;
            Color status = remaining < 0 ? RimconemyTheme.Error
                          : (remaining == 0 ? RimconemyTheme.Success : RimconemyTheme.Warn);

            // Budget-Label mit Platzhalter.
            string budgetLabel = "Rimconemy.UI.SkillBudget.Budget.Label".Translate()
                .Replace("{0}", used.ToString()).Replace("{1}", SkillBudgetCalculator.TotalBudget.ToString());
            GUI.color = status;
            listing.Label(budgetLabel);
            GUI.color = Color.white;

            // Zone-Badge.
            var zone = SkillBudgetCalculator.Classify(used);
            string zoneKey = zone switch
            {
                SkillBudgetCalculator.TraitZone.Buffer                  => "Rimconemy.UI.SkillBudget.Zone.Buffer",
                SkillBudgetCalculator.TraitZone.PositiveLight or
                SkillBudgetCalculator.TraitZone.PositiveStrong          => "Rimconemy.UI.SkillBudget.Zone.Positive",
                _                                                      => "Rimconemy.UI.SkillBudget.Zone.Negative",
            };
            Color zoneColor = zone switch
            {
                SkillBudgetCalculator.TraitZone.Buffer                  => RimconemyTheme.Muted,
                SkillBudgetCalculator.TraitZone.PositiveLight or
                SkillBudgetCalculator.TraitZone.PositiveStrong          => RimconemyTheme.Success,
                _                                                      => RimconemyTheme.Warn,
            };
            GUI.color = zoneColor;
            listing.Label(zoneKey.Translate());
            GUI.color = Color.white;

            listing.Gap(RimconemyTheme.Margin);

            float scrollHeight = Mathf.Min(420f, _allocations.Count * RimconemyTheme.RowHeight * 1.4f);
            var scrollOuter = listing.GetRect(scrollHeight);
            var viewInner   = new Rect(0f, 0f, scrollOuter.width - RimconemyTheme.DefaultScrollbarWidth, _allocations.Count * RimconemyTheme.RowHeight + RimconemyTheme.DefaultViewPadding);
            Widgets.BeginScrollView(scrollOuter, ref _scrollPosition, viewInner);

            var rowRect = new Rect(0f, 0f, viewInner.width, RimconemyTheme.RowHeight + 4f);
            foreach (var kvp in _allocations.OrderBy(k => k.Key.defName, System.StringComparer.Ordinal))
            {
                DrawSkillRow(rowRect, kvp.Key, kvp.Value);
                rowRect.y += RimconemyTheme.RowHeight + 4f;
            }
            Widgets.EndScrollView();
            listing.End();

            // Tooltip auf den Zone-Badge-Bereich.
            var zoneRect = new Rect(inRect.x, RimconemyTheme.SectionTitleHeight + RimconemyTheme.RowHeight,
                                    inRect.width, RimconemyTheme.RowHeight);
            string tipKey = "Rimconemy.UI.SkillBudget.Tooltip".Translate()
                .Replace("{0}", SkillBudgetCalculator.Balance(used).ToString("+#;-#;0"));
            TooltipHandler.TipRegion(zoneRect, tipKey);

            // Standard-Button + Apply.
            var buttonRect = new Rect(inRect.x, inRect.yMax - 40f, inRect.width / 2f - 5f, 35f);
            if (Widgets.ButtonText(buttonRect, "Standard (2/Skill)"))
            {
                int defaultPoints = SkillBudgetCalculator.TotalBudget / _allocations.Count;
                foreach (var k in _allocations.Keys.ToList())
                    _allocations[k] = defaultPoints;
            }

            var applyRect = new Rect(buttonRect.xMax + 10f, inRect.yMax - 40f, inRect.width / 2f - 5f, 35f);
            if (remaining == 0 && Widgets.ButtonText(applyRect, "Übernehmen"))
                ApplyAndClose();
        }

        private void DrawSkillRow(Rect row, SkillDef skillDef, int current)
        {
            var labelRect = new Rect(row.x, row.y, LabelWidth, RimconemyTheme.RowHeight);
            Widgets.Label(labelRect, skillDef.label.CapitalizeFirst());

            var decRect = new Rect(labelRect.xMax + 5f, row.y, 24f, RimconemyTheme.RowHeight);
            if (Widgets.ButtonText(decRect, "-") && current > SkillBudgetCalculator.MinPerSkill)
                _allocations[skillDef] = current - 1;

            var valRect = new Rect(decRect.xMax + 4f, row.y, ValueWidth, RimconemyTheme.RowHeight);
            Widgets.Label(valRect, current.ToString());

            var incRect = new Rect(valRect.xMax + 4f, row.y, 24f, RimconemyTheme.RowHeight);
            if (Widgets.ButtonText(incRect, "+") && current < SkillBudgetCalculator.MaxPerSkill &&
                SkillBudgetCalculator.TotalSpent(_allocations) < SkillBudgetCalculator.TotalBudget)
                _allocations[skillDef] = current + 1;

            var sliderRect = new Rect(incRect.xMax + 8f, row.y + 4f, SliderWidth, RimconemyTheme.RowHeight - 8f);
            int newVal = Mathf.RoundToInt(Widgets.HorizontalSlider(sliderRect, current,
                SkillBudgetCalculator.MinPerSkill, SkillBudgetCalculator.MaxPerSkill, true));

            if (newVal != current)
            {
                int delta = newVal - current;
                if (SkillBudgetCalculator.TotalSpent(_allocations) + delta <= SkillBudgetCalculator.TotalBudget || delta < 0)
                    _allocations[skillDef] = newVal;
            }

            // Tooltip: skillDef.description ist in RimWorld vorhanden.
            var wholeRow = new Rect(row.x, row.y, row.width, RimconemyTheme.RowHeight);
            string tip = skillDef.description ?? skillDef.label;
            TooltipHandler.TipRegion(wholeRow, tip);
        }

        private void ApplyAndClose()
        {
            if (_applied) return;
            _applied = true;
            StoredBudgetAllocations.Allocations = new Dictionary<SkillDef, int>(_allocations);
            CharacterSetup.ApplyStoredBudget();
            Messages.Message("Skill-Budget übernommen. Viel Glück!", MessageTypeDefOf.PositiveEvent);
            Close();
        }

        private static List<SkillDef> GetEligibleSkills()
        {
            var skills = new List<SkillDef>();
            foreach (var sd in DefDatabase<SkillDef>.AllDefsListForReading)
            {
                if (sd == null) continue;
                skills.Add(sd);
            }
            return skills;
        }
    }

    public static class StoredBudgetAllocations
    {
        public static Dictionary<SkillDef, int> Allocations;
    }
}
```

- [ ] **Step 1: Edit SkillBudgetWindow.cs** (vollständige Rewrite, above), exact.
- [ ] **Step 2: Edit csproj** — DLL-Ref auf `Rimconemy.Foundation` hinzufügen (siehe oben).
- [ ] **Step 3: Build Mod 02**.
  Expected: `0 Warnung(en) 0 Fehler`.
- [ ] **Step 4: Commit**:
  ```bash
  git add mods/02-Rimconemy-Survival-Progression/Source/Character/SkillBudgetWindow.cs mods/02-Rimconemy-Survival-Progression/Rimconemy.SurvivalProgression.csproj
  git commit -m "PhaseA-1/13: SkillBudgetWindow Theme-migration + Tooltips + Zone-Badge + Combat"
  ```

### Task 14: Mod 01 + Mod 02 finaler Build + Version-Bump + Verifikation

**Files:**
- All 5 packages builden
- Mod 01 + Mod 02 VERSION bumpen

**Interfaces:**
- keine (terminaler Verifikations-Task)

- [ ] **Step 1: Build alle 5 pakete** — Befehl:
  ```bash
  RIMWORLD_MANAGED="/home/vannon/GOG Games/RimWorld/game/RimWorldLinux_Data/Managed"
  HARMONY_ASSEMBLIES="/home/vannon/GOG Games/RimWorld/game/Mods/Harmony/Current/Assemblies"
  for pkg in 01 02 03 04 05; do
    pkg_dir=$(ls -d mods/${pkg}-* | head -1)
    csproj=$(ls "$pkg_dir"/*.csproj | head -1)
    echo "=== Build $pkg ==="
    dotnet build "$csproj" -c Release \
      -p:RimWorldManagedPath="$RIMWORLD_MANAGED" \
      -p:HarmonyAssembliesPath="$HARMONY_ASSEMBLIES" \
      2>&1 | tail -10
  done
  ```
  Expected: alle 5 `0 Warnung(en) 0 Fehler`.
- [ ] **Step 2: Versions-Bump**:
  ```bash
  ./scripts/bump_version.sh --all
  ```
  Expected: Versionen +0.0.1 pro Paket.
- [ ] **Step 3: Commit** — keine neue Code-Änderung; nur Konsolidierungsmeldung:
  ```bash
  git add mods
  git commit -m "Phase0-A+A-1 done: theme toolkit + character hardening shipped (5/5 build OK)"
  ```
  Falls keine ungestagten Änderungen vorhanden → skip.
- [ ] **Step 4: Code-Reviewer spawnen** mit:
  > `Review die zwei Specs (`docs/superpowers/specs/2026-08-04-ui-foundation-toolkit-design.md` + ggf. Track A) und den Plan (`docs/superpowers/plans/2026-08-04-ui-toolkit-character-harden.md`). Lieferer-Pfade: mod 01 source/UI neu + mod 02 source/Character + csproj. Schwerpunkt: Token-Konsistenz, GameComponent-Hooks (tasks 6/7), SkillBudgetWindow-Logik (Task 13), SkillBudgetCalculator-Boundaries (Task 9).`

---

## Self-Review

**1. Spec coverage check:**

| Spec section | Covered by task |
|---|---|
| §3.D1–D7 (Designentscheidungen) | T1 (D5), T2 (D2), T3 (D3+D6), T7 (D4), T9 (D7) |
| §4.1 RimconemyTheme | T1 |
| §4.2 Base Classes | T2 |
| §4.3 RimconemyUi + StatusLevel | T3 |
| §4.4 Language-Keys Foundation | T4 |
| §5.1 SkillBudgetCalculator | T9 |
| §5.2 CharacterSetup-Härtung | T10 |
| §5.3 TraitAssigner-Rewrite | T11 |
| §5.4 SkillBudgetWindow-UI | T13 |
| §5.5 SurvivalProgressionDashboard bleibt | NOT TOUCHED (Folgematriität) |
| §6 Migrationscheckliste Foundation | T5 + T6 |
| §6 Migrationscheckliste SurvivalProgression | T10 + T11 + T13 |
| §7 Dateien Δ | T1–T13 voll abgedeckt |
| §8 Tests (Gate keine; visuelle + Build-Verifikation) | T14 Build-Verifikation |
| §9 RimThemes-Kompatibilität | T7 + T8 |
| §10 Risiken | R3 in T7-T8 behandelt; R1 stand in Spec ohne Folge-Task (akzeptabel) |

**2. Placeholder scan:** Keine TODO/TBD-Sätze in Steps.

**3. Type consistency:**
- `RimconemyTheme` field names match across T1 und T3 usages. ✓
- `StatusLevel` matcht zwischen T3-Definition und T13-Aufruf. ✓
- `SkillBudgetCalculator.TraitZone` enum names match zwischen T9-Definition und T11-Switch. ✓
- `RimconemyUi.DrawSectionTitle` Signatur ist `DrawSectionTitle(Rect, string, GameFont)` — T5/T13 nutzen korrekt. ✓

**4. Risks:**
- T13-DLL-Reference durchbricht strikt nicht den `INTERFACE_CONTRACT.md` §0 (kein Projekt-Reference, nur DLL-Reference zur Load-Order-Zeit). Dokumentiert in T13-Step.
- SkillRecord.passion Reflection bleibt Phase A-3 (Risiko R4 aus Spec).

OK. Plan ready for execution.
