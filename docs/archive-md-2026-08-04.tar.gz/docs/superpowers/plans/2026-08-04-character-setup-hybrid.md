# Character Setup Hybrid Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Make the H5 character budget and trait selection reproducible without introducing an unverified PawnGenerator Harmony hook.

**Architecture:** Keep `SkillBudgetCalculator` as the pure source of budget and zone rules. Add a pure deterministic trait-selection result/API to `TraitAssigner`, then make the existing Pawn wrapper resolve and apply those selected IDs idempotently. Preserve `CharacterSetup.FixAge` as the documented 18/18 fallback while `API-START-01` remains open.

**Tech Stack:** C# `netstandard2.1`, RimWorld 1.6 local assemblies, Harmony only through existing package wiring, package-local assertion tests without an external test framework.

## Global Constraints

- H5 values remain exact: total budget 30, neutral center 25, neutral zone `[-5, +3]`.
- No direct `PawnGenerator`/`PawnGenerationRequest` Harmony patch is implemented in this slice.
- Pure selection code must not depend on `Pawn`, `DefDatabase`, `Verse.Rand`, `Log`, `Current.Game`, or wall-clock time.
- Same seed plus same inputs must produce the same result; global RimWorld RNG state must not affect it.
- Existing public wrappers and current callers remain source-compatible.
- Any code change in package 02 requires `mods/02-Rimconemy-Survival-Progression/VERSION` to be bumped by `+0.0.1`.
- Runtime claims remain `IMPLEMENTED`/`UNVERIFIED` until live save/load and gameplay evidence exists.

---

### Task 1: Add pure deterministic trait-selection contract

**Files:**
- Modify: `mods/02-Rimconemy-Survival-Progression/Source/Character/TraitAssigner.cs`
- Test: `mods/02-Rimconemy-Survival-Progression/Tests/BioRemapTests.cs`

**Interfaces:**
- Consumes: `SkillBudgetCalculator.Classify`, `NegativeTraitCount`, and `PositiveTraitCount`.
- Produces: `TraitSelectionResult`, `TraitAssigner.SelectTraitsForBudget(int seed, int spentPoints, IReadOnlyList<string> positivePool, IReadOnlyList<string> negativePool)`, and `TraitAssigner.StableHash(string)` for deterministic pure selection.

- [ ] **Step 1: Define the result shape**

Add a public immutable-by-convention result class/struct in the Character namespace containing `SpentPoints`, `Balance`, `SkillBudgetCalculator.TraitZone Zone`, `List<string> PositiveTraitIds`, and `List<string> NegativeTraitIds`. Returned lists must be new lists and never the caller's pool.

- [ ] **Step 2: Implement stable selection**

Use a local deterministic integer hash (FNV-1a over UTF-16 code units or an equivalent documented fixed algorithm) and an integer mixer. Sort each non-null pool by ordinal `string` order before indexing so caller order does not change the result. Use the explicit seed, balance, zone, and slot index to select candidates. Deduplicate selected IDs; empty/null pools produce no IDs.

- [ ] **Step 3: Keep the existing Pawn API compatible**

Refactor `AssignForBudget` to call the pure selector with the existing trait pools. Resolve returned IDs with `DefDatabase<TraitDef>.GetNamedSilentFail`, skip absent/duplicate defs, and keep the current warning behavior. `AssignTraitsForBudget` remains a compatibility wrapper and continues to calculate spent points from the Pawn skill records when no override is supplied.

- [ ] **Step 4: Add pure regression assertions**

Extend `BioRemapTests.RunAll()` with assertions for zone boundaries, trait counts, same-seed equality, a different-seed selection check using sufficiently large synthetic pools, null/empty pools, duplicate-pool handling, and independence from any global RNG call. Tests must only call the pure API for these cases.

- [ ] **Step 5: Run package build/tests**

Run the package build command using the repository's local RimWorld and Harmony paths. Expected: 0 warnings and 0 errors. Run the package's existing test runner mechanism if available; otherwise rely on build plus the existing `RunAll()` compile coverage and report that no external runner exists.

---

### Task 2: Align budget application and UI with the cost-aware contract

**Files:**
- Modify: `mods/02-Rimconemy-Survival-Progression/Source/Character/CharacterSetup.cs`
- Modify: `mods/02-Rimconemy-Survival-Progression/Source/Character/SkillBudgetWindow.cs`
- Test: `mods/02-Rimconemy-Survival-Progression/Tests/BioRemapTests.cs`

**Interfaces:**
- Consumes: `SkillBudgetCalculator.CalculateSpentPoints` and the deterministic trait-selection wrapper from Task 1.
- Produces: no new public API; preserves `CharacterSetup.ApplyToAllStartingPawns`, `ApplyStoredBudget`, and `DistributeSkillBudget`.

- [ ] **Step 1: Validate allocations before applying**

Clamp requested levels to `SkillBudgetCalculator.MaxSkillLevel`, ignore null/disabled records, calculate cost-aware spent points, and do not apply an over-budget allocation. Keep the existing call path and logging, but report cost-aware points rather than raw level sums.

- [ ] **Step 2: Make default distribution consume exactly the intended budget where possible**

Use the same cost function to choose affordable increments across eligible skills. Do not rely on raw `TotalBudget / skillCount` as if one level always cost one point. Preserve deterministic skill ordering by ordinal `defName`.

- [ ] **Step 3: Make UI default allocation cost-aware**

Construct the initial and standard allocations through a shared cost-aware helper or equivalent local loop so the UI's displayed `used` equals the applied allocation's cost. Keep existing button behavior and the 30-point cap.

- [ ] **Step 4: Add consistency assertions**

Assert that a generated/default allocation's displayed cost never exceeds 30 and that its cost is computed by `SkillBudgetCalculator.CalculateSpentPoints`, not raw level totals.

- [ ] **Step 5: Build package 02**

Run the package build again and confirm no warnings/errors.

---

### Task 3: Version and roadmap handoff update

**Files:**
- Modify: `mods/02-Rimconemy-Survival-Progression/VERSION`
- Modify: `docs/H5-character-setup-formula.md`
- Modify: `HANDOFF.md`
- Modify: `ROADMAP.md`
- Modify: `docs/PLAN_GESAMTAUFGABEN.md`
- Create: `docs/handoff-2026-08-04-character-setup.md`

- [ ] **Step 1: Bump package 02 version**

Run `./scripts/bump_version.sh 02` only after code changes are complete; expected version increment is exactly `+0.0.1` from the current value.

- [ ] **Step 2: Update H5 status honestly**

Mark the deterministic Pure-Logik portion as implemented, retain Bio-Remap/Save-Schema and direct generator API as open, and state that runtime proof is still absent.

- [ ] **Step 3: Archive the sprint handoff**

Record changed files, tests, build result, explicit non-goals, and next gate (`API-START-01` plus live runtime evidence). Update Root `HANDOFF.md` and the matching roadmap task checkboxes without claiming full Character Setup completion.

- [ ] **Step 4: Check documentation references**

Ensure no changed document says the direct PawnGenerator hook or runtime save/load gate is complete.

---

### Task 4: Review and final verification

**Files:**
- Review: all changed files

- [ ] **Step 1: Run code review**

Ask the code reviewer to check deterministic behavior, API compatibility, cost consistency, and roadmap truthfulness.

- [ ] **Step 2: Run package build and targeted static checks**

Run `dotnet build` for package 02 with local paths, check `git diff --check`, and search for accidental `Verse.Rand` use in the new pure selector and accidental direct Generator Harmony patches.

- [ ] **Step 3: Address review/build findings**

Fix only findings within this approved scope, then repeat the affected validation command.

- [ ] **Step 4: Report evidence and remaining gates**

Summarize exact build/test results and clearly separate implemented pure logic from unverified runtime/API work.
