# Sprint-Handoff: 2026-08-04 — Character Setup Hybrid

> **Scope:** ROADMAP Phase 4 / H5, Pure-Logik- und Determinismus-Schnitt  
> **Paket:** `02-Rimconemy-Survival-Progression`  
> **Version:** `0.1.28`  
> **Status:** Teilabnahme — Code-/Build-Gate bestanden; Runtime-/API-Gates offen

## Implementiert

- `SkillBudgetCalculator.BuildDefaultAllocation` erzeugt eine stabile, kostenbewusste Default-Verteilung.
- `CharacterSetup.ApplyBudget` clamp’t Levels, verwirft überbudgetierte Allocations atomar und setzt nicht gelieferte eligible Skills auf 0.
- `SkillBudgetWindow` verwendet dieselbe Default-Allocation wie die Runtime und prüft beim `+`-Button die tatsächlichen progressiven Grenzkosten.
- `TraitAssigner.SelectTraitsForBudget` ist pure und deterministisch; kein globaler `Verse.Rand`-Zustand.
- Expliziter Seed-Overload `AssignForBudget(Pawn, int, int)` ergänzt; der Legacy-Wrapper bleibt kompatibel.
- Starke Negativzone wählt deterministisch zwei unterschiedliche Kandidaten, sofern der Pool mindestens zwei unterschiedliche IDs enthält.
- `BioRemapTests` deckt H5-Grenzen, Neutralzone, Trait-Anzahl, Seed-Reproduzierbarkeit, Seed-Variation, leere und duplizierte Pools ab.

## Belege

- Paket-02-Build mit lokalen RimWorld-/Harmony-Referenzen: **0 Warnungen, 0 Fehler**.
- Version-Bump: `0.1.27 → 0.1.28`; Registry-Sync auf `rimconemy.survivalprogression v0.1.28`.
- Pure Tests bleiben in der bestehenden paketinternen `RunAll()`-Suite; es gibt kein externes Testframework im Projekt.

## Bewusste Nicht-Ziele

- Kein direkter Harmony-Patch auf `PawnGenerator.GeneratePawn`.
- Kein Anspruch, dass `PawnGenerationRequest.FixedBiologicalAge`/`FixedChronologicalAge` lokal als konkrete API verifiziert sind.
- Kein `CharacterSetupState`/Scribe-Schema und kein persistenter Setup-Seed.
- Kein Spielstart-, Def-Load-, Save/Load- oder Character-UI-Live-Beleg.

## Nächste Gates

1. `API-START-01` mit konkreter lokaler Assembly-Signatur und Compile-/Runtime-Beleg abschließen.
2. CharacterSetupState mit Schema-Version, Seed, Skills und Trait-IDs definieren.
3. Bio-Remap und Generator-/Customization-Pfad mit 18/18 sowie Save/Load live testen.
4. H5-Balance-Gate für Budget 30 und Neutralzone `[-5,+3]` entscheiden.
