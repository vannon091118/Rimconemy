# Sprint-Handoff: 2026-08-04 — Story-Datenmodelle + Auswahlfunktion

> **Sprint:** Coding-Cut §1 (tasks.md §6)
> **Dauer:** 1 Session
> **Status:** Abgeschlossen ✅
> **Nächster Sprint:** [`../../HANDOFF.md`](../../HANDOFF.md) (Root-TODO)

## Was wurde erreicht

7 C#-Dateien in `mods/05-Rimconemy-Infected-Automation/Source/Story/` implementiert:

| Datei | Zeilen (ca.) | Beschreibung |
|---|---|---|
| `SettingProfile.cs` | 120 | 18 Parameter, 3 Built-in-Profile, `GetBuiltIn()`, Tick-Helfer |
| `StoryEventSpec.cs` | 155 | Event-Spec, `EventCondition` (Factory), `EventChoice` |
| `SituationSnapshot.cs` | 120 | Aggregierter Snapshot, `HasActiveEventOfFamily()`, `DaysSinceEvent()` |
| `StoryState.cs` | 95 | Save-Modell, Cooldowns, Idempotency-Keys, `PruneExpiredCooldowns()` |
| `DeterministicRng.cs` | 95 | Splitmix64-PRNG, FNV-1a-Hash, `BuildSeed()` |
| `StoryEventCatalog.cs` | 175 | 3 MVP-Events hardcodiert, `Register/GetById/All` |
| `StorySelector.cs` | 200 | 8-Schritt-Auswahlalgorithmus, `SelectionResult`, Prerequisite/Exclusion-Evaluator |

**Build:** 0 Warnungen, 0 Fehler (2 Builds: initial + Review-Fixes).

## Review-Befunde (behoben)

1. **Bug:** `HasActiveEventOfFamily()` mit `null`-Catalog → `ActiveEventFamilies`-Liste eingeführt
2. **Bug:** `NextInt()` Rejection-Sampling-Formel → Standard-Threshold-Pattern
3. **Design:** `CriticalResourceIds` als String → `List<string>`
4. **Design:** `SeedRule` toter Code → Dokumentations-Kommentar ergänzt
5. **Design:** `DeterminismKey`-Format → Hash-basiert, im Code dokumentiert

## Referenzen

- Spezifikation: `docs/H2-story-contract.md`
- Build-Vertrag: `mods/05-Rimconemy-Infected-Automation/BUILD.md`
- Root-TODO (nächster Sprint): `HANDOFF.md`
