# Handoff — Falsifizierungs-Fixes für Save-/Idempotenzpfade

> Datum: 2026-08-04
> Scope: Pakete 01 Foundation, 04 Economy & Territory, 05 Infected & Automation

## Befunde und Fixes

- **CreditsLedger:** Replay antwortet direkt aus einer persistierbaren `Key → TxId`-Map und ist dadurch unabhängig vom 256er UI-History-Cap. Die Einfügereihenfolge wird separat gespeichert. Alte Saves ohne Index rekonstruieren Keys, soweit der historische Transaction-Record noch in der retained History liegt; nicht rekonstruierbare Keys werden nicht erfunden.
- **CreditsLedger-Balance:** Vor der Addition werden positive/negative Grenzverletzungen inklusive `long.MinValue` erkannt. Abgelehnte Transaktionen verändern weder Balance noch TxId.
- **StoryState:** Idempotency-Keys persistieren ihre Insertions-Ticks über parallele Scribe-Listen. Legacy-Keys ohne Tick verwenden ein `-1`-Sentinel und werden nicht fälschlich als Tick 0 behandelt. Alters-Pruning entfernt nur nachweislich abgelaufene Keys; der Count-Cap greift anschließend deterministisch.
- **Foundation EventLog:** Pipe-Escape, Pipe-Unescape und Field-Splitting arbeiten escape-aware in Einzelpass-Scannern. Pipes, Backslashes, Literal-`\\p` und trailing Backslashes bleiben im Roundtrip erhalten.

## Regressionstests

- `mods/04-.../Tests/CreditsLedgerRegressionTests.cs`
- `mods/05-.../Tests/StoryStateRegressionTests.cs`
- `mods/01-.../Tests/FoundationEventLogRegressionTests.cs`

Die Tests sind self-contained, werden über die jeweiligen Paket-Bootstraps aufgerufen und benötigen kein externes Testframework. In dieser Validierung wurden sie kompiliert und verdrahtet; ein separater Test-Runner bzw. frischer RimWorld-Boot-Log mit `passed/failed`-Ausgabe liegt nicht vor.

## Validierung

- Foundation 01: Build 0 Warnungen / 0 Fehler
- Economy 04: Build 0 Warnungen / 0 Fehler
- Infected 05: Build 0 Warnungen / 0 Fehler nach Entfernung einer unbenutzten Pruning-Variable
- Registry synchronisiert mit `VERSION`: Foundation `0.1.36`, Economy `0.0.25`, Infected `0.0.32`

## Nicht behauptet

Ein echter RimWorld-Save/Load-Live-Test mit Scribe sowie ein Ingame-EventLog-Roundtrip bleiben Runtime-Gates. Die self-contained Tests prüfen die reine Logik und den privaten Event-Envelope über Reflection, ersetzen aber keinen Spielstart-/Save-Beleg.

Für bereits ausgelieferte Foundation-Saves mit dem früheren Base64-Feldformat existiert im aktuellen Envelope kein Formatmarker und in diesem Slice kein belastbarer Migrationsbeleg. Diese Legacy-Kompatibilität wird daher nicht behauptet; vor einer Save-Schema-Freigabe muss das alte Format entweder gezielt migriert oder ausdrücklich abgelehnt werden.
