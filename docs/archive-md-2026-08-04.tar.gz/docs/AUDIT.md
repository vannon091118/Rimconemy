# AUDIT.md — Rimconemy Architectural Audit &amp; Design Decisions

> **Stand:** 2026-08-04 | **Owner:** Buffy (Agent) + User  
> **Zweck:** Single Source of Truth für alle Audit-relevanten Architekturentscheidungen, besonders solche die bei externen Reviews als „Lücke" fehlinterpretiert werden könnten.

---

## 1. Harmony-Strategie (bewusste Design-Entscheidung)

### Status: ✅ ENTSCHEIDUNG DOKUMENTIERT

### Entscheidung: Harmony-Minimierung zugunsten nativer RimWorld-Anker

Das Rimconemy-Projekt **nutzt Harmony bewusst nur dort, wo native RimWorld-Mechanismen nicht ausreichen**. Dies ist keine Implementierungslücke, sondern eine architektonische Grundsatzentscheidung.

### Begründung

| Kriterium | Bewertung |
|---|---|
| **Stabilität** | Native Anker (`GameComponent`, `StaticConstructorOnStartup`, `Defs`, `PatchOperation`) brechen bei RimWorld-Updates seltener als Harmony-Patches |
| **Kollisionsrisiko** | Harmony-Patches verschiedener Mods konkurrieren um dieselben Methoden; native Anker laufen parallel |
| **Wartbarkeit** | Weniger Harmony-Code = weniger Transpiler-Fragilität, weniger Upgrade-Aufwand bei neuen RimWorld-Versionen |
| **Community-Standard** | Harmony ist der Standard für *Runtime-Patching* — aber GameComponents sind der Standard für *Persistenz und Lifecycle* |

### Anker-Hierarchie (Priorität 1 > 3)

```
1. Defs / PatchOperation-XML          → Daten- und Inhaltsänderungen
2. [StaticConstructorOnStartup]        → Boot-Reihenfolge, Registry, einmalige Init
3. GameComponent / WorldComponent      → Runtime-State, Persistenz, Ticks
4. Harmony (Prefix/Postfix)            → Nur wenn 1–3 nicht reichen
5. Harmony (Transpiler)                → Nur nach gescheitertem Prefix/Postfix-Spike
```

### Aktuelle Harmony-Nutzung (2026-08-04)

| Patch | Mod | Typ | Grund |
|---|---|---|---|
| `Page_ConfigureStartingPawnsBioPatch` | 02 | `[HarmonyPostfix]` | Einziger Weg, vor dem ersten Rendern des Customization-Screens in `Page_ConfigureStartingPawns.PreOpen` einzugreifen |

**Kein Transpiler im gesamten Projekt.** Keine eigene `0Harmony.dll` — alle Referenzen gehen über `brrainz.harmony` als `modDependency` (About.xml) und NuGet-Referenz via `$(HarmonyAssembliesPath)`.

### Falsifikation (wann diese Entscheidung revidiert wird)

- Ein dokumentierter Spike (z.B. `API-STORYTELLER-01`) belegt, dass der direkte Storyteller-Zugriff **zwingend** Harmony erfordert und kein Prefix/Postfix ausreicht.
- Ein native-Anker-Spike (`API-ANCHOR-01`) belegt, dass RimWorld 1.6 den benötigten Hook nicht bereitstellt.
- Bis dahin: Harmony-Minimierung bleibt aktiv. Jeder neue Harmony-Patch braucht einen Eintrag in dieser Tabelle.

### Vergleich zu Community-Praktiken

Die RimWorld-Modding-Community nutzt Harmony oft als primäres Werkzeug. Rimconemy weicht bewusst ab:

- **Risiko der Community-Norm:** Viele Mods patchen `Find.Storyteller`, `IncidentQueue`, `Page_ConfigureStartingPawns` — jedes RimWorld-Update kann diese Patches brechen.
- **Rimconemy-Ansatz:** Nutzt `GameComponent.GameComponentTick` statt `StorytellerComp`-Patches, `StaticConstructorOnStartup` statt Assembly-Patches, `Scribe` statt Reflection-Save.
- **Ergebnis:** Weniger Laufzeitkonflikte, dafür frühere Bindung an RimWorlds offizielle API.

---

## 2. Prefix/Postfix statt Transpiler

### Status: ✅ ENTSCHEIDUNG DOKUMENTIERT

### Entscheidung

Sollte Harmony in Zukunft ausgeweitet werden (z.B. für den direkten Storyteller-Spike), wird **ausschließlich Prefix/Postfix** verwendet. Transpiler (IL-Manipulation) sind:
- kollisionsanfälliger (zwei Transpiler auf derselben Methode = hohes Konfliktrisiko)
- versionsabhängiger (IL-Änderungen in RimWorld-Updates brechen Transpiler)
- schwerer debuggbar (kein Klartext-Code, nur IL-Stream)

### Ausnahme-Regel

Ein Transpiler ist nur erlaubt, wenn:
1. Ein Spike belegt, dass Prefix/Postfix das Ziel nicht erreichen können (z.B. weil der benötigte IL-Body fehlt — siehe Punkt 3)
2. Der Patch im **BypassGate**-Verfahren (aus SyxEconomyMod übernommen) freigegeben wurde

---

## 3. Patch-Barkeit von Methoden ohne IL-Body

### Status: 🟡 BEWUSST — Noch nicht relevant, aber dokumentiert

### Hintergrund

Harmony kann nur Methoden patchen, die tatsächlich IL-Code besitzen. Elternklassen ohne eigenen Body (z.B. abstrakte Methoden, Interface-Default-Implementierungen, Auto-Properties) sind nicht direkt patchbar.

### Relevanz für Rimconemy

- Der geplante **direkte StorytellerDef-Anker** (Roadmap: nach `API-STORYTELLER-01`-Spike) muss vorab per Decompile geprüft werden.
- Falls die Zielmethode keinen eigenen IL-Body hat, muss stattdessen die Elternklasse gepatcht werden (Pattern-Matching über `__instance`).

### Vorgehen

Vor jedem Harmony-Spike: `dotnet-ildasm` oder Rider-Decompiler auf der Zielmethode laufen lassen und im Spike-Dokument festhalten:
- Existiert ein IL-Body?
- Falls nein: Welche Elternklasse muss stattdessen gepatcht werden?
- Welche Harmony-Strategie (Prefix/Postfix/__instance-Matching) wird benötigt?

---

## 4. ExposeData / Scribe — Save-Korrektheit

### Status: 🟡 IMPLEMENTIERT, Tests empfohlen

### Aktueller Stand

| Klasse | Scribe-Methode | LookMode | Backing-Listen? | Risiko |
|---|---|---|---|---|
| `StoryState.cs` | `Scribe_Collections.Look` für Dict/HashSet | `LookMode.Value` | ✅ Parallel-Listen (`_cooldownKeys`/`_cooldownValues`) | Gering — Value-Typen, keine Referenzen |
| `FoundationSaveData.cs` | `Scribe_Collections.Look` für `List<string>` | `LookMode.Value` | Nein (Listen direkt) | Gering — nur Value-Typen |
| `CreditsLedger.cs` | `Scribe_Collections.Look` für `List<Transaction>` | `LookMode.Deep` | Nein (IExposable-Objekte direkt) | Mittel — Deep-Save ist korrekt, aber ungetestet |
| `ProgressionGameComponent.cs` | `Scribe_Collections.Look` für Listen | `LookMode.Deep` + `LookMode.Value` | ✅ Null-Checks nach Load | Gering — Defensive Guards vorhanden |

### Empfohlene Falsifikationstests (Phase 3+)

Für jedes Scribe-Collection-Pattern sollte ein Test existieren:
1. **Serialisierung → Deserialisierung → Wertevergleich** (Roundtrip)
2. **LookMode.Reference mit fehlender Backing-Liste** → NRE-frei
3. **Schema-Migration von v0 auf Current** → kein Datenverlust

### Bekannte Risiken

Das häufigste NRE-Muster in RimWorld-Mods: `Scribe_Collections.Look(ref list, "key")` mit `LookMode.Reference` auf ein Feld, dessen Backing-Liste null ist → NRE beim Rebuild. Rimconemy verwendet derzeit kein `LookMode.Reference`, was dieses Risiko eliminiert. Falls in Zukunft Referenzen gespeichert werden, **muss** eine parallele Backing-Liste existieren.

---

## 5. GameComponent / WorldComponent

### Status: ✅ KORREKT IMPLEMENTIERT

### Aktuelle Nutzung

| Komponente | Mod | Typ | Zweck |
|---|---|---|---|
| `FoundationSaveData` | 01 (Foundation) | `GameComponent` | Persistenz, Schema-Version, Migration |
| `ProgressionGameComponent` | 02 (Survival) | `GameComponent` | XP-Sampling, Game-Over-Detection |
| `MapMarketComponent` | 04 (Economy) | `MapComponent` | Per-Map-Markt-Snapshot |
| `WalletGameComponent` | 04 (Economy) | `GameComponent` | Wallet-Persistenz |
| `SilverGameComponent` | 04 (Economy) | `GameComponent` | Silber-Persistenz |
| `OutpostService` | 04 (Economy) | `GameComponent` | Outpost-Roster |
| `StoryDirector` | 05 (Infected) | `GameComponent` | Story-Evaluation, Tick-basiert |

### Hinweis zu MapComponents

`MapMarketComponent` ist ein korrekter Use-Case für `MapComponent` — Marktdaten sind pro Map unterschiedlich. Alle globalen Daten (Wallet, Progression, Story) nutzen `GameComponent`, was für Single-Player-RimWorld die richtige Wahl ist.

**Kein Risiko:** Foundation nutzt keine `MapComponent` für globale Daten.

---

## 6. Namespace-Trennung RimWorld vs. Verse

### Status: ✅ KORREKT

Alle Rimconemy-Klassen importieren beide Namespaces (`using Verse;` + `using RimWorld;`) nach Bedarf. Es gibt keine unvollständigen using-Listen.

---

## 7. Decompilieren als API-Verifikation

### Status: ✅ PRAKTIK DOKUMENTIERT

Das Projekt verwendet Spike-Dokumente (`docs/superpowers/specs/`, `mods/*/Tests/Spikes/`) als API-Verifikation. Die Methodik ist etabliert. Empfehlung für Phase 3: Decompile-Ergebnisse als Kommentar-Referenz direkt im Zielcode verlinken (Assembly-CSharp-Quellzeile), analog zu:

```csharp
// Decompile ref (1.6.9371): Verse.GameComponent.ExposeData() → VTable-Dispatch, kein eigener Body
```

---

## 8. HugsLib

### Status: ✅ KEINE ABHÄNGIGKEIT

Kein `HugsLib`-Import, keine `HugsLib`-Abhängigkeit in `About.xml`. Die eigene Foundation-Registry ersetzt Fremdbibliotheken bewusst.

---

## 9. StaticConstructorOnStartup

### Status: ✅ KORREKT IMPLEMENTIERT

Alle 5 Bootstrap.cs-Dateien nutzen `[StaticConstructorOnStartup]`. Die defensive Prüfung auf `Current.Game == null` (z.B. in Foundation Bootstrap.cs) ist korrekt — während der Static-Constructor-Phase ist Current.Game noch nicht initialisiert.

---

## 10. HarmonyRimWorld als Shared Dependency

### Status: ✅ KORREKT

| Mod | About.xml Dependency | Eigene 0Harmony.dll? |
|---|---|---|
| 01 Foundation | `brrainz.harmony` | ❌ (Shared) |
| 02 Survival | `brrainz.harmony` | ❌ (Shared) |
| 03 Scavenger | `brrainz.harmony` | ❌ (Shared) |
| 04 Economy | `brrainz.harmony` | ❌ (Shared) |
| 05 Infected | `brrainz.harmony` | ❌ (Shared) |

Alle 5 Mods deklarieren `brrainz.harmony` als `modDependency` und referenzieren `0Harmony.dll` via `$(HarmonyAssembliesPath)` im Build. **Keine Mod schleppt eine eigene Kopie mit.** Dies ist der von der Community empfohlene Pfad (zentrale Harmony-Instanz, einheitliche Version, Load-Order stabil).

---

## Offene Audit-Punkte

| ID | Bereich | Status | Nächster Schritt |
|---|---|---|---|
| A-01 | Scribe-Tests für `LookMode.Reference` | 🟡 Empfohlen | Falsifikationstest für StoryState/FoundationSaveData/CreditsLedger schreiben |
| A-02 | Decompile-Referenzen im Code | 🟡 Empfohlen | Phase 3: API-Zeilen-Kommentare in Zielmethoden einfügen |
| A-03 | Transpiler-Spike-Bedingung | 🟡 Vorsorglich | Vor erstem Transpiler: `API-ILBODY-01`-Spike durchführen |

---

## Änderungshistorie

| Datum | Version | Änderung |
|---|---|---|
| 2026-08-04 | 1.0 | Initiale Audit-Dokumentation. Harmony-Strategie, Scribe-Risiken, GameComponent-Check, DLC- und HugsLib-Status, 10 Community-Punkte bewertet. |
| 2026-08-04 | 1.1 | 5 Code-Fixes nach User-Ground-Truth-Audit: CreditsLedger (Idempotenz-Separation, Rejection-Balance), StoryState (Insertion-Order-Tracker), DeterministicRng (InvariantCulture), EventLog (Pipe-Escaping). |