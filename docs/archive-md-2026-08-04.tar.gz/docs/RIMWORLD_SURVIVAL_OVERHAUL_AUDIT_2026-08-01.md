# RimWorld Survival Overhaul — Pre-Implementation Quad-Perspective Audit

> **SUPERSEDED BY:** [`mods/PRODUCT_VISION.md`](../mods/PRODUCT_VISION.md), [`mods/BLUEPRINT_INDEX.md`](../mods/BLUEPRINT_INDEX.md), [`mods/BLUEPRINT_EXECUTION_CONTRACT.md`](../mods/BLUEPRINT_EXECUTION_CONTRACT.md) und [`mods/VANILLA_DLC_RESEARCH_BASELINE.md`](../mods/VANILLA_DLC_RESEARCH_BASELINE.md). Dieser historische Audit bleibt als Beleg der damaligen Ausgangslage erhalten; seine alten Blocker sind nicht erneut als aktuelle Projektbeschreibung zu lesen.
>
> **Stand:** 2026-08-01 | **Basis:** historischer Pre-Implementation-Stand vor den Rimconemy-Vertrags- und Blueprint-Dokumenten |
> **Methodik:** 4-Quadrate (USER×UX, USER×TECH, CODER×UX, CODER×TECH)
> **Truth-Pass:** Dieser Bericht beschreibt ausschließlich seinen damaligen Prüfstand. Der aktuelle Dokumentstand ist in [`../mods/PRODUCT_VISION.md`](../mods/PRODUCT_VISION.md), [`../mods/BLUEPRINT_INDEX.md`](../mods/BLUEPRINT_INDEX.md) und [`../mods/VANILLA_DLC_RESEARCH_BASELINE.md`](../mods/VANILLA_DLC_RESEARCH_BASELINE.md) erfasst.
> **Fokus:** Survivor-Outposts, Credits-Wallets, Angebot/Nachfrage-Wirtschaft, automatisierte Outposts, Infizierte, Produktionsketten, Ressourcen-Remapping und settinggerechte Biome — **explizite Ausschlüsse:** kein Code-Audit, kein Performance-Messlauf, kein Save-/Multiplayer-Test, kein RimWorld-Assembly-Abgleich
> **Status:** ABORTED AS CODE AUDIT / zulässige Pre-Implementation-Assessment. Wegen fehlender Tests, Logs, Diagnostics und Implementierung werden keine Laufzeitbefunde behauptet.

## Beweisgrenze und Abbruchgrund

**Historischer Befund zum Auditzeitpunkt:** Dieses Repository enthielt damals keine Dateien, Tests, Logs, Diagnostik-Exports oder Implementierung. Dieser Befund wird nicht auf den aktuellen Dokumentstand übertragen; er erklärt nur, warum der damalige Code-/Last-Audit abgebrochen wurde. Deshalb sind Aussagen über konkrete Bugs, LOC, Laufzeitverhalten oder vorhandene Codepfade nicht zulässig. Solche Aussagen sind als `[hyp]` markiert. Konzeptanforderungen sind als `[brief]` markiert und stammen aus dem User-Auftrag, nicht aus Code. Architekturvorschläge sind als `[recommendation]` markiert.

Der Quad-Perspective-Audit wird hier als **Code-/Last-Audit abgebrochen**, weil das Skill-Guardrail „keine Tests + keine Diagnostics“ greift. Die folgenden Abschnitte sind ein begrenztes Pre-Implementation-Assessment, um Phase N+1 zu definieren; sie ersetzen keinen späteren Code-Audit.

Belegbare historische Zustandsfunde:

- **E1:** Der Projektbaum war beim Audit leer; es gab damals keine vorhandenen Code- oder Dokumentationsdateien.
- **E2:** Es existierte damals keine technische Test- oder Diagnostics-Basis, mit der Last-, Save- oder UI-Behauptungen falsifiziert werden konnten.
- **E3:** Der User-Brief fordert ein Survival-Overhaul mit Survivor-Outposts, echter Wirtschaft, Credits-Wallets, automatisierbaren Outposts, Infizierten, Ressourcen-/Produktionsketten-Remapping und passenden Biomen. `[brief]`

## Aktueller Truth-Pass (2026-08-01)

**Erledigt durch neue Dokumente:** Produktvision, Paketaufteilung, Vanilla-/DLC-Baseline, Artefakt-/Taskvertrag und fünf Blaupausen. **Weiter offen:** Assembly-/Def-Spikes, Build, Laufzeit, Save-/UI-/Performance-Tests und alle 19 Falsifizierungsberichte. Der Audit bleibt daher `ABORTED AS CODE AUDIT` und ist kein Freigabesignal.

Seit diesem historischen Audit wurden folgende Dokumentationsartefakte ergänzt:

- kanonische Spieler- und Produktvision,
- lokale RimWorld-Referenz `1.6.4566 rev575` mit fünf DLC-Manifests,
- Vanilla-/DLC-Systembaseline,
- fünf Paket-Blaupausen mit Artefaktzielen und Tasks,
- Blueprint-Execution-Contract und Blueprint-Index.

Nicht geändert hat sich die Laufzeitbeweislage: Es gibt weiterhin keine verifizierte Rimconemy-Gameplay-Implementierung und keine `SURVIVED`-Falsifizierungsberichte. Alle 19 Berichte bleiben deshalb `UNVERIFIED`. Die historischen Risiken werden durch die neuen Dokumente geplant adressiert, nicht als technisch gelöst behauptet.

## Executive Summary — Top-5 Risiken VOR der Konzept-/Spike-Phase

| # | Risiko | Severity | LOC-Impact | Phase-N-Blocker |
|---|--------|----------|------------|-----------------|
| 1 | Es fehlt ein kanonisches Domain-Modell für Waren, Produktion, Wallets, Outposts und Infektionsdruck; ohne dieses Modell drohen widersprüchliche Zustände zwischen Welt-, Outpost- und lokaler Map-Ebene. `[hyp]` | crit | nicht messbar — Repository leer (E1) | yes |
| 2 | „Echte Wirtschaft“ ist ohne klare Marktgrenzen, Geldschöpfung, Preisbildung, Eigentum und Logistikregeln nicht testbar definiert. `[hyp]` | crit | nicht messbar — Repository leer (E1) | yes |
| 3 | Der Spieler könnte bei vielen Outposts entweder mit Mikromanagement überlastet werden oder die Automatisierung als Black Box erleben. `[hyp]` | high | nicht messbar — Repository leer (E1) | yes |
| 4 | Eine globale Infizierten-Simulation kann bei naiver Kopplung an Pawn-/Map-Ticks die Performance und Save-Komplexität dominieren. `[hyp]` | high | nicht messbar — Repository leer (E1) | yes |
| 5 | Ressourcen- und Biome-Remapping ohne kanonische Setting-Taxonomie erzeugt tote Produktionsketten, Überschussressourcen oder fehlende Progressionspfade. `[hyp]` | high | nicht messbar — Repository leer (E1) | yes |

## TEIL A: Q1 — USER × UX (Spieler-Erleben)

### Evidenztabelle

| ID | Befund | Evidenz | Severity | Phase-Blocker |
|---|---|---|---|---|
| Q1-01 | Der Spieler-Loop für Outposts, Handel, Credits und Infizierte ist noch nicht festgelegt. | E3 `[brief]`; keine Implementierung (E1) | high | yes |
| Q1-02 | Automatisierung benötigt erklärbare Ziele, Engpässe und Blockadegründe. | `[hyp]` aus dem geforderten Automatisierungsmodell; kein UI-Code vorhanden (E1) | high | yes |
| Q1-03 | Markt-/Infektionsdaten brauchen eine Informationshierarchie statt einer unpriorisierten Zahlenansicht. | `[recommendation]`; kein UI-Code vorhanden (E1) | medium | yes |

### A1. Sichtbares Kernversprechen ist noch nicht als Spieler-Loop definiert

**Anforderung:** Survivor-Outposts, Handel, Credits, automatisierte Produktion und Infizierte sollen zusammen ein Survival-Spiel bilden. `[brief]`

**Lücke:** Es ist noch nicht festgelegt, welche Entscheidung der Spieler pro Tag/Woche trifft und woran Erfolg oder Scheitern sichtbar wird. `[hyp]`

**Risiko:** Der Spieler sieht viele Zahlen — Credits, Angebot, Nachfrage, Lager, Produktion, Infektionsdruck — aber nicht, welche davon handlungsrelevant sind. `[hyp]`

**Truth-Pass:** Der kanonische Loop ist inzwischen in [`../mods/PRODUCT_VISION.md`](../mods/PRODUCT_VISION.md) festgelegt. Die folgenden historischen Empfehlungen bleiben als UX-Prüfbegründung erhalten, sind aber kein offener Dokumentationsblocker mehr.

**Empfehlung:** Ein kanonischer Loop muss beschrieben werden:

```text
Bedarf erkennen → Priorität setzen → Ressourcen/Arbeitskraft zuweisen
→ Produktion/Logistik abwarten → Infektions-/Marktereignis bewerten
→ Strategie anpassen
```

### A2. Automatisierung braucht erklärbare Entscheidungen

**Empfehlung:** Ein Outpost, der „mehr oder weniger automatisch“ arbeitet, sollte mindestens anzeigen:

- aktuelles Ziel
- Produktionspriorität
- erwarteter Verbrauch
- Engpass
- Lagerreichweite
- Infektionsrisiko
- verwendete Credits
- nächster geplanter Schritt
- Grund für Abweichungen vom Plan

Ohne diese Erklärbarkeit wäre die Automatisierung für den Spieler nicht steuerbar. `[hyp]`

### A3. Wirtschaft benötigt eine klare Informationshierarchie

**Empfehlung:** Die UX sollte drei Ebenen anbieten:

1. **Sofort:** „Was fehlt jetzt?“
2. **Planung:** „Was wird in den nächsten Tagen knapp?“
3. **Analyse:** „Warum ist der Preis/Bestand so?“

Ein Marktbildschirm ohne Prognose, Ursache und Handlung wäre nur eine Statistikansicht. `[hyp]`

### A4. Infizierte müssen wirtschaftlich und räumlich lesbar sein

**Anforderung:** Die Infizierten sind der Hauptgegner. `[brief]`

**Empfehlung:** Der Spieler sollte erkennen können:

- betroffene Region
- Ausbreitungsrichtung
- Druck auf Handelsrouten
- bedrohte Outposts
- erwartete Produktionsausfälle
- Quarantäne-/Säuberungsoptionen

Andernfalls würde die Bedrohung wahrscheinlich nicht sinnvoll mit Wirtschaftsentscheidungen konkurrieren. `[hyp]`

### A5. Historischer UX-Phase-N-Blocker

Der damalige Blocker ist dokumentarisch adressiert; seine Laufzeit-/UI-Belege bleiben bis zur Implementierung offen.

Vor Implementierung fehlen:

- ein Player-Lifecycle-Diagramm
- ein Outpost-Dashboard-Wireframe oder textuelles UI-Schema
- eine Liste der minimalen Spielerentscheidungen
- Definitionen für „profitabel“, „versorgt“, „infiziert“, „kollabiert“ und „stabil“

## TEIL B: Q2 — USER × TECHNICAL (Spieler unter Last)

### Evidenztabelle

| ID | Befund | Evidenz | Severity | Phase-Blocker |
|---|---|---|---|---|
| Q2-01 | Last-, Save- und Recovery-Verhalten ist nicht messbar. | E1/E2: keine Implementierung, Tests oder Diagnostics | crit | yes |
| Q2-02 | Eine naive globale Simulation könnte den lokalen Spielthread überlasten. | `[hyp]`; kein Lastlauf vorhanden (E2) | high | yes |
| Q2-03 | Save-State und Transaktions-Recovery sind noch nicht spezifiziert. | `[hyp]`; kein Save-Schema vorhanden (E1) | high | yes |

### B1. Lastverhalten ist nicht messbar

**Beleg:** E1/E2. Es gibt keine Implementierung, keine Testdaten und keine Diagnostics-Ausgabe.

**Konsequenz:** Aussagen wie „die Wirtschaft läuft performant“ oder „200 Outposts funktionieren“ wären derzeit unbelegt.

### B2. [hyp] Globale Simulation könnte den lokalen Spielthread überlasten

Wenn jeder Outpost, jede Produktionskette, jeder Markt und jede Infektionszelle in jedem RimWorld-Tick vollständig berechnet wird, drohen möglicherweise:

- Tick-Verlust
- verzögerte UI-Antworten
- lange Welt-/Map-Übergänge
- schwer reproduzierbare Lastspitzen

**Empfehlung:** Die Phase-N-Anforderung ist ein getaktetes Simulationsmodell mit messbaren Budgets, nicht unbeschränktes Tick-Polling.

### B3. [hyp] Savegame-Größe und Save-Zeit können mit Outpost-/Markt-State wachsen

Zu spezifizieren sind mindestens:

- Outpost-ID und Position
- Bevölkerung/Kapazität
- Lager und Produktionsstatus
- Markt-/Preiszustand
- Wallet-Saldo und Transaktionshistorie oder Aggregat
- Handelsroute-/Lieferstatus
- Infektionsstatus
- Schema-Version

Ohne Aggregation und Schema-Versionierung könnte der Save-State unkontrolliert wachsen oder bei Änderungen unlesbar werden.

### B4. [hyp] Fehlende Recovery-UX wäre gefährlicher als ein sichtbarer Fehler

Bei fehlender Ware, ungültigem Rezept, gelöschtem Outpost oder abgebrochener Lieferung sollte das System:

- Transaktion zurückrollen oder als fehlgeschlagen markieren
- Ware nicht duplizieren oder still verlieren
- Wallet nicht doppelt belasten
- Outpost in einen bekannten Zustand zurücksetzen
- Diagnose für den Spieler und im Log ausgeben

### B5. Q2-Phase-N-Blocker

Vor einer großen Simulation benötigt das Projekt:

- deterministische Tick-/Step-Funktion
- Last-Szenario mit künstlichen Outposts und Produktionsketten
- Save-/Load-Runde
- Transaktions-Invarianten
- Diagnostics-Export für Preis, Lager, Wallet, Produktion und Infektionsdruck

## TEIL C: Q3 — CODER × UX (UI-Code-Pfad)

### Evidenztabelle

| ID | Befund | Evidenz | Severity | Phase-Blocker |
|---|---|---|---|---|
| Q3-01 | Es existiert noch kein Command-/Query- und Snapshot-Vertrag zwischen Simulation und UI. | E1: Repository leer | high | yes |
| Q3-02 | Eine zentrale God-Class ist ein plausibles Architektur-Risiko, aber kein bestehender Bug. | `[hyp]`; keine Implementierung vorhanden (E1) | high | yes |
| Q3-03 | Automationszustände und Blockadegründe sind noch nicht als gemeinsamer Vertrag definiert. | E3 `[brief]`; keine Implementierung (E1) | high | yes |

### C1. [hyp] Gefahr einer zentralen God-Class

Die fünf Domänen — Wirtschaft, Outposts, Infizierte, Ressourcen/Produktion und Biome — besitzen unterschiedliche Lebenszyklen. Eine gemeinsame `OverhaulManager`-Klasse mit Simulation, UI, Savegame und RimWorld-Hooks würde voraussichtlich untestbar und schwer handhabbar werden.

**Empfehlung:** UI sollte nur über Read-Modelle/Services auf Simulation-State zugreifen:

```text
Simulation State
   ↓
Selectors / Read Models
   ↓
UI View Models
   ↓
Windows, Tabs, Gizmos, World Overlays
```

### C2. UI und Simulation müssen getrennte Verantwortungen haben

**Empfehlung:** Die UI sollte nicht:

- Preise berechnen
- Produktionsaufträge direkt mutieren
- Credits buchen
- Infektionsfortschritt simulieren
- RimWorld-Defs global verändern

UI-Aktionen sollten Commands auslösen, deren Ergebnis die Simulation validiert und verbucht. `[hyp]`

### C3. Ein gemeinsamer Datenvertrag fehlt

Vor dem UI-Bau sollten mindestens folgende Typen/Verträge feststehen:

```text
OutpostId
ResourceId
ProductionChainId
WalletId
MarketId
InfectionZoneId

OutpostSnapshot
MarketSnapshot
WalletSnapshot
ProductionPlanSnapshot
InfectionSnapshot
```

Die UI sollte Snapshots lesen, nicht mutable Engine-Objekte direkt halten. `[recommendation]`

### C4. Automatisierung braucht Eingriffs- und Erklärungsverträge

Für jeden automatisierten Prozess sollten Code und UI dieselben Zustände kennen:

```text
Planned → Active → Blocked → Suspended → Completed → Failed
```

`Blocked` sollte einen Grundcode besitzen, z. B.:

- `MissingInput`
- `NoStorage`
- `RouteUnsafe`
- `InsufficientCredits`
- `InfectionQuarantine`
- `NoWorkforce`

### C5. Q3-Phase-N-Blocker

Vor UI-Implementierung fehlen:

- Command-/Query-Vertrag
- Snapshot-Modelle
- Zustandsmaschine für automatische Aufgaben
- Fehler-/Blockade-Codes
- ein UI-Informationsmodell für Outpost, Markt und Infektion

## TEIL D: Q4 — CODER × TECHNICAL (System-Stabilität)

### Evidenztabelle

| ID | Befund | Evidenz | Severity | Phase-Blocker |
|---|---|---|---|---|
| Q4-01 | Wirtschaftsinvarianten, persistente IDs und Save-Schema sind noch nicht definiert. | E1: kein Code oder Schema vorhanden | crit | yes |
| Q4-02 | Zeit-Synchronität zwischen globaler Simulation, unloaded Maps und aktiver Map ist noch ungeklärt. | E3 `[brief]`; keine technische Entscheidung dokumentiert | crit | yes |
| Q4-03 | Logistik-Paradigma und Vanilla-Isolation sind noch ungeklärt. | E3 `[brief]`; keine technische Entscheidung dokumentiert | crit | yes |
| Q4-04 | Setting-Ressourcen-Taxonomie und Biomprofile fehlen. | E3 `[brief]`; keine Matrix vorhanden | high | yes |

### D1. [hyp] Wirtschaftsinvarianten sind noch nicht definiert

Eine echte Wirtschaft braucht vor Code mindestens überprüfbare Invarianten:

```text
Credits entstehen nur durch definierte Quellen.
Credits verschwinden nur durch definierte Senken.
Eine Transaktion ist atomar: Ware und Credits ändern sich gemeinsam.
Eine Lieferung kann nicht zweimal verbucht werden.
Ein Preis ist aus dokumentierten Inputs reproduzierbar.
Ein Marktbestand kann nicht negativ werden, außer ein explizites Schuldenmodell erlaubt es.
```

Ohne Invarianten kann ein Fehler wie Geldduplizierung unbemerkt bleiben.

### D2. [hyp] Identität muss unabhängig von RimWorld-Objektreferenzen sein

Outposts, Waren, Verträge, Wallets und Transaktionen benötigen persistente IDs. Direkte Objekt-Referenzen als Primäridentität wären für Savegames, Migration und Wiederherstellung riskant.

Empfohlenes Grundschema:

```text
OutpostId: stable integer or serialized string
ResourceId: canonical setting identifier
TransactionId: monotonic/serialized identifier
WalletId: stable owner identifier
```

### D3. [hyp] Zeit-Synchronität ist ein eigener Architekturblocker

Vor der Ressourcenmatrix muss entschieden werden, wie globale Simulation, unloaded Maps und die aktive Map zeitlich gekoppelt sind. Eine Matrix allein reicht nicht aus, wenn eine globale Lieferung und eine lokale Map nicht dieselbe Zeitbasis verwenden.

### D4. [hyp] Logistik benötigt ein klares Transport-Paradigma

Vor der Implementierung muss entschieden werden, ob Waren:

- physisch über Vanilla-Karawanen transportiert werden,
- als abstrakte Welttransaktionen mit Verzögerung laufen,
- oder je nach Warenklasse beide Modelle verwenden.

Diese Entscheidung bestimmt, ob Infizierte Handelsrouten physisch blockieren oder als Risiko-/Wahrscheinlichkeitsmodell wirken.

### D5. [hyp] Vanilla-Isolation muss festgelegt werden

Vanilla-KI, Rezepte und Events können Kernressourcen voraussetzen. Vor einem Ressourcen-Remap muss entschieden werden, ob Vanilla-Defs direkt ersetzt werden oder ob ein Mapping-/Adapter-Layer zwischen Setting-Ressourcen und Vanilla-Ausgaben liegt.

### D6. [hyp] Determinismus ist für Replay, Debugging und späteres Multiplayer wichtig

Auch wenn zunächst nur Singleplayer geplant wird, sollte die globale Simulation deterministisch sein:

- definierte Step-Reihenfolge
- keine Uhrzeit als Spielinput
- kein unkontrolliertes `System.Random`
- expliziter Seed/Random-Stream
- keine Mutation während UI-Lesen
- keine unkontrollierten Hintergrundthreads für Spielzustand

### D7. [hyp] Setting-Remapping benötigt eine kanonische Ressourcen-Taxonomie

„Ressource remappen“ darf nicht nur bedeuten, Holz in einen anderen Namen umzubenennen. Es braucht eine Tabelle:

| Setting-Ressource | Quelle/Erzeugung | Verarbeitung | Verbraucher | Lagerklasse | Ersatz/Alternative |
|---|---|---|---|---|---|
| Rohstoff | Biome/Outpost | Produktionsstufe 1 | Bau/Industrie | Item/abstrakt | definiert |

Jede Ressource braucht mindestens:

- eindeutige ID
- Einheit
- Verderb/Decay-Regel
- Quelle
- Senke
- Transportvolumen
- Produktionszeit
- Marktrolle
- Settingname

### D8. [hyp] Biome-Remapping kann Produktionsketten unspielbar machen

Wenn ein Biom keine Nahrung, kein Wasser-/Medizinäquivalent, keinen Brennstoff oder keine Reparaturressource erzeugt, wird es entweder sofort unspielbar oder nur durch zufällige Handelsdrops versorgt.

Jedes Biom benötigt daher ein Ressourcenprofil:

```text
FoodPotential
WaterPotential / hydration equivalent
FuelPotential
BuildingMaterialPotential
MedicalPotential
Metal/ComponentPotential
ThreatPotential
TravelCost
```

### D9. Q4-Phase-N-Blocker

Vor einer produktiven Mod-DLL müssen feststehen:

- persistente IDs
- Save-Schema und Migration
- Transaktionsinvarianten
- deterministischer Simulation-Step
- Zeit-Synchronitätsvertrag
- Logistik-Paradigma
- Vanilla-Isolationsstrategie
- Ressourcen-Taxonomie
- Outpost-/Markt-/Infektions-State-Maschine
- Fehler- und Rollback-Verhalten

## TEIL E: Risiko-Heatmap & empfohlene Reihenfolge (Phase N → Phase N+1)

| Rang | Risiko/Entscheidung | Severity | Begründung | Empfohlene Phase |
|---:|---|---|---|---|
| 1 | Zeit-Synchronität zwischen globalem State, unloaded Maps und aktiver Map | crit | Ohne gemeinsame Zeitbasis sind Wirtschaft, Logistik und Infektionsdruck nicht reproduzierbar | Konzept 1 |
| 2 | Logistik-Paradigma: physisch, abstrakt oder hybrid | crit | Bestimmt Warenfluss, Infiziertenwirkung, UI und Save-State | Konzept 1 |
| 3 | Domain-Modell und Zustandsgrenzen | crit | Verhindert widersprüchliche Zustände zwischen Welt, Outpost und Map | Konzept 1 |
| 4 | Wirtschaftsregeln und Transaktionsinvarianten | crit | Ohne sie sind Credits, Preise und Handel nicht verifizierbar | Konzept 2 |
| 5 | Vanilla-Isolationsstrategie beim Ressourcen-Remapping | high | Verhindert, dass Vanilla-KI/Rezepte und Setting-Wirtschaft auseinanderlaufen | Konzept 2 |
| 6 | Ressourcen-/Produktionsketten-Matrix | high | Verhindert tote oder zyklisch unlösbare Progression | Konzept 3 |
| 7 | Outpost-Automation als erklärbare Zustandsmaschine | high | Verhindert Black-Box-Automation und UI-/Simulationsdrift | Konzept 4 |
| 8 | Infektionsmodell und globale/lokale Übergänge | high | Verbindet Bedrohung mit Wirtschaft und Map-Gameplay | Konzept 5 |
| 9 | Biome-Profile und World-Generation-Inputs | high | Verhindert settingwidrige oder unversorgbare Startregionen | Konzept 6 |
| 10 | Technischer Spike mit Save/Load und Diagnostics | crit | Der erste Beweis, dass die Architektur in RimWorld tragfähig ist | Spike 1 |
| 11 | UI und Komfortfunktionen | medium | Erst sinnvoll, wenn Snapshots und Commands stabil sind | Spike 2 |

### Top-3-Budgetprioritäten

Diese drei Risiken erhalten das erste Konzeptbudget, bevor weitere Detailplanung beginnt:

| Priorität | Entscheidung | Ergebnis | Geschätzter Aufwand |
|---|---|---|---|
| 1 | Zeitbasis und Catch-up-Verhalten | World-Step-Vertrag für globale Simulation, unloaded Maps und aktive Map | 0,5–1 Tag |
| 2 | Transportmodell | physischer, abstrakter oder hybrider Warenfluss mit Infiziertenwirkung | 0,5 Tag |
| 3 | Vanilla-Isolationsstrategie | klare Grenze zwischen Setting-Ressourcen und Vanilla-KI/Defs/Events | 0,5–1 Tag |

**Budgetregel:** Ressourcenmatrix, Produktionsketten und UI-Detailplanung beginnen erst nach diesen drei Entscheidungen.

### Niedrigere Prioritäten / späterer Budgetblock

Die folgenden Punkte bleiben wichtig, sind aber nach den Top-3 zu bearbeiten:

- Wirtschaftsformeln und Preisparameter
- vollständige Ressourcen-/Produktionsmatrix
- Outpost-Automation und Blockadegründe
- Infektionsausbreitung und lokale Materialisierung
- Biome-Profile und World-Generation
- UI-Komfort und Visualisierung

### Empfohlene Projektphasen

```text
Phase 0: Canonical vocabulary + design constraints
Phase 1: Time contract + logistics paradigm + vanilla isolation
Phase 2: Domain model + IDs + invariants
Phase 3: Resource and production matrix
Phase 4: Abstract market/wallet simulation
Phase 5: Outpost state and automation
Phase 6: Infection pressure and local materialization
Phase 7: Biome/resource remap
Phase 8: RimWorld integration spike
Phase 9: UI, balance, compatibility and content expansion
```

### Root-Cause-Cluster

1. **Zeit ↔ Wirtschaft ↔ Logistik:** Wenn globale und lokale Ebenen unterschiedliche Zeit-/Catch-up-Regeln verwenden, sind Preise, Lieferungen und Infektionsdruck nicht reproduzierbar. `[hyp]`
2. **Logistik ↔ Infizierte ↔ UX:** Das Transport-Paradigma entscheidet, ob der Spieler eine physische Bedrohung, eine abstrakte Risikowahrscheinlichkeit oder einen Hybrid erlebt. `[hyp]`
3. **Wirtschaft ↔ UI ↔ Stabilität:** Wenn Preise/Wallets keine Invarianten haben, kann die UI zwar Zahlen anzeigen, aber nicht erklären, ob diese korrekt sind. `[hyp]`
4. **Outpost-Automation ↔ UX ↔ Savegame:** Wenn automatische Aufträge keine expliziten Zustände und IDs haben, sind Blockaden für Spieler und Save-Migration schwer nachvollziehbar. `[hyp]`
5. **Infizierte ↔ Performance ↔ Biome:** Eine zu fein aufgelöste globale Infektionssimulation könnte Last erzeugen, während ein zu grobes Biommodell keinen sinnvollen Einfluss auf Versorgung hat. `[hyp]`
6. **Ressourcen ↔ Produktion ↔ Handel:** Wenn jede Ressource lokal und global anders definiert wird, entstehen Preis-, Lager- und Transport-Divergenzen. `[hyp]`

## Historischer Abschnitt — Definition of Done für Phase N+1 (ersetzt)

Die folgende Liste war die damalige Übergabeanforderung. Sie ist durch `PRODUCT_VISION.md`, `BLUEPRINT_EXECUTION_CONTRACT.md`, `BLUEPRINT_INDEX.md` und `VANILLA_DLC_RESEARCH_BASELINE.md` ersetzt; sie bleibt ausschließlich zur Rückverfolgbarkeit erhalten.

Phase N+1 ist **Konzept-/Domain-Spezifikation**, nicht Implementierung. Sie ist fertig, wenn:

- [ ] die Zeitbasis für globale Simulation, unloaded Maps, aktive Map und Catch-up-Verhalten entschieden ist;
- [ ] das Logistik-Paradigma (physisch, abstrakt oder hybrid) mit Warenklassen und Infiziertenwirkung festgelegt ist;
- [ ] die Vanilla-Isolationsstrategie für Ressourcen, Rezepte, KI und Events entschieden ist;
- [ ] eine kanonische Begriffsliste für `Resource`, `Good`, `Recipe`, `Outpost`, `Market`, `Wallet`, `Contract`, `Route`, `InfectionZone` und `BiomeProfile` existiert;
- [ ] jede Domäne einen Owner für ihren Zustand und eine klare Read-/Write-Grenze besitzt;
- [ ] mindestens ein vollständiger Produktionspfad vom Biom/Rohstoff bis zu einem Endverbraucher dokumentiert ist;
- [ ] Credits-Quellen und -Senken vollständig aufgelistet sind;
- [ ] die Transaktionsinvarianten in prüfbarer Form stehen;
- [ ] der Preisbildungsmechanismus mit Inputs, Step-Reihenfolge und Grenzen beschrieben ist;
- [ ] ein Outpost-Automationszyklus mit `Planned`, `Active`, `Blocked`, `Suspended`, `Completed` und `Failed` definiert ist;
- [ ] ein Infektionszyklus zwischen globaler Zone und lokaler Map beschrieben ist;
- [ ] jedes geplante Biom ein Ressourcen- und Bedrohungsprofil besitzt;
- [ ] Savegame-Schema, IDs und mindestens eine Migrationsregel definiert sind;
- [ ] mindestens ein Lastszenario spezifiziert ist: Outpost-Anzahl, Warenanzahl, Marktanzahl, Simulationsschritte und erwartetes Zeitbudget;
- [ ] ein Diagnostics-Exportformat für Markt, Wallet, Produktion, Outpost und Infektion definiert ist;
- [ ] der RimWorld-Integrations-Spike erst danach als eigener, begrenzter Auftrag formuliert wird.

## Historischer Abschnitt — Audit-Entscheidung (ersetzt)

Die folgende Entscheidung war zum damaligen Auditstand offen. Die Produktvision und Paket-Blaupausen haben den Konzeptteil inzwischen geschlossen; Laufzeitbelege und API-Spikes bleiben offen.

Der vollständige Code-/Last-Audit ist wegen E1/E2 abgebrochen. Die Architektur-Assessment empfiehlt, vor der Ressourcenmatrix zuerst zwei physikalische Verträge zu entscheiden: **Zeit-Synchronität** und **Logistik-Paradigma**. Erst danach sind Domain-Modell, Wirtschafts-Invarianten und Ressourcen-/Produktionsmatrix belastbar.

### Eine scharfe Entscheidung

Wenn wir nur eine Entscheidung als Nächstes treffen, sollten wir Zeitbasis und Transportmodell gemeinsam festlegen — insbesondere: **Läuft die globale Outpost-/Wirtschaftssimulation über einen abstrakten World-Step mit Catch-up, und werden Handelsgüter physisch, abstrakt oder hybrid transportiert?**

**Bestätigst du dieses Vorgehen als Phase-N+1?** Für die schriftliche Entscheidungsspezifikation rechne ich mit ungefähr **1–2 Arbeitstagen**; erst danach sollte der begrenzte RimWorld-Integrations-Spike beginnen. Ohne diese Entscheidung wäre weitere Wirtschafts- oder Ressourcenplanung Architektur ohne definierte Zeit- und Warenbewegung.
