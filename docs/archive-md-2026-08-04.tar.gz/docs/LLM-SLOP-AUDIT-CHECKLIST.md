# LLM-Slop-Audit: Prüfliste

> **Erstellt:** 2026-08-04  
> **Basis:** Buffy Audit-Bericht (Foren-Recherche + Code-Audit + Architektur-Analyse)  
> **Status:** Offen — jeder Punkt einzeln prüfen und schließen

---

## Legende

| Symbol | Bedeutung |
|--------|-----------|
| ⬜ | Offen |
| ✅ | Geprüft & bestanden |
| ❌ | Geprüft & fehlgeschlagen — Fix nötig |
| ⏭️ | Übersprungen (nicht anwendbar) |
| 🔴 | Kritisch — sofortiger Fix |
| 🟡 | Mittel — im nächsten Sprint |
| 🟢 | Niedrig — kann warten |

---

## A. Tautologische Tests (KRITISCH)

> **Problem:** Tests verifizieren dass Code das tut was Code tut — nicht was Code soll.

| # | Prüfpunkt | Datei | Status | Notizen |
|---|-----------|-------|--------|---------|
| A1 | `TestDeterministicRng_StableSequence` — prüft ob Re-Seeding gleiche Werte liefert. Das beweist nur Determinismus, nicht Korrektheit. **Mutation:** Ändere Splitmix64-Konstanten — überlebt der Test? | `StorySelectorTests.cs:260` | ⬜ | |
| A2 | `TestDeterministicRng_NextInt_Uniform` — 700 Samples auf 7 Buckets. "At least some hits" ist statistisch garantiert. **Fehlt:** Chi-Quadrat-Test oder KL-Divergenz gegen Gleichverteilung | `StorySelectorTests.cs:285` | ⬜ | |
| A3 | Determinismus-Tests (Refuge/Survival/Collapse) — rufen `SelectEvent` mit identischen Inputs auf. **Fehlt:** Test der prüft ob Events *sinnvoll* sind (z.B. SupplyShortage bei leerem Lager) | `StorySelectorTests.cs:100-160` | ⬜ | |
| A4 | Idempotency-Tests — prüfen ob zweiter Aufruf blockiert wird. **Fehlt:** Test ob nach Save/Load der Key *wirklich* persists (nicht nur Hash-Ähnlichkeit) | `StorySelectorTests.cs:165-210` | ⬜ | |
| A5 | **Mutation-Test-Setup fehlt** — kein mutmut/Stryker-Integration. Ohne Mutations-Testing kann nicht verifiziert werden, dass Tests etwas beweisen | Projektübergreifend | ⬜ | |

### Empfohlener Aktion für A1-A5

```
Für jeden Test:
1. Test ausführen → muss grün sein
2. Erwarteten Wert im Test ändern → muss rot werden
3. Implementation ändern (Bug einführen) → muss rot werden
4. Wenn 2 oder 3 nicht rot wird: Test ist tautologisch
```

---

## B. Stubs als "Fertig" getarnt (KRITISCH)

> **Problem:** Code sieht implementiert aus, ist aber ein No-Op oder Placeholder.

| # | Prüfpunkt | Datei | Status | Notizen |
|---|-----------|-------|--------|---------|
| B1 | `InfectedRaidWorker.TryExecuteWorker` gibt `true` zurück, spawnt aber keine Raids. **Prüfen:** Ist das beabsichtigt (Phase 1 MVP) oder ein vergessener Stub? | `InfectedRaidWorker.cs:45` | ⬜ | |
| B2 | `InfectedRaidWorker.TryExecuteWorker` sendet Letter mit Fallback-Text: `"A Rimconemy story event has occurred."` **Prüfen:** Wann wird dieser Fallback ausgelöst? | `InfectedRaidWorker.cs:52` | ⬜ | |
| B3 | `CreditsLedger` — 15 Datenfelder, keine Methoden. **Prüfen:** Gibt es eine externe Klasse die die Logik implementiert? | `CreditsLedger.cs` | ⬜ | |
| B4 | `GameOverDetector` — `IsPlayerColonist` und `CountPlayerColonists` sind Trivial-Wrapper. **Prüfen:** Werden diese Methoden überhaupt aufgerufen? | `GameOverDetector.cs` | ⬜ | |
| B5 | `StoryEventCatalog` — 3 hardcoded Events. **Prüfen:** Laut Decision 3 sollen Events XML-geladen werden. Wo ist die XML-Integration? | `StoryEventCatalog.cs` | ⬜ | |

---

## C. Fake-StorageHash (KRITISCH)

> **Problem:** Story Writer soll auf Ressourcenmangel reagieren, aber der Snapshot liefert immer `false`.

| # | Prüfpunkt | Datei | Status | Notizen |
|---|-----------|-------|--------|---------|
| C1 | `snapshot.StorageHash = "live-" + tick.ToString()` — ist ein Platzhalter. **Prüfen:** Wann wird dieser durch `StorageQuery.ReadStorage()` ersetzt? | `StoryDirector.cs:283` | ⬜ | |
| C2 | `snapshot.AnyResourceCritical = false` — hardcoded. **Prüfen:** Gibt es einen Config-Parameter oder Threshold der diese Flag steuert? | `StoryDirector.cs:284` | ⬜ | |
| C3 | `StorySelector` prüft `AnyResourceCritical`? **Prüfen:** Wenn `false`, werden dann Events nie basierend auf Ressourcenmangel ausgelöst? | `StorySelector.cs` | ⬜ | |
| C4 | Decision 4 sagt "Echter Snapshot" — Code sagt "Placeholder". **Prüfen:** Wer hat recht? | `DECISIONS.md` vs `StoryDirector.cs` | ⬜ | |
| C5 | `CriticalFoodThreshold`, `CriticalMedicineThreshold`, `CriticalMaterialThreshold` aus Decision 14 — **Prüfen:** Sind diese Werte irgendwo im Code definiert? | `I-T1` | ⬜ | |

---

## D. Duplizierte Pawn-Filterung (MITTEL)

> **Problem:** 5 verschiedene Stellen filtern Pawns unterschiedlich, trotz zentralem `ColonialReader`.

| # | Prüfpunkt | Datei | Status | Notizen |
|---|-----------|-------|--------|---------|
| D1 | `StoryDirector.BuildLiveSnapshot` Zeile 300 — eigene Enumeration statt `ColonialReader` | `StoryDirector.cs:300` | ⬜ | |
| D2 | `StoryDirector.MaybeSignalGameOverForWipe` — eigene Enumeration | `StoryDirector.cs:355` | ⬜ | |
| D3 | `ProgressionPawnTab` — `IsColonist && !Dead` | `ProgressionPawnTab.cs:56` | ⬜ | |
| D4 | `ThoughtWorker_ResourceFairness` — `!pawn.IsColonist \|\| pawn.Dead` (invertierte Logik!) | `ThoughtWorker_ResourceFairness.cs:39` | ⬜ | |
| D5 | `ProgressionGameComponent.IsDirectlyControlledColonist` — nutzt `ColonialReader` ✓, aber `UpdateRuntimeState` hat eigenen Grace-Counter | `ProgressionGameComponent.cs:280` | ⬜ | |

### Filter-Vergleich

| Stelle | IsColonist | !Dead | !DestroyedOrNull | Humanlike | Dedup |
|--------|-----------|-------|-------------------|-----------|-------|
| ColonialReader | ✅ | ✅ | ✅ | ✅ | ✅ |
| StoryDirector (2 Stellen) | ✅ | ✅ | ❌ | ❌ | ❌ |
| ProgressionPawnTab | ✅ | ✅ | ❌ | ❌ | ❌ |
| ThoughtWorker | ✅ | inverted | ❌ | ❌ | ❌ |
| GameOverDetector | ✅ | ❌ | ❌ | ❌ | ❌ |

---

## E. Dead Code / Irreführende Namen (MITTEL)

| # | Prüfpunkt | Datei | Status | Notizen |
|---|-----------|-------|--------|---------|
| E1 | `TryApplyThreatDrivenXpBoost` — prüft Capability, loggt Status, wendet aber keinen Boost an. Name ist irreführend | `ProgressionGameComponent.cs:320` | ⬜ | |
| E2 | `ClassifyJob` — FIXME-Kommentar seit Beginn: "Job classification via Substring is fragile" | `ProgressionGameComponent.cs:325` | ⬜ | |
| E3 | `StoryDirector.QueueSelectedIncident` — null-Check nach `TryFire` ist toter Code (TryFire gibt nie null zurück) | `StoryDirector.cs:310` | ⬜ | |

---

## F. Magic Numbers / Hardcoded Werte (MITTEL)

| # | Prüfpunkt | Datei | Status | Notizen |
|---|-----------|-------|--------|---------|
| F1 | `wealthFactor / 700000f` — Normalisierungskonstante ohne Dokumentation | `StoryDirector.cs:278` | ⬜ | |
| F2 | `ExperiencePerWorkSample = 0.25f` — woher kommt dieser Wert? | `ProgressionGameComponent.cs:24` | ⬜ | |
| F3 | `EvaluationIntervalTicks = 60000` (1 Tag) vs `MinEventSpacingTicks = 30000` (0.5 Tage) — Verhältnis 2:1. Ist das beabsichtigt? | `StoryDirector.cs:25-28` | ⬜ | |
| F4 | `EmptyColonistGraceIntervals = 12` → 3,000 ticks ≈ 50 Sek. **Prüfen:** Reicht das für Caravan-Reisen? | `ProgressionGameComponent.cs:29` | ⬜ | |

---

## G. Kommentar-Logik-Lücke (NIEDRIG)

| # | Prüfpunkt | Datei | Status | Notizen |
|---|-----------|-------|--------|---------|
| G1 | StoryDirector: Kommentar beschreibt "force-fire" via incidentQueue — Code ist einfaches `TryFire`. Stimmt die Beschreibung? | `StoryDirector.cs:300-320` | ⬜ | |
| G2 | StoryDirector: "Phase 2 follow-up: MarkExecuted into the worker" — ist das noch aktuell? | `StoryDirector.cs:315` | ⬜ | |
| G3 | StoryDirector: "Audit caveat (2026-08-04): FiringIncident.source NPE" — wurde das getestet? | `StoryDirector.cs:305` | ⬜ | |

---

## H. DECISIONS.md Drift (KRITISCH)

> **Problem:** Entscheidungen sind als "✅ entschieden" markiert, obwohl der Code sie nicht abdeckt.

| # | Decision | Behauptung | Code-Wahrheit | Status |
|---|----------|------------|---------------|--------|
| H1 | #4 StorageHash | "Echter Snapshot" | `"live-" + tick` Placeholder | ⬜ |
| H2 | #3 XML-Event-System | "Events in XML-Defs" | 3 hardcoded Events in C# | ⬜ |
| H3 | #13 Event-Variablen | "11+ Variablen pro Event" | Nur LetterLabel + LetterText | ⬜ |
| H4 | #14 Schwellenwerte | "CriticalFoodThreshold = 0.2f" | Keine Schwelle im Code | ⬜ |
| H5 | #1 Need-System | "Adapter-Pattern" | `ReadNeedPercentage` in ProgressionGameComponent | ⬜ |
| H6 | #5 Markt/Preise | "Market.cs" | Nur `CreditsLedger` (Data-Record) | ⬜ |

---

## I. Architektur-Risiken (Übersicht)

| # | Risiko | Beschreibung | Status |
|---|--------|--------------|--------|
| I1 | StorageHash-Platzhalter | Story Writer kann nicht auf Ressourcenmangel reagieren | ⬜ |
| I2 | Raid-Stub | InfectedRaidWorker spawnt keine Raids — Bedrohung ist Letter-only | ⬜ |
| I3 | XP-Boost No-Op | Cross-Package-Integration deklariert aber nicht funktional | ⬜ |
| I4 | Reflection-Bridge | `CrossPackageState.TryReadStoryGameOverPending` ist fragil | ⬜ |
| I5 | Vanilla-Raids | "NOT deactivated" — aber wie interagiert das mit StoryDirector? | ⬜ |

---

## Abschluss-Checkliste

| # | Aktion | Verantwortlich | Fällig |
|---|--------|---------------|--------|
| 1 | Mutation-Testing-Setup (mutmut/Stryker) | Coder | Vor nächstem Sprint |
| 2 | Tautologische Tests rewrite (A1-A5) | Coder | Vor nächstem Sprint |
| 3 | StorageHash-Bridge implementieren (C1-C5) | Coder | I-T1 |
| 4 | Pawn-Filterung konsolidieren (D1-D5) | Coder | F-T3 |
| 5 | Dead Code entfernen / umbenennen (E1-E3) | Coder | |
| 6 | DECISIONS.md gegen Code abgleichen (H1-H6) | Buffy | Dieser Sprint |
| 7 | InfectedRaidWorker erweitern (B1-B2) | Coder | Phase 5+ |

---

## Metriken

| Metrik | Wert |
|--------|------|
| Gesamtprüfpunkte | 42 |
| 🔴 Kritisch | 15 |
| 🟡 Mittel | 14 |
| 🟢 Niedrig | 3 |
| ⏭️ Nicht anwendbar | 0 |
| Offen | 42 |
| Abgeschlossen | 0 |
