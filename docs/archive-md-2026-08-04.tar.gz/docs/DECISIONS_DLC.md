# DLC Decision Matrix (2026-08-04)

**Status:** Locked-in nach Audit-Round-4 + User-Confirm. Single Source of Truth für Phase 7+ DLC-Patch-Layer.

## Architektur-Prinzip: Opt-In statt Opt-Out

Rimconomy kontrolliert welche RimWorld-DLC-Inhalte aktiv sind — nicht RimWorld-Defaults. Jedes DLC wird im Default-Modus gestoppt und Rimconomy explicit-enabled genau die Teile die das Setting braucht. Konsequenz: ein einziger zentraler Gate (`Foundation.DLC.DLCFilter`) entscheidet; alle fünf Pakete fragen ihn, niemand greift direkt auf `ModsConfig.RoyaltyActive` zu.

Technische Folgen:
- `mods/01-Rimconemy-Foundation/Source/DLC/DLCFilter.cs` ist die Single Source of Truth.
- Capability `rimconemy.foundation.dlc_filter` v1 registriert die Verfügbarkeit des Gates.
- Patch-Layer in `mod/01-Rimconemy-Foundation/Patches/*.xml` wickelt DLC-Suppressions via `<Operation Class="PatchOperationFindMod">`.
- Konsumenten (Mod 02–05) rufen `DLCFilter.IsContentEnabled(contentId)` mit stable string-Keys; niemals direkten DLC-Property-Zugriff.

---

## Blockierende Entscheidungen (Lock 2026-08-04)

### F1: Anomaly = Hard-Require

- About.xml `<modDependencies>` für `Ludeon.RimWorld.Anomaly`.
- Mod 05 `InfectedPawnKind.ParentName` = `Anomaly_Shambler` (erbt Hediffs + Textures + Flee-Behavior).
- `InfectedRaidWorker.TryExecuteWorker` spawnt Shambler-Kinder statt vanilla PawnKinds.
- Ohne Anomaly: Mod 05 lädt nicht, klare Fehlermeldung im Mod-Manager.

**Begründung:** Anomaly ist nicht Dekoration sondern genetische Basis der Rimconemy-Infected. Opt-In mit Fallback-Pflege würde doppelten Code-Test-Aufwand für verschlechterte Spielerfahrung erzeugen. Hard-Require ist ehrlicher.

### F2: Odyssey = Hard-Require

- About.xml `<modDependencies>` für `Ludeon.RimWorld.Odyssey`.
- Mod 04 `OutpostWorldObject` extendiert `Odyssey_Gravship` (WorldObject mit Gravship-Lifecycle).
- `TerritoryNode` wird zu GravShip-State-Tracker statt abstrakter Graph-Knoten.
- Etwa 240 Zeilen Code-Ersparnis beim Territory-Graph selbst.
- Ohne Odyssey: Mod 04 lädt nicht.

**Begründung:** Territory-Mechanismus IST der Gravship. Ohne Odyssey = kein Territory-System das den Rimconemy-Spielstil trägt. Fallback-Pfad wäre Wartungsfall ohne Nutzen.

### F3: Royalty = Suppress-Installed

- About.xml KEIN modDependencies-Eintrag.
- 3 Patch-XML deaktivieren:
  1. `Royalty_StorytellerComps.xml` — baseChance=0 auf Bestower-Shuttle.
  2. `Royalty_Incidents.xml` — baseChance=0 auf alle Royal-Psylink-Incidents.
  3. `Royalty_Psycasts.xml` — `Need_NeuralHeat` disabled=true, Psycast-TraitDefs rauspatchen.
- FoundationSaveData zeigt beim Save-Load: "Royalty detected — content suppressed by Rimconomy."
- Vergebliche Patches ohne RimWorld-Install sind no-ops.

**Begründung:** Royalty ist kein Träger. Kein Rimconomy-Code nutzt Royalty-Assets. Suppression ist ehrliche Asymmetrie: Träger = Hard-Require, Störenfried = Suppress.

---

## Schwächere Entscheidungen (Lock 2026-08-04)

### F4: Biotech = Mostly Suppress-Installed

- Mechanitor + Mech-Gestator: deaktiviert via `Biotech_DisableMechSystem.xml`.
- Children-System: deaktiviert via `Biotech_DisableChildren.xml`.
- Pollution: suppressed by default (`DLCFilter.IsContentEnabled("biotech.pollution")` = false). Optional später über FoundationSaveData-Toggle aktivierbar.
- Genome-Editing + Toxifier Generator: suppressed.
- Mechadroids eigenen PawnKind (siehe F1) statt Biotech-Mechanoid-Bandwidth.

### F5: Ideology = Trim-UX

- PreceptDef / ThoughtDef / ThoughtWorker bleiben aktiv (technischer Träger).
- Ideoligion-Founder-Screen deaktiviert via `Ideology_RemovePlayerUI.xml`.
- Ritual-Performer-UI deaktiviert.
- Player-Edit-Ideology disabled.
- `IdeologyAssigner` weist Rimconemy-Setting-Ideologie auto zu (Rimconfemy_Ideo_Survival/Refuge/Collapse).

---

## DLC Content-IDs (registry strings für Code + Patches)

| Content-ID | Aktiv? | Quelle |
|---|---|---|
| `royalty.psycasts` | ❌ nein | F3 |
| `royalty.shuttles` | ❌ nein | F3 |
| `royalty.imperial` | ❌ nein | F3 |
| `biotech.mechanitor` | ❌ nein | F4 |
| `biotech.children` | ❌ nein | F4 |
| `biotech.pollution` | ❌ nein (toggleable) | F4 |
| `anomaly.shamblers` | ✅ wenn Anomaly aktiv | F1 |
| `anomaly.entities` | ❌ nein | F1 |
| `anomaly.hold` | ❌ nein | F1 |
| `odyssey.gravship` | ✅ wenn Odyssey aktiv | F2 |
| `odyssey.fishing` | ❌ nein | F2 |
| `ideology.player_founder` | ❌ nein | F5 |
| `ideology.ritual_ui` | ❌ nein | F5 |

---

## Item-Inventur (Architektur-Defaults)

### Strukturen

| Item | Status | Pfad |
|---|---|---|
| Wall | behalten + Cost→Bauschutt | `Patches/ConstructionCosts.xml` |
| Door | behalten + Cost→Bauschutt | `Patches/ConstructionCosts.xml` |
| Sandbag | behalten | vanilla |
| Barricade | behalten | vanilla |
| Barbed Wire | behalten | vanilla |
| Embrasure (Ideology) | behalten | vanilla |

### Power

| Item | Status | Pfad |
|---|---|---|
| Solar Panel | behalten | vanilla |
| Wind Turbine | behalten | vanilla |
| Geothermal Generator | behalten | vanilla |
| Battery | behalten | vanilla |
| Rimconemy_WoodCoalGenerator | aktiv (Mod 03) | BuildingDefs |
| Rimconemy_WaterTurbineGenerator | aktiv (Mod 03) | BuildingDefs |
| Rimconemy_TurbineWaterPump | aktiv (Mod 03) | BuildingDefs |
| Toxifier Generator (Biotech) | suppressed | F4 |

### Production

| Item | Status |
|---|---|
| Crafting Spot / Smithy / Smelter | vanilla |
| Drug-Labs + Growing Zones | vanilla, Hanf-Resource-Patch |
| Fueled Smithy | vanilla |
| Mech Gestator (Biotech) | suppressed |
| Bioferrite Processor (Anomaly) | suppressed |
| Fishing Dock (Odyssey) | suppressed |

### Sicherheit

| Item | Status |
|---|---|
| Turret_MiniTurret | behalten, parallel zu Rimconemy_ArrowTurret_Power |
| Rimconemy_ArrowTurret_Power | aktiv (Mod 03) |
| IED Traps / Spike Traps | behalten, vanilla |
| Ballista (Royalty) | suppressed |

---

## Implementation-Reihenfolge (Sprint-Plan)

```
Tag 1 (heute):
  ✓ docs/DECISIONS_DLC.md                ← dieses Dokument
  → Foundation/Source/DLC/DLCFilter.cs   ← central gate
  → Foundation/Source/Registry/PackageRegistry.cs   ← new capability
  → Foundation/About/About.xml            ← Hard-Require für Anomaly + Odyssey

Tag 2:
  → 7 Patch-XML in Foundation/Patches/
       Royalty_Disable.xml                  (3 Sub-Patches konsolidiert)
       Ideology_RemovePlayerUI.xml
       Biotech_DisableMechSystem.xml
       Biotech_DisableChildren.xml
       Anomaly_KillEntities.xml
       Anomaly_Hold.xml
       Odyssey_KillExceptGravship.xml

Tag 3 (Mod 05):
  → InfectedPawnKind.ParentName = "Anomaly_Shambler"
  → InfectedRaidWorker spawnt Shambler-Kinder

Tag 4 (Mod 04):
  → TerritoryNode → GravShip-State-Tracker
  → OutpostWorldObject extends Odyssey_Gravship
  → alter abstract Graph: legacy-fallback Path

Tag 5:
  → DEPLOY + Live-Test alle 5 Pakete
  → Player.log soll zeigen: alle DLCs geladen, Foundation-DLCFilter Log einmal,
    StoryDirector spawnt Shambler wenn Anomaly aktiv.
```

---

---

## Patch-Layer-Standard (RimWorld 1.5+)

**Lock-Status:** 2026-08-04 (Audit-Round-5). Player.log hat zwei XML-Fehler enthüllt die jetzt gefixt sind:

1. **Scenario-Root-Element** muss `<Defs>` sein mit `<ScenarioDef>` als Kind — RimWorld's `LoadedModManager.CombineIntoUnifiedXML` lehnt `<ScenarioDef>` als Root ab.
2. **PatchOperationTest Field-Name** muss `<case>` (und `<nomatch>`) sein — **nicht `<match>`**. Das ist RimWorld 1.4-Legacy und wirft in 1.5+ einen "doesn't correspond to any field" Error beim Mod-Load.

**Field-Name-Matrix pro PatchOp-Klasse:**

| PatchOp-Klasse | Field wenn xpath matched | Optionaler Else-Branch |
|---|---|---|
| `PatchOperationFindMod` | `<match>` | `<nomatch>` |
| `PatchOperationTest` | `<case>` | `<nomatch>` |
| `PatchOperationAddModExtension` | `<value>` | (kein else) |
| `PatchOperationSet` | `<value>` | (kein else; no-op bei no-match) |
| `PatchOperationRemove` | (kein Wert) | (kein else) |
| `PatchOperationSequence` | `<operations>/<li>` | (iteriert intern) |
| `PatchOperationAdd` | `<value>` | (kein else; appended wenn matched) |

**Conditional-Patch-Template** (`<Operation Class="PatchOperationFindMod">` wraps eine `<match Class="PatchOperationSequence">` Liste von `<li Class="PatchOperationTest">` Blöcken):

```xml
<Patch>
  <Operation Class="PatchOperationFindMod">  <!-- Condidional: Patch fires nur wenn Mod listed -->
    <mods><li>Ludeon.RimWorld.SomeDlc</li></mods>
    <match Class="PatchOperationSequence">
      <success>Always</success>
      <operations>
        <li Class="PatchOperationTest">
          <xpath>/Defs/SomeDef[defName="SomeName"]/someField</xpath>
          <case Class="PatchOperationSet">
            <xpath>/Defs/SomeDef[defName="SomeName"]/someField</xpath>
            <value>0</value>
          </case>
        </li>
      </operations>
    </match>
  </Operation>
</Patch>
```

**Conventions:**
- xpath im Test und inner-Op **immer identisch**. Redundancy ist explizit für Rename-Risk-Defense.
- `<nomatch>` nie setzen wenn xpath-Match non-fatal sein darf — non-match resultiert in no-op, kein Crash.
- Def-Name-Lookup via `defName="X"` (string literal) ist renamings-anfällig. Mitigation: bei vermutet unstabilem Def-Name expliziter Doppel-Check im Live-Test.

---

## Out-of-Scope (vor Phase 7 nicht angefasst)

- Biotech-Pollution × Wasser-Resource (F6): später, nach F4 Toggle.
- Odyssey Travel-Events × Territory-Discovery (F7): später.
- Biome-Spezifische Caravan-Camps (F8): vor Odyssey nicht relevant.
- StyleDef-Anpassung an Ideology-Style: dokumentiert als "kein Style-Remapping".

Diese Liste ist explizit "später" — kein Sprint-Plan-Backlog-Drift.
