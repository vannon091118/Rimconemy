# Rimconemy — Gesamtreport (Stand 2026-08-04)

> **Auftrag:** Read-only-Verifikation und Kristallisation. Alle Aussagen wurden aktiv zu widerlegen versucht (Falsifizierung statt Bestätigung).
> **Quellen:** (1) vollständiger Scan des Repos (42 MD-Dateien, 35+ C#-Dateien, 28 XML-Defs, 5 About.xml, Deploy-Skript, `_invbuild/`), (2) lokale RimWorld-1.6-Installation `1.6.4566` (`Assembly-CSharp.dll`-String-Scan + Core-/DLC-XML-Abgleich), (3) Online-Recherche (RimWorld-Wiki, Ludeon).
> **Kein Code wurde verändert.** Die lokale Installation ist die stärkste Evidenzquelle — stärker als jede Wiki-Seite.

---

## 1. Projektstatus in einem Satz

Das Repo ist ein **diszipliniert dokumentierter Scaffold/Prototyp**: Alle 5 Pakete kompilieren und liefern ein sichtbares Dashboard, aber fast keine Gameplay-Mechanik ist implementiert — Wallets, Märkte, Outposts, Infizierte, Mechadroids, eigener Storyteller und XP sind überwiegend leere Daten-Bausteine (`LogMarker = "v0"`).

## 2. Paketübersicht

| Paket | Rolle | Tatsächlicher Zustand |
|---|---|---|
| 01 Foundation | Diagnose, Registry, ServiceBus, Save, Dashboard | **Am weitesten**: funktionierendes MainTabWindow, PackageRegistry, EventLog, SaveData, Def-Inventur |
| 02 Survival & Progression | Needs, XP, Research, Game Over, Scenario | Runtime-Component (ProgressionGameComponent) läuft, aber XP = Tick-Sampling; Needs = Vanilla-Sampling; Game-Over-Anker fragil |
| 03 Scavenger Infrastructure | Bauschutt, Pflanzen, Wasser, Strom, Turm | Defs korrekt 1.6-fixiert (PowerPlants.xml), aber **0 Patch-Dateien** → kein Baukosten-Remap |
| 04 Economy & Territory | Wallet, Markt, Outposts, Territory | **Nur Datenrecords** (CreditsLedger, MarketStub, OutpostStubRecord, TerritoryNode) |
| 05 Infected & Automation | Raid, Threat, Mechadroids | **Nur Datenrecords + Worker-Lüge**: InfectedRaidWorker meldet Erfolg ohne Effekt |

## 3. Verifizierte RimWorld-1.6-API-Anker (lokale Evidenz)

String-Scan der installierten `Assembly-CSharp.dll` (1.6.4566) — Trefferzahlen in Klammern:

| Anker | Beleg | Bedeutung |
|---|---|---|
| `IncidentWorker_RaidEnemy` (3), `TryResolveRaidFaction` (4), `ResolveRaidPoints` (1), `ResolveRaidStrategy` (4), `GetLetterDef` (1) | DLL | **A2 machbar**: eigener Raid durch Erben statt Neuimplementierung |
| `DefaultThreatPointsNow` (1), `StorytellerUtility` (6), `ThreatBig` (6) | DLL | Raid-Punkte- und Letter-Pfad bestätigt |
| `SetInitialLevel` (2), `CurLevelPercentage` (2), `NeedInterval` (2) | DLL | **A10 machbar**: Need-Basisklasse bestätigt |
| `threatScale`, `cropYieldFactor`, `researchSpeedFactor`, `colonistMoodOffset`, `diseaseIntervalFactor`, `isExtreme` (je 1) | DLL | **S1 machbar**: DifficultyDef-Felder 1:1 vorhanden |
| `FixedBiologicalAge` (3), `FixedChronologicalAge` (3), `PawnGenerationRequest` (3) | DLL | **S3 machbar**: Startalter-18-Zwang |
| `CompPowerTrader` (4), `CompPowerPlant` (27), `CompRefuelable` (5) | DLL | **A1 machbar**: Power-Comps bestätigt (XML nutzt sie bereits korrekt) |
| `WorldObjectComp` (71) | DLL | **A4 machbar**: Outpost-Comp-Pfad |
| `Scribe_Collections` (3) | DLL | **C3 machbar**: Scribe-Deep-Save statt Base64 |
| `GameEnder` (3), `CheckOrUpdateGameOver` (1) | DLL | `Find.GameEnder?.CheckOrUpdateGameOver()` kompiliert — Risiko ausgeräumt |
| `workerClass` (2), `incidentClass` (0) | DLL | Feld-Rename real; Version (1.5 vs 1.6) lokal nicht beweisbar |
| `TicksPerDay` (1) | DLL | **1 Tag = 60.000 Ticks** → F1-Befund bestätigt |
| `AllMapsCaravansAndTravellingTransporters_Alive_FreeColonists` | DLL | F6-Fix-Anker existiert (Name korrekt: „TravellingTransporters", nicht „TransportPods") |
| `PreceptDef` (19), `RitualDef` (73), `RoleDef` (17), `IdeoManager` (6) | DLL | Ideology-Anker teilweise bestätigt; **`IdeoDef` in DLC-Assembly, lokal nicht prüfbar** → Spike `API-IDEOLOGY-01` zwingend |
| DLC-PackageIds lokal: `Ludeon.RimWorld.Royalty` etc. (PascalCase) | Data/*/About.xml | **F5 widerlegt**: ProfileDetector-PackageId-Check matcht exakt |
| `Gun_MiniTurret` existiert (Vanilla-Turm nutzt es), `Gun_TurretMini` nicht | Core XML | **Turret-Befund widerlegt**: Rimconemy-Turm-Def korrekt |
| `Flammability` ist StatDef (WoodLog `<Flammability>0.4</Flammability>` via statFactors) | Core XML | **F7 widerlegt**: kein Top-Level-Feld; XML-Kommentar im Kern korrekt |
| Core NeedDefs: `<defName>Joy</defName>`, kein „Recreation"; `Need_Joy` (3), `Need_Recreation` (0) | Core XML + DLL | „Recreation"-Rename lokal nicht bestätigt; Fallback-Kette im Code korrekt |
| **Odyssey ist offizielles DLC** (Release 11.07.2025) | rimworldwiki.com/wiki/Odyssey_(DLC) + lokale Data/Odyssey | 5-DLC-Annahme korrekt; Verdacht in Dumps 1/2 falsch |

## 4. Falsifikations-Ergebnisse (F1–F9 des Audit-Berichts)

### Bestätigt (der Audit-Bericht hat recht)

| # | Befund | Evidenz | Severity |
|---|---|---|---|
| **F1** | `TerritoryNode.cs`-Kommentar „30,000 ticks (3 in-game days)" falsch | `TicksPerDay` bestätigt → 30.000 Ticks = **0,5 Tage**; 3 Tage = **180.000 Ticks**. Auch `API-WORLD-01.md` („3 Tage (30 000 Ticks)") falsch. Spezifikation (ROADMAP 04) ist korrekt. | **crit** |
| **F2** | XP per Tick-Sampling statt „validiertem Output" | `ProgressionGameComponent.UpdateWorkEpisode`: XP aus `ActiveJobTicks` (250-Tick-Sampling); Bootstrap-Log gibt es selbst zu. BLUEPRINT 02 P3 verbietet Tick-XP. | **high** |
| **F3** | „Bauschutt für Wände/Türen" nicht implementiert | **0** `Patches/*.xml` im gesamten Repo; `Patches/README.md` = `NOT_REQUIRED_FOR_MVP`. | **high** |
| **F4** | „eigener Storyteller" nicht implementiert | Kein `StorytellerDef` irgendwo; `InfectedRaid.xml` `baseChance 0.0`; `CanFireNowSub → false`. | **high** |
| **F6** | Game-Over-Grace zu kurz | 4 × 250 Ticks = **1.000 Ticks ≈ 24 Spielminuten / ~17 Real-Sekunden** — kürzer als Karawanenreisen. Fix-Anker: `PawnsFinder.AllMapsCaravansAndTravellingTransporters_Alive_FreeColonists` (lokal bestätigt). | **crit** |
| **F9** | README-Overclaim vs. ehrliche BLUEPRINTs | README 04/05 listen Countdown, Mechadroids, Storyteller als geliefert; Code = Datenrecords. | medium |

### Widerlegt (der Audit-Bericht irrt hier — lokale Evidenz)

| # | Bericht-Behauptung | Lokaler Befund |
|---|---|---|
| **F5** | „DLC-PackageIds lowercase → `==`-Check matcht nie" | Lokale `About.xml` aller 5 DLCs: **PascalCase** `Ludeon.RimWorld.Royalty` usw. — Check matcht exakt. |
| **F7** | „Vanilla hat Top-Level-`<flammability>` (WoodLog: 1)" | `Flammability` ist **StatDef**; WoodLog setzt `<Flammability>0.4</Flammability>` via `statFactors`. |
| **Turret** | „`Gun_MiniTurret` falsch; heißt `Gun_TurretMini`; Comp fehlt" | Vanilla `Turret_MiniTurret` nutzt selbst `Gun_MiniTurret`; `Gun_TurretMini` existiert nicht; Vanilla-Turm hat ebenfalls kein `CompProperties_TurretGun`. |
| **GameEnder** | „Existenz nicht verifizierbar → Risiko" | `GameEnder` (3), `CheckOrUpdateGameOver` (1) in DLL — existiert. |
| **Recreation** | „NeedDef ‚Recreation' als 1.5-Rename" | Core nutzt lokal weiterhin **`Joy`**; Fallback `"Recreation" ?? "Joy"` löst korrekt auf „Joy" auf. |

### Teilweise bestätigt

- **F8** („1.6-Fixes" sind 1.5-Änderungen): Feld-Renames real (`workerClass` ja, `incidentClass` nein), aber exakte Versionszuordnung lokal nicht beweisbar. Kommentar-Hygiene, low.
- **netstandard2.1** vs. Community-Standard 2.0: csproj bestätigt `netstandard2.1`; Laufzeitverhalten lokal **nicht testbar** (kein Spielstart) — als unverifiziertes Risiko führen, nicht als Bug.

## 5. Strukturelle Befunde

1. **Fehlende Meta-Dokumente (alle 9):** `PRODUCT_VISION.md`, `BLUEPRINT_INDEX.md`, `BLUEPRINT_EXECUTION_CONTRACT.md`, `VANILLA_DLC_RESEARCH_BASELINE.md`, `INTERFACE_CONTRACT.md`, `SAVE_CONTRACT.md`, `COMPATIBILITY_MATRIX.md`, `HANDOFF_QUEUE.md`, `SPIKE_INDEX.md` — in jeder README/BLUEPRINT als `../…` referenziert, **existieren im Checkout nicht** (auch `TASK_CACHE.json` fehlt).
2. **Alle Falsifizierungsberichte fehlen:** Jede ROADMAP verlangt `FALSIFICATION_REPORTS/rimconemy.*.md` mit Status `SURVIVED` — **kein einziger existiert** (auch BLUEPRINT 01 listet einen „vorhanden, UNVERIFIED" — falsch).
3. **`mods/_invbuild/`:** 6 Unterordner mit rohen DLLs/deps.json, inkl. **doppeltem Foundation-Ordner** (`foundation/` + `01-Rimconemy-Foundation/`) — nicht vom Deploy-Skript referenziert.
4. **`obj/` in allen 5 Paketen** (Build-Artefakte im Quellbaum), plus `mods/01-Rimconemy-Foundation/mods/`-Ordner als Artefakt.
5. **Deploy-Skript** (`scripts/deploy_all_to_local_mods.sh`): dokumentiert vorherige kaputte Deployment-Strategie; `rsync → cp -ar`-Fallback; `cp ... 2>/dev/null || true` schluckt fehlende DLLs still.
6. **`netstandard2.1`:** Potenzielles Laufzeitrisiko, ungetestet.

## 6. Notlösungs-Inventar (kondensiert aus allen Audit-Runden)

- **A — Deklarierte Stubs (v0):** PowerChainStub, IncidentStub, MarketStub, OutpostStub + OutpostWorldObject (leer), ThreatAggregator, MechadroidUnit, CreditsLedger, TerritoryNode, ResourceCategory, PlantHelper, SurvivalNeedCategory, SingleSurvivorScenario.
- **B — No-op-Gates:** `InfectedRaidWorker` (`CanFireNowSub→false`, `TryExecuteWorker→true` = Erfolgs-Lüge).
- **C — Fragile Workarounds:** ServiceBus-Thread-Maschinerie (`Monitor.Wait`, `[ThreadStatic]`, `WouldCreateWaitCycle`, 1000er-Eviction), Base64-`|`-Event-Serialisierung, Substring-Job-Matching (`IndexOf("Build")` …), `catch (NullReferenceException)` um `Find.TickManager`, 0.5f-Defaults, Magic Numbers (`250`, `0.25f`, `4`, `xp/1000f`, `0.65/0.35`, `500`, `100`).
- **D — Def-/XML:** Vanilla-Textur-Fallbacks (Hemp, Rice, Turret) als Grafik-Platzhalter.
- **E — Build/Deploy:** `_invbuild/`-Müll, `obj/`-Artefakte, Deploy-Fehlerstille.
- **F — Dokumentierte Lücken:** alle Tests `UNVERIFIED`, Audit abgebrochen, Kern-Features (Needs/XP/Research/GameOver) unimplementiert.

## 7. Empfohlene Reihenfolge (Abhängigkeiten)

1. **F1 + B1 + F6** — drei belegte Sofort-Fixes: Tick-Zahl 180.000, Raid-Lüge entfernen (`return false` + `Log.Warning`), Game-Over-Anker auf `PawnsFinder.AllMapsCaravansAndTravellingTransporters_Alive_FreeColonists` (korrekter Name).
2. **C2** — ServiceBus auf Main-Thread-Modell vereinfachen (größter Komplexitätsabbau, entblockt A5/A7).
3. **C3** — Scribe-Deep-Save statt Base64 (Save-Integrität).
4. **F1(Tests)** — Unit-Tests für pure Funktionen (Preis, ThreatPressure, Graph-BFS, Effizienz).
5. **A2** — Infizierten-Raid via `IncidentWorker_RaidEnemy`-Erbung (alle Anker verifiziert).
6. **A7 → A4 → A5** — Wallet → Outpost (`WorldObjectComp`) → ThreatAggregator (Full-Profile-Kette).
7. **A10 + C1** — echte Needs + Job-Klassifikation statt Substring/0.5f.
8. **Meta-Docs** — fehlende Referenzdokumente anlegen oder tote Links markieren.

## 8. Offene Punkte (bewusst nicht verhärtet)

- `IdeoDef`-Signatur (DLC-Assembly fehlt lokal) → Spike `API-IDEOLOGY-01` vor S2.
- `PawnGenerator.GeneratePawn`/`GenerateTraits`-Signaturen → Spike `API-START-01`.
- netstandard2.1-Laufzeitverhalten (kein Spielstart durch Agent).
- Exakte Versionszuordnung der Feld-Renames (1.5 vs 1.6).

## 9. Kernaussage

Die Architektur (late-bound Registry/ServiceBus, GameComponent-Persistenz, def-getriebene Inhalte mit korrekten 1.6-Konventionen) ist tragfähig. Der größte Handlungsbedarf ist nicht strukturell, sondern inhaltlich: **die Erfolgs-Lüge, die falsche Tick-Rechnung, das Game-Over-Risiko und die Diskrepanz zwischen README-Versprechen und Gerüst-Zustand** müssen zuerst bereinigt werden — danach lassen sich die echten Mechaniken auf verifizierten Ankern aufbauen.
