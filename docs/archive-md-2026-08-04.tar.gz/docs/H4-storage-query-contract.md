# H4 — Storage-Query-Vertrag

> **Owner:** Research/Design (kein Code)
> **Status:** `PLANNED` — Signatur und Randfälle definiert; Kompilierprobe gegen 1.6-API durch User
> **Referenz:** [ROADMAP.md §3 Phase 3](../ROADMAP.md#phase-3--storage-only-ressourcenmodell), [HANDOFF.md §5 Schritt H4](../HANDOFF.md#schritt-h4--storage-query-vertrag)

## Zweck

Eine **einzige Read-only-Abfrage** definieren, die Story Writer, UI und Economy als gemeinsame Quelle für Survivor-Ressourcen nutzen. Kein zweites abstraktes Survivor-Inventar und kein paralleles Ledger für dieselben physischen Items.

---

## 1. Kernsignatur

```csharp
namespace Rimconemy.Foundation.Storage
{
    /// <summary>
    /// Read-only storage snapshot. The single source of truth for all
    /// survivor resources. Story Writer, UI, and Economy read from this;
    /// no package may write to it directly.
    /// </summary>
    public static class StorageQuery
    {
        /// <summary>
        /// Reads the current storage state for the given scope and filter.
        /// Returns an immutable snapshot. No mutation of game state.
        /// </summary>
        /// <param name="scope">Which maps/storages to include.</param>
        /// <param name="filter">Which resources to include. If null, all.</param>
        /// <param name="tick">Game tick for snapshot timestamp.</param>
        /// <returns>Immutable snapshot with aggregated resource entries.</returns>
        public static StorageSnapshot ReadStorage(
            StorageScope scope,
            ResourceFilter filter,
            long tick);
    }
}
```

---

## 2. Datenstrukturen

### `StorageSnapshot`

```csharp
public sealed class StorageSnapshot
{
    /// <summary>Snapshot schema version for save migration.</summary>
    public int SchemaVersion = 1;

    /// <summary>Game tick when this snapshot was taken.</summary>
    public long SnapshotTick;

    /// <summary>Scope used for this snapshot.</summary>
    public StorageScope Scope;

    /// <summary>Aggregated resource entries, sorted by ResourceId ascending.</summary>
    public List<StorageEntry> Entries;

    /// <summary>
    /// Maps that were unavailable at snapshot time.
    /// Key = map unique ID, Value = reason.
    /// </summary>
    public Dictionary<int, string> UnavailableMaps;

    /// <summary>Hash of all entries for deterministic comparison.</summary>
    public string ContentHash;
}
```

### `StorageEntry`

```csharp
public sealed class StorageEntry
{
    /// <summary>Stable ThingDef.defName (e.g., "WoodLog", "RawRice").</summary>
    public string ResourceId;

    /// <summary>Display label (cached from ThingDef.label).</summary>
    public string Label;

    /// <summary>Aggregated total amount (sum of all stackCounts).</summary>
    public int TotalAmount;

    /// <summary>Number of distinct stacks.</summary>
    public int StackCount;

    /// <summary>
    /// Availability status:
    /// - Available: fully accessible
    /// - Blocked: in reserved/inaccessible storage
    /// - Unavailable: on unloaded map or destroyed
    /// - Frozen: temporarily locked (e.g., during event)
    /// </summary>
    public StorageAvailability Availability;

    /// <summary>Location(s) as MapId list. "Unknown" if unloaded.</summary>
    public List<int> MapIds;

    /// <summary>Optional quality aggregation (min/avg/max).</summary>
    public QualityAggregation? Quality;

    /// <summary>Optional rot/decay aggregation.</summary>
    public RotAggregation? Rot;
}

public enum StorageAvailability
{
    Available,
    Blocked,
    Unavailable,
    Frozen
}

public struct QualityAggregation
{
    public int MinQuality;  // 0-6 (Awful-Legendary)
    public float AvgQuality;
    public int MaxQuality;
}

public struct RotAggregation
{
    public float MinRotProgress;  // 0-1
    public float AvgRotProgress;
    public int RottenStacks;  // stacks past rot threshold
    public int FreshStacks;
}
```

### `StorageScope`

```csharp
public enum StorageScope
{
    /// <summary>All player-home maps only.</summary>
    PlayerHomeMaps,

    /// <summary>All loaded maps regardless of ownership.</summary>
    AllLoadedMaps,

    /// <summary>Specific map by ID.</summary>
    SpecificMap,        // requires mapId

    /// <summary>All maps including caravan/temporary maps.</summary>
    AllMapsIncludingCaravans,
}

public struct ResourceFilter
{
    /// <summary>If non-empty, only include these ResourceIds.</summary>
    public List<string> WhitelistResourceIds;

    /// <summary>If non-empty, exclude these ResourceIds.</summary>
    public List<string> BlacklistResourceIds;

    /// <summary>Minimum availability to include. Default: Available.</summary>
    public StorageAvailability MinAvailability;

    /// <summary>If non-null, only include these ThingCategories.</summary>
    public List<string> WhitelistCategories;

    /// <summary>If true, include items in pawn inventories. Default: false.</summary>
    public bool IncludePawnInventory;

    /// <summary>If true, include items on the ground. Default: true.</summary>
    public bool IncludeGroundItems;

    /// <summary>If true, include items in storage zones. Default: true.</summary>
    public bool IncludeStorageZones;
}
```

---

## 3. Implementierungsskizze (Pseudocode)

```csharp
public static StorageSnapshot ReadStorage(
    StorageScope scope, ResourceFilter filter, long tick)
{
    var entries = new Dictionary<string, StorageEntry>(StringComparer.Ordinal);
    var unavailableMaps = new Dictionary<int, string>();
    var maps = ResolveMaps(scope);

    foreach (var map in maps)
    {
        if (map == null || !map.IsLoaded)
        {
            unavailableMaps[map?.uniqueID ?? -1] = "Map not loaded";
            continue;
        }

        // Enumerate all Things on the map via listerThings
        // SPIKE: Map.listerThings.AllThings — local assembly check required
        foreach (var thing in map.listerThings.AllThings)
        {
            if (!MatchesFilter(thing, filter))
                continue;

            var resourceId = thing.def.defName;
            if (!entries.TryGetValue(resourceId, out var entry))
            {
                entry = new StorageEntry
                {
                    ResourceId = resourceId,
                    Label = thing.def.label,
                    MapIds = new List<int>(),
                };
                entries[resourceId] = entry;
            }

            entry.TotalAmount += thing.stackCount;
            entry.StackCount++;
            if (!entry.MapIds.Contains(map.uniqueID))
                entry.MapIds.Add(map.uniqueID);

            // Quality aggregation (if applicable)
            var qualityComp = thing.TryGetComp<CompQuality>();
            if (qualityComp != null && entry.Quality == null)
            {
                entry.Quality = new QualityAggregation
                {
                    MinQuality = (int)qualityComp.Quality,
                    AvgQuality = (int)qualityComp.Quality,
                    MaxQuality = (int)qualityComp.Quality,
                };
            }
            // (simplified — production code would properly aggregate)

            // Determine availability
            if (thing.IsForbidden(Faction.OfPlayer))
                entry.Availability = StorageAvailability.Blocked;
            else
                entry.Availability = StorageAvailability.Available;
        }
    }

    // Sort entries by ResourceId for deterministic output
    var sortedEntries = entries.Values
        .OrderBy(e => e.ResourceId, StringComparer.Ordinal)
        .ToList();

    // Compute content hash
    var hashBuilder = new StringBuilder();
    foreach (var e in sortedEntries)
        hashBuilder.Append($"{e.ResourceId}:{e.TotalAmount};");
    var contentHash = ComputeSha256(hashBuilder.ToString());

    return new StorageSnapshot
    {
        SchemaVersion = 1,
        SnapshotTick = tick,
        Scope = scope,
        Entries = sortedEntries,
        UnavailableMaps = unavailableMaps,
        ContentHash = contentHash,
    };
}

private static bool MatchesFilter(Thing thing, ResourceFilter filter)
{
    if (!filter.IncludeGroundItems && thing.ParentHolder is Map)
        return false;
    if (!filter.IncludeStorageZones && thing.IsInAnyStorage())
        return false;
    if (!filter.IncludePawnInventory && thing.ParentHolder is Pawn)
        return false;

    var resourceId = thing.def.defName;
    if (filter.WhitelistResourceIds?.Count > 0
        && !filter.WhitelistResourceIds.Contains(resourceId))
        return false;
    if (filter.BlacklistResourceIds?.Contains(resourceId) == true)
        return false;

    return true;
}
```

---

## 4. Randfälle und Regeln

| Fall | Regel | Verhalten |
|---|---|---|
| **Unloaded Map** | Map nicht in `Find.Maps` | `UnavailableMaps[mapId] = "Map not loaded"`. Einträge in dieser Map werden **nicht** als 0 gezählt, sondern als `Unavailable` markiert. |
| **Caravan/Temporary Map** | `StorageScope.AllMapsIncludingCaravans` | Caravan-Items werden enumeriert, falls Map geladen. |
| **Kartenwechsel** | Snapshot wird neu gebaut | Keine Übernahme alter Werte. Neuer Snapshot = neue Timestamps + Hash. |
| **Save/Load** | Snapshot wird **nicht persistiert** | `StorageSnapshot` ist immer live aus `Map.listerThings` gelesen. Save speichert nur den letzten Hash für Drift-Erkennung. |
| **Cache** | Letzter Snapshot + Hash | Bei gleichem Hash innerhalb von 250 Ticks wird kein neuer Snapshot gebaut. Cache-Invalidation: bei Thing-Änderung oder Tick-Differenz > 250. |
| **Qualität/Verderb** | Optional, nur wenn Comp existiert | `CompQuality` / `CompRottable` aggregieren Min/Avg/Max. Fehlt der Comp → `null`. |
| **Credits/Wallet** | **Nicht** im StorageSnapshot | Credits sind Wallet-Daten, keine physischen Items. Getrennte Abfrage. |
| **Performance** | Kein Scan pro UI-Frame | Snapshot wird max. 1× pro 250 Ticks gebaut. UI liest nur den gecachten Snapshot. |
| **Null-Ergebnis** | Keine Maps/Items | `Entries` = leere Liste, nicht null. `ContentHash` = Hash von "". |
| **Doppelte Scans** | Mehrere Pakete fragen ab | Foundation cached den Snapshot. Alle Pakete lesen dieselbe Instanz. |

---

## 5. Konsumenten-Vertrag

| Konsument | Nutzung | Darf schreiben? |
|---|---|---|
| **Story Writer** (Phase 1) | Liest `StorageSnapshot` für `SituationSnapshot.Storage` | ❌ Nein |
| **UI / Dashboard** (Foundation) | Zeigt Ressourcen-Übersicht | ❌ Nein |
| **Economy** (Phase 6) | Liest physische Waren für Markt/Handel | ❌ Nein |
| **Scavenger Infrastructure** (Phase 3) | **Besitzer** der Read-Funktion | ✅ Ja (nur Read, nicht Write) |
| **Survival Progression** (Phase 2–4) | Liest für Need-Berechnung (Nahrung) | ❌ Nein |

---

## 6. Save-Schema für Snapshot-Referenz

```yaml
# In Foundation-Save oder StoryState
StorageSnapshotReference:
  LastSnapshotTick: long
  LastSnapshotHash: string
  CacheValidUntilTick: long
```

Der Snapshot selbst wird **nicht persistiert**. Nur die Referenz, um Drift zwischen Sessions zu erkennen.

---

## Nächster Schritt (User)

1. `Map.listerThings.AllThings`-Enumeration gegen lokale Assembly kompilieren
2. `CompQuality`- und `CompRottable`-Casts testen
3. Storage-Scan mit einer Test-Map (3 Ressourcen, 2 Maps) durchführen und Hash-Vergleich prüfen
