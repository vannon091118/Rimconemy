# Build-Vertrag – Rimconemy Scavenger Infrastructure

## Ausgabe

```text
Assemblies/Rimconemy.ScavengerInfrastructure.dll
```

## Source-Verantwortung

`Source/` enthält Bauschutt, Bau-/Handelsremapping, Pflanzen, Farmen, Wasser, Brennstoff, Energie, Pfeilturm und Infrastruktur-UI.

## Standalone-Build

Der Build darf ohne die anderen Rimconemy-Assemblies kompiliert werden. Integrationen zu Survival, Economy und Infected werden im Full Profile über den Foundation-Servicebus und versionierte Capabilities geladen, nicht über ungeschützte Klassenreferenzen. Ohne Foundation bleibt der Standalone-Modus.

## Validierung

- Bauschutt, Wände und Türen laden.
- Nahrungspflanzen und Hanf sind getrennt.
- Wasser/Brennstoff/Strom bilden eine testbare Kette.
- Pfeilturm blockiert bei fehlender Energie.
- Vanilla-Modus bleibt ohne übrige Pakete spielbar.
