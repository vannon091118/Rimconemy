# Rimconemy Scavenger Infrastructure

> Blueprint: [`BLUEPRINT.md`](BLUEPRINT.md) · zentrale Vision: [`../PRODUCT_VISION.md`](../PRODUCT_VISION.md) · Research: [`../VANILLA_DLC_RESEARCH_BASELINE.md`](../VANILLA_DLC_RESEARCH_BASELINE.md)

## Kurzbeschreibung

Rimconemy Scavenger Infrastructure ist der physische Basebuilding- und Energie-Loop des Settings. Es verschiebt den frühen Fortschritt von gewöhnlichen Baumaterialien zu Bauschutt, Farmen, Wasser, Brennstoff und einer ersten automatischen Verteidigung.

## Was das gesamte Paket bietet

- Bauschutt als physische Ressource
- Bauschutt für Wände und Türen
- Bauschutt als Handelsware
- Nahrungspflanzen und getrennte Hanfpflanzen
- Farmproduktion und Farm-Schutzbedarf
- Nahrung als mögliche Quelle aus Farmen, Expeditionen und Drops
- Holz und Kohle als Brennstoff
- Wasser als Versorgungskomponente
- Generator-/Boiler-Kette
- Stromproduktion, Verbrauch und Priorisierung
- strombetriebener Pfeilturm
- Eisen und andere Erze als technische Upgrade-Materialien
- sichtbare Produktions- und Energieengpässe

## Was es alleine bietet

Allein mit Vanilla-Bedürfnissen und Vanilla-Raids bietet es einen vollständigen Scavenger-Basebuilding-Loop:

```text
Bauschutt sammeln
→ Wand und Tür bauen
→ Farm sichern
→ Wasser bereitstellen
→ Holz/Kohle verarbeiten
→ Strom erzeugen
→ Pfeilturm betreiben
```

Es ist damit auch ohne Economy, Outposts oder eigene Infizierte spielbar.

## Verhalten ohne andere Rimconemy-Pakete

- nutzt Vanilla-Bedürfnisse, wenn Survival & Progression fehlt
- nutzt Vanilla-Forschung, wenn kein gemeinsamer Progressionspfad vorhanden ist
- nutzt Vanilla-Handel und Vanilla-Fraktionen
- nutzt Vanilla-Raids als Test- und Bedrohungsquelle
- aktiviert keinen eigenen Fraktions- oder Infizierten-Druck ohne das zuständige Paket
- erzeugt keine Credits-Wallets und keine Outposts

## Integration im Full Overhaul

- Bauschutt wird zum zentralen Wand- und Türmaterial.
- Survival & Progression liefert Bedürfnisse, XP und Freischaltungen.
- Farmfläche, Bewohner, Produktion, Generatoren und Türme speisen den Infizierten-Druck.
- Economy & Territory kann Bauschutt, Nahrung, Erze und Brennstoff regional handeln.
- Outposts verwenden die Bau- und Upgrade-Ressourcen für Gründung, Proxies und Verteidigung.
- Mechadroids können später Farmen, Energie und Wartung automatisieren.

## Abhängigkeiten

- RimWorld 1.6
- Harmony als externe Laufzeitabhängigkeit
- Survival & Progression optional
- Foundation optional im Standalone-Modus
- **Foundation-Servicebus** erforderlich für die geschlossene Full-Profile-Integration
- gemeinsamer Interface-Vertrag: [`../INTERFACE_CONTRACT.md`](../INTERFACE_CONTRACT.md)
- Economy, Territory und Infected optional im Standalone-Modus

## Save-Risiko

Niedrig bis mittel. Neue Defs sind meist unkritisch; Remapping bestehender Baukosten, Pflanzen und Handelslisten kann bestehende Saves semantisch verändern. Vor Remapping wird ein Save-Hinweis benötigt.

## Definition of Done für dieses Paket

- Bauschutt kann erzeugt, gelagert, gehandelt und für Wand/Tür verwendet werden
- Nahrungspflanzen und Hanfpflanzen sind funktional getrennt
- Wasser und Brennstoff führen zu messbarer Stromproduktion
- Pfeilturm funktioniert nur mit ausreichender Energie
- Energieproduktion und -verbrauch sind im UI nachvollziehbar
- Standalone-Modus bleibt ohne Economy und Infected spielbar
