# API-POWER-01 – Fuel/Power/Turret Anker

Status: UNVERIFIED
Owner: Scavenger Infrastructure

## Zweck

Bevor Wasser-, Brennstoff- oder Pfeilturm-Schleifen tatsächlich Befehle ausführen, muss klar sein, welche Vanilla-Comps die Energie- und Turretzustandsverwaltung tragen. Der Spike erzeugt keinen neuen Sim-Kern.

## Gesuchte Anker

- `CompPowerTrader`
- `CompRefuelable`
- `CompPowerPlant` / `CompPowerConsumer`
- Vanilla-Turret-Defs

## Besitzentscheidung

- Scavenger Infrastructure besitzt die Rimconemy-ThingDefs `Rimconemy_WoodCoalGenerator`, `Rimconemy_TurbineWaterPump`, `Rimconemy_DistilledWater`, `Rimconemy_ArrowTurret_Power`.
- Vanilla besitzt `CompPowerTrader` / `CompRefuelable` / `CompPowerPlant`.
- Economy und Infected lesen nur aggregierte Snapshots, niemals direkte Vanilla-Comps.
- Schwamm-Energie ohne logischen Input ist verboten.

## Minimaler Spike-Test

1. Generator-CompRefuelable ohne Fuel → Idle; mit Fuel → Online.
2. Turbine-Water-Pump unter Stromabschaltung → Offline.
3. Pfeilturm ohne Strom → Blocked, kein Schaden.
4. Save/Load und Mapwechsel lassen Status invariant.
5. P1/P2-Profile halten das 2 ms / 5 ms-Budget ein.

## Belegschema

- Symbol gesucht: CompPowerTrader, CompRefuelable, CompPowerPlant
- Symbol gefunden: UNVERIFIED
- Def-/XML-Beleg: `game/Data/Core/Defs/ThingDefs/Building/{Power,Turrets}/*.xml`; `mods/03-Rimconemy-Scavenger-Infrastructure/Defs/BuildingDefs/PowerPlants.xml`
- Testaktion: oben beschrieben
- Ergebnis: UNVERIFIED
- Belegpfad: `mods/FALSIFICATION_REPORTS/rimconemy.scavengerinfrastructure__WaterPowerArrowTurret.md`

## Exit

`READY` erst nach lokalem Runtime-Test des Fuel-/Water-/Turret-Blockadeverhaltens mit Save/Load und Mapwechsel.
