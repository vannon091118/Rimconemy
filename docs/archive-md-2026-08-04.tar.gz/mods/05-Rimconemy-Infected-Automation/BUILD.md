# Build-Vertrag – Rimconemy Infected & Automation

## Ausgabe

```text
Assemblies/Rimconemy.InfectedAutomation.dll
```

## Source-Verantwortung

`Source/` enthält Infizierte, Storyteller, Bedrohungsberechnung, World-Map-Raids, Mechadroids, Silber-Upgrades, Automationsaufträge und Raid-Auflösung.

## Standalone-Build

Der Build darf ohne Economy, Territory, Scavenger und Survival kompiliert werden. Standalone verwendet Vanilla-Ressourcen, lokale Ziele und einen dokumentierten Minimalmodus für Energie/Handel. Im Full Profile werden Integrationen über den Foundation-Servicebus und versionierte Capabilities geladen; ohne Foundation bleibt der Standalone-Modus.

## Validierung

- eigener Storyteller/Bedrohungsmodus lädt.
- Bedrohungswerte nennen ihre Ursachen.
- Mechadroids sind von Vanilla-Mechanoids getrennt.
- Silber kann als Upgrade-Material verwendet werden.
- lokale Automation funktioniert ohne Outposts.
- fehlende optionale Pakete erzeugen keine Phantomreferenzen.
