# Rimconemy Infected & Automation

> Blueprint: [`BLUEPRINT.md`](BLUEPRINT.md) · zentrale Vision: [`../PRODUCT_VISION.md`](../PRODUCT_VISION.md) · Research: [`../VANILLA_DLC_RESEARCH_BASELINE.md`](../VANILLA_DLC_RESEARCH_BASELINE.md)

## Kurzbeschreibung

Rimconemy Infected & Automation ist die Bedrohungs- und Automationskampagne. Sie führt Infizierte als Hauptgegner, einen eigenen Storyteller, sichtbare Raidentscheidungen und herstellbare Mechadroids ein.

## Was das gesamte Paket bietet

- Infizierte als zentrale Gegnerrolle
- eigener Storyteller und Incident-Steuerung
- Infizierten-Druck mit sichtbaren Beiträgen
- Farm-, Bewohner-, Produktions- und Verteidigungsdruck
- World-Map-Raids mit Symbol, Anzahl, Pfad und ETA
- sichtbare Raid-Prognose und Auflösungsgrund
- Mechadroids als eigene Einheiten, getrennt von Vanilla-Mechanoids
- Silber als physisches Mechadroid-Upgrade-Material
- Herstellung, Wartung und Einsatz von Mechadroids
- lokale und spätere Outpost-Automation
- manueller und automatisierter Raidmodus
- befestigte Hauptstädte als Endgame-Ziele

## Was es alleine bietet

Allein mit Vanilla-Ressourcen und Vanilla-Energie bietet es eine eigenständige Infizierten-Survival- und Automationskampagne:

```text
Bedrohung beobachten
→ Verteidigung priorisieren
→ Technik erforschen
→ Mechadroids herstellen
→ Arbeit automatisieren
→ Raidrisiken verwalten
```

Ohne Economy funktionieren Mechadroids zunächst lokal. Ohne Outposts werden World-Map-Ziele als Vanilla-Siedlungen oder eigene Szenarien dargestellt.

## Verhalten ohne andere Rimconemy-Pakete

- verwendet Vanilla-Ressourcen für Standalone-Rezepte
- verwendet Vanilla-Handel, wenn Economy fehlt
- verwendet Vanilla-Energie oder einen dokumentierten Minimalmodus, wenn Scavenger fehlt
- verwendet lokale Mechadroid-Aufgaben, wenn Territory fehlt
- aktiviert keine Outpost- oder Wallet-Referenzen ohne Capability-Prüfung
- ersetzt nicht automatisch jede Vanilla-Fraktion als Infizierten-Fraktion

## Integration im Full Overhaul

- Farmfläche, Bewohner, Generatoren, Produktion und Verteidigung kommen aus dem Gesamtprofil.
- Survival & Progression liefert Forschung, XP und Sicherheitsbedürfnis.
- Scavenger liefert Strom, Pfeilturm, Ressourcen und Farmen.
- Economy & Territory liefert Outposts, Proxies, Fraktionen und Weltkarten-Ziele.
- Mechadroids können Outposts betreiben, Proxies warten, Farmen bearbeiten und Verteidigung unterstützen.
- Alle Spielerbewohner tot bedeutet weiterhin Game Over, unabhängig von Outposts oder Mechadroids.

## Abhängigkeiten

- RimWorld 1.6
- Harmony als externe Laufzeitabhängigkeit
- Foundation optional im Standalone-Modus
- **Foundation-Servicebus** erforderlich für die geschlossene Full-Profile-Integration
- gemeinsamer Interface-Vertrag: [`../INTERFACE_CONTRACT.md`](../INTERFACE_CONTRACT.md)
- Survival, Scavenger und Economy optional im Standalone-Modus

## Save-Risiko

Hoch. Mechadroids, aktive Raids, Storyteller-Zustände, Infektionswerte und Automationsaufträge benötigen stabile IDs und Migration. Entfernen aus einem laufenden Save darf nicht still erfolgen.

## Definition of Done für dieses Paket

- eigener Storyteller kann eine Infizierten-Bedrohung erzeugen
- jeder Bedrohungsanstieg nennt sichtbare Ursachen
- Raid-Symbole, Anzahl, Pfad und ETA sind sichtbar
- Mechadroid ist nicht automatisch ein Vanilla-Mechanoid
- Silber wird als Upgrade-Material verwendet, ohne Credits zu werden
- mindestens eine Automationsaufgabe funktioniert lokal
- manuelle und automatisierte Raidentscheidung unterscheiden sich sichtbar
- fehlende optionale Pakete führen zu einem klaren Standalone-Modus
