# API-INCIDENT-01 – Storyteller, IncidentWorker, Wealth-Raids

Status: UNVERIFIED
Owner: Infected & Automation

## Zweck

Bevor ein eigener Raid-Provider implementiert wird, muss klar sein, wie RimWorld-1.6 `IncidentDef`, `IncidentWorker` und `StorytellerComp` zusammenarbeiten. Vanilla Wealth-Raids bleiben separat klassifiziert und werden nicht pauschal unterdrückt.

## Gesuchte Anker

- `IncidentDef`, `IncidentWorker`
- `StorytellerComp`, `StorytellerDef`
- `IncidentParms`
- Main-Thread-Auslöser

## Besitzentscheidung

- Infected & Automation besitzt `Rimconemy_InfectedRaidIncident`, `IncidentStub`, `ThreatAggregator`.
- Vanilla-`WealthWatcher`/`WealthRaid` werden **nicht** nulliert; sie sind explizit `separate Policypfad`.
- Quest- und DLC-Incidents bleiben funktional.

## Minimaler Spike-Test

1. `IncidentDef` lädt ohne TypeLoadException.
2. IncidentWorker registriert genau einen eigenen Provider im Full Profile.
3. Storyteller löst Druckanstieg → die vorgesehene Anzahl Providertickets aus.
4. Vanilla Wealth-Raid und Rimconemy Incident laufen unabhängig.
5. UI zeigt Ursachen, Faktoren, Trend, ETA.

## Belegschema

- Symbol gesucht: IncidentDef, IncidentWorker, StorytellerComp
- Symbol gefunden: UNVERIFIED
- Def-/XML-Beleg: `mods/05-Rimconemy-Infected-Automation/Defs/Incidents/InfectedRaid.xml`
- Testaktion: oben beschrieben
- Ergebnis: UNVERIFIED
- Belegpfade: `mods/FALSIFICATION_REPORTS/rimconemy.infectedautomation__ThreatPressure.md`, `...__InfectedRaid.md`

## Exit

`READY` erst nach lokalem Nachweis, dass `IncidentCategory` und Storytellercomp ohne direkten Patch und ohne Full-Profile-Doppelung funktionieren.
