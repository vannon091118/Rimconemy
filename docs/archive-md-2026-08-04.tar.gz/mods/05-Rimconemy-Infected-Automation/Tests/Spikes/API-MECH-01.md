# API-MECH-01 – Biotech, Mechanitor, Mechadroids

Status: UNVERIFIED
Owner: Infected & Automation

## Zweck

Mechadroids sind eine eigene Einheit-/Auftragsdomäne, getrennt von Vanilla Mechanoids (Biotech). Vor jeder Code-Implementierung stellt der Spike sicher, dass kein Verhalten wie `IsMechanoid` still übernommen wird.

## Gesuchte Anker

- `PawnKindDef` mit `canBeColonist = false`
- Eigene `FactionDef` ohne Mechanitor
- Wartungs-/Energie-Comp als Vanilla-konforme kleine Comps oder Eigendokumentation

## Besitzentscheidung

- Infected & Automation besitzt `Rimconemy_MechadroidLabourer` (PawnKind), `Rimconemy_PlayerAutomationFaction`, `MechadroidUnit`.
- Mechanitor-System gehört zu Biotech bzw. Vanilla-Mechanoids; kein Read oder Write dorthin.
- Mechadroid-Aufträge werden als eigene Liste/Jobdriver gekennzeichnet und nicht im `MainTabWindow` als Kolonist gerendert.

## Minimaler Spike-Test

1. Mechadroid-PawnKind erzeugen und mit Save/Load prüfen.
2. Mechanitor-Vanillasystem separat aktiv lassen – kein unbeabsichtigter Mech-Merger.
3. Wartung, Energie, ID und Status über Save/Load und Mapwechsel stabil.
4. Mechadroid verhindert niemals das Game-Over aus Survival & Progression.

## Belegschema

- Symbol gesucht: IsMechanoid, CompOverseer, Mechanitor-Klasse
- Symbol gefunden: UNVERIFIED
- Def-/XML-Beleg: `mods/05-Rimconemy-Infected-Automation/Defs/PawnKinds/Mechadroid.xml`, `.../Defs/Factions/InfectedAndAutomation.xml`
- Testaktion: oben beschrieben
- Ergebnis: UNVERIFIED
- Belegpfad: `mods/FALSIFICATION_REPORTS/rimconemy.infectedautomation__MechadroidJob.md`

## Exit

`READY` erst nach lokalem 1.6-Beleg, dass `Rimconemy_MechadroidLabourer` nicht `IsMechanoid` erbt oder in einen Mechanitor-Lifecycle gerät.
