# Story Events — Preset-Ordner

> **Owner:** Infected & Automation (Story-/Threat-Domäne, Phase 1)
> **Status:** `SCAFFOLD` — RimWorld-ladbare Defs, **keine** Auswahl-/Effekt-Engine (PLANNED)
> **Vertrag:** [`docs/H2-story-contract.md`](../../../docs/H2-story-contract.md)

## Zweck

Dieser Ordner ist die Schreibfläche für neue Story-Events. Jedes Event ist eine
eigene XML-Datei im RimWorld-Def-Format und wird von RimWorld über die
Def-Klasse `Rimconemy.InfectedAutomation.Story.StoryEventDef` geladen.

**Wichtig:** Es gibt noch keine Engine, die Events auswählt oder ausführt.
Die Presets sind bis Phase 1 deklarative Daten — sie brechen nichts, tun aber
auch noch nichts im Spiel. Das ist Absicht (HANDOFF §2: keine übererfüllten
Claims, `SCAFFOLD` statt `IMPLEMENTED`).

## Dateien

| Datei | Inhalt |
|---|---|
| `Rimconemy_SupplyShortage.xml` | MVP-Event 1 — Versorgungskrise (H2 §2 Event 1) |
| `Rimconemy_IdeologyConflict.xml` | MVP-Event 2 — Ideologischer Konflikt (H2 §2 Event 2) |
| `Rimconemy_ExternalThreat.xml` | MVP-Event 3 — Äußere Bedrohung (H2 §2 Event 3) |
| `TEMPLATE_NewEvent.xml` | Kopiervorlage für neue Events (Platzhalter `XXXXX`) |
| `README.md` | dieses Dokument |

## Neues Event anlegen (Checkliste)

1. `TEMPLATE_NewEvent.xml` kopieren und umbenennen: `Rimconemy_<Kurzname>.xml`
   (Ownership-Regel: Präfix `Rimconemy_`; Familienpräfix optional, z.B.
   `Rimconemy_Discovery_Ruin`).
2. `defName` eindeutig und stabil vergeben. **Nie umbenennen**, sobald das
   Event im Save-State referenziert wird (StoryState.LastEventId / FollowUpIds).
3. `eventFamily` aus der 8er-Liste (H2 §3) wählen:
   `SupplyCrisis`, `IdeologyConflict`, `ExternalThreat`, `Discovery`,
   `TechOpportunity`, `MoralChoice`, `RestRecovery`, `TurnPoint`.
4. `escalationBand` <= `MaxEscalationBand` des Zielprofils setzen (H2 §1).
5. `weights`/`cooldownDays` pro Profil befüllen. Fehlt ein Profil-Eintrag,
   wird das Event dort nicht gewählt (Dokumentation im Feld kommentieren).
6. `prerequisites` (müssen ALLE wahr sein) und `exclusions` (JEDER verhindert)
   deklarativ notieren — Bezug auf H4-`StorageSnapshot`/H3-`IdeologySnapshot`-
   Felder. `>` im XML als `&gt;` schreiben.
7. `choices` mit eindeutigen `choiceId`s und deklarativen `effects` füllen.
   Option `Ignore` immer vorsehen (Eskalationspfad).
8. `followUpIds` nur eintragen, wenn ein Folge-Event existiert oder geplant ist.
9. `determinismKey` mit den tatsächlich verwendeten Eingaben formulieren.
10. RimWorld starten → Def-Load ohne Fehler in `Player.log` prüfen.
    (`Rimconemy.InfectedAutomation` lädt; das Event erscheint in Def-Debug.)

## Def-Schema (Feld → Bedeutung)

Siehe XML-Kommentare in `TEMPLATE_NewEvent.xml`. Kernregeln:

- **Tage statt Ticks:** `cooldownDays` ist in Tagen; 1 Tag = 60.000 Ticks
  (H1 F6). Die Engine konvertiert.
- **Dictionary-Syntax:** `<weights><ProfilId>Wert</ProfilId></weights>`.
- **Liste:** `<prerequisites><li>…</li></prerequisites>`.
- **Choice:** `<li Class="Rimconemy.InfectedAutomation.Story.StoryEventChoiceDef">`.
- **Escalation:** `escalationTarget` = `ThreatPressure` oder `IdeologyTension`;
  `escalationModifier` wird bei `Ignore` addiert.

## Konventionen & Falsifizierung

- Determinismus: stabile Sortierung, gespeicherte IDs, keine Systemzeit
  (ROADMAP §4).
- Idempotenz: `StoryState.IdempotencyKeys` verhindern Doppelausführung.
- Save: Cooldowns/Seeds werden in `StoryState` (H2 §5) gespeichert.
- Ein Event, das per Save/Load doppelt feuert, ist ein Falsifikationsfall
  (HANDOFF Gate G2).
