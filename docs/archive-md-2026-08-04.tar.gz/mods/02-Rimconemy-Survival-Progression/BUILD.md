# Build-Vertrag – Rimconemy Survival & Progression

## Ausgabe

```text
Assemblies/Rimconemy.SurvivalProgression.dll
```

## Source-Verantwortung

`Source/` enthält Needs, Arbeitserfahrung, Spezialisierung, Forschung, Szenario und Game-Over-Logik. Foundation-, Scavenger-, Economy- und Infected-Code wird nicht kopiert.

## Standalone-Build

Der Build darf nur RimWorld-1.6-Assemblys und Harmony voraussetzen. Optionale Foundation-Integration wird über den late-bound Registry-/Servicebus und Capability-Prüfung aktiviert; sie ist kein Compile-Zwang. Ohne Foundation bleibt nur der Standalone-Modus.

## Validierung

- Vanilla-Ressourcen und Vanilla-Gebäude bilden einen spielbaren Standalone-Modus.
- Needs, XP, Forschung und Game Over funktionieren ohne andere Rimconemy-Pakete.
- fehlende optionale Integrationen werden ohne Typ-/Def-Fehler behandelt.
