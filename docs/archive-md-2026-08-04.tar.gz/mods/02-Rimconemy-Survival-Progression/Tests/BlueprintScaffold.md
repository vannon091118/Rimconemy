# Q13 – Paket-02-Blueprint und Scaffold

Status: IMPLEMENTED_UNVERIFIED
Owner: Survival & Progression

## Startzustand

- RimWorld 1.6 with Core and Harmony.
- `rimconemy.survivalprogression` enabled without Foundation or packages 03–05.
- No Needs-, XP-, Research- or Game-Over gameplay implementation is expected in Q13.

## Aktion

1. Build `Rimconemy.SurvivalProgression.csproj` in Release mode with `-p:IsolatedOutputPath=.build/package-02/` for the isolated gate output.
2. Inspect the project references for optional Rimconemy assemblies.
3. Start RimWorld and activate `Rimconemy Survival & Progression` explicitly in the main-menu **Mods** list; a DLL merely present in `Mods/` is not loaded.
4. Keep Harmony before Package 02 and choose **Apply/Übernehmen**.
5. Fully exit RimWorld and restart it, regardless of whether RimWorld requests a restart.
6. Run the package in a user-controlled RimWorld load test (`NEW_GAME` remains user-only).
7. Check the package bootstrap log and confirm that no gameplay claim is made by the scaffold.

## Expected build-/source-beleg

- Default deployment output: `Assemblies/Rimconemy.SurvivalProgression.dll`.
- Isolated gate output: `.build/package-02/Rimconemy.SurvivalProgression.dll` when `-p:IsolatedOutputPath=.build/package-02/` is supplied.
- Build has 0 warnings and 0 errors.
- The project references RimWorld managed assemblies and Harmony only; no Foundation project or DLL reference exists.
- Bootstrap logs standalone availability and explicitly identifies the scaffold boundary.

## Expected user-only runtime-/UI-beleg

- The user has explicitly activated Package 02 in the Mods list and restarted RimWorld after applying the load order.
- `[Rimconemy.SurvivalProgression] Standalone bootstrap starting...`
- `[Rimconemy.SurvivalProgression] Package 02 scaffold loaded; gameplay systems remain unimplemented.`
- Visible gameplay/UI function: `N/A` for Q13; the scaffold intentionally exposes only its startup/log marker. Visible Needs/XP/Research/Game-Over functionality belongs to Q14 and is not claimed here.
- No `TypeLoadException`, no missing optional-package reference and no claim that Needs/XP/Research/Game Over are already playable.

## Runtime status

`IMPLEMENTED_UNVERIFIED`: The agent does not start RimWorld, create a new game or inspect `Player.log`. Q13 has no visible gameplay/UI function by design; its runtime evidence is limited to the startup/log marker. Q14 requires `API-NEED-01`, the job/output path, and the explicitly deferred Research-/Game-Over-Lifecycle checks before T1–T5 implementation work can close their gates.
