# API-JOB-01 – Work/XP/Reservation Anker

Status: UNVERIFIED
Owner: Survival & Progression

## Zweck

Vor jeder XP- oder Effizienz-Implementierung wird geprüft, welche Vanilla-Anker WorkGiver, JobDriver, Reservation und Skill-Tracker tragen. Dieser Spike bestätigt keine API-Signatur und erzeugt noch keinen Gameplaycode.

## Gesuchte Anker

- `WorkGiver`
- `JobDriver`
- `ToilReservationManager` / `Reservation`
- Jobabschluss-Hookpunkt

Die konkreten 1.6-Signaturen bleiben offen, weil das vorhandene `Assembly-CSharp.dll` im Forschungs-Setup nicht dekompiliert wird.

## Besitzentscheidung für Q14

- Survival & Progression besitzt drei Rimconemy-Kern-Arbeitsdomänen (`Building`, `Farming`, `Power`).
- Vanilla besitzt übrige Skills, Jobs und Reservationen.
- XP-Commit erfolgt genau einmal pro validiertem Output; die Idempotency-ID `(PackageId, RequestId)` wird in `ProgressionSnapshot` gespeichert.
- Foundation darf nur lesen; Mechadroids erhalten niemals Spieler-XP.

## Minimaler Spike-Test

1. Pawn-Generation mit bekannter Vanilla-WorkType.
2. Reservationsverhalten in 1/50 Pawn-Test (kein Loop).
3. Jobabschluss mit gesetztem Idempotency-Key dokumentieren.
4. Save/Load, Mapwechsel und 50-Pawn-Stresstest.
5. UI zeigt XP je Domäne, Effizienzursache, Trend, Spezialisierung, Game-Over-Status.

## Belegschema

- Symbol gesucht: WorkGiver, JobDriver, Reservation, SkillRecord
- Symbol gefunden: UNVERIFIED
- Def-/XML-Beleg: `mods/VANILLA_DLC_RESEARCH_BASELINE.md`
- Testaktion: oben beschrieben
- Ergebnis: UNVERIFIED
- Belegpfad: `mods/FALSIFICATION_REPORTS/rimconemy.survivalprogression__WorkXp.md`

## Exit

`READY` erst nach lokalem Vanilla-Anker-Beleg und reproduzierbarem 50-Pawn-Stresstest ohne Doppel-XP.
