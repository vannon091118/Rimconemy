# API-NEED-01 – Needs-/Mood-Anker

Status: UNVERIFIED
Owner: Survival & Progression
RimWorld-Build: 1.6.4566 rev579 (User-Player.log); lokale Research-Baseline: 1.6.4566 rev575
DLC: Core, Royalty, Ideology, Biotech, Anomaly, Odyssey

## Zweck

Vor jeder Needs- oder Mood-Implementierung wird geprüft, welche Vanilla-Anker für Nahrung, Sicherheit und Soziales tatsächlich verwendet werden können. Dieser Spike bestätigt keine API-Signatur und erzeugt noch keinen Gameplaycode.

## Gesuchte Anker

- `Need`
- `Pawn_NeedsTracker`
- `Mood`
- `MentalBreak`
- Trait-, Gene-, Ideology- und Hediff-Einflüsse auf die sichtbare Needs-/Mood-Ausgabe

Die konkreten 1.6-Klassen-, Feld- und Methodensignaturen bleiben offen, bis sie gegen die lokale Assembly-/Def-Baseline nach dem Projektvorgang bestätigt wurden. Keine Signatur wird aus diesem Plan direkt in `Source/` übernommen.

## Besitzentscheidung für Q14

- Survival & Progression besitzt nur die drei Rimconemy-Kernbedürfnisse und den versionierten `ProgressionSnapshot`.
- Vanilla besitzt Gesundheit, Verletzungen, Temperatur, Krankheit, Erschöpfung und übrige Vanilla-Bedürfnisse.
- Traits, Genes, Ideology, Psycasts und Hediffs werden als Einflussquellen klassifiziert; sie werden nicht still überschrieben.
- Foundation darf später nur einen Read-only-Snapshot beziehungsweise eine Diagnose lesen.

## Minimaler Spike-Test

1. Lokale Def-/Assembly-Referenz nach `VANILLA_DLC_RESEARCH_BASELINE.md` festlegen.
2. Einen einzelnen Pawn im Core-/Full-DLC-Testfall erzeugen.
3. Nahrung, Sicherheit und Soziales getrennt beobachten und die jeweils sichtbare Vanilla-Quelle notieren.
4. Je einen relevanten Trait-, Gene-, Ideology- und Hediff-Einfluss klassifizieren, ohne globale Werte zu überschreiben.
5. Prüfen, ob ein bestehender Mood-/Mental-Break-Pfad den vorgesehenen UI-/Event-Anker liefert.
6. SAVE_LOAD, MAP_CHANGE, UI_REASON und DLC_SCOPE als geplante User-Belege dokumentieren; kein Agenten-Spielstart.

## Statische Anker-Befunde (Online-/Doku-Recherche 2026-08-02)

Die folgenden Symbole und Def-Familien sind **statisch** auffindbar. Sie bleiben Teil des `UNVERIFIED`-Spikes, weil das Verhalten zur Laufzeit (UI-Sichtbarkeit, Save/Lifecycle, Doppelbesitz-Sicherheit) noch nicht belegt ist. Keine Signatur darf vor `READY` in `Source/` landen.

### Lokale Assembly-/Def-Belege (`/home/vannon/GOG Games/RimWorld`)

**Assembly** `game/RimWorldLinux_Data/Managed/Assembly-CSharp.dll` (Strings-Stichprobe, keine Decompile-Verifikation der Feld-/Methodensignaturen):

- `Pawn_NeedsTracker` (RimWorld-Pfad `Pawn/Trackers/Needs/Pawn_NeedsTracker.cs`)
- `NeedDef`, `NeedDefOf`
- Need-Unterklassen: `Need_Food`, `Need_Rest`, `Need_Comfort`, `Need_Beauty`, `Need_Outdoors`, `Need_RoomSize`, `Need_Joy`/`Need_Play`, `Need_Chemical`/`Need_Chemical_Any`, `Need_Learning`, `Need_Mood`, `Need_Authority` (Royalty), `Need_Deathrest` (Biotech), `Need_KillThirst`, `Need_MechEnergy`, `Need_Sadism`, `Need_Seeker`, `Need_Suppression`
- MentalBreak-/MentalState-Familie: `MentalBreaker`, `MentalState`, `MentalStateDef`, `MentalBreakDef`, `MentalBreakWorker_Catatonic`, `MentalStateWorker_TargetedInsultingSpree`, `MentalState_CocoonDisturbed`, `MentalState_CorpseObsession`, `MentalState_EntityLiberator`
- Einflussquellen: `ForcedTraits`, `MaximumAgeTraits`, `MinimumAgeTraits`, `Hediff_AddedPart`, `Hediff_BloodRage`, `Hediff_Deathrest`, `Thought_Situational`/`Thought_Memory`-Stichproben (über `ThoughtWorker_*`)

**Core-/DLC-Def-Pfade:**

- `game/Data/Core/Defs/NeedDefs/Needs.xml`
- `game/Data/Royalty/Defs/NeedDefs/Needs.xml`
- `game/Data/Ideology/Defs/NeedDefs/Needs.xml`
- `game/Data/Biotech/Defs/NeedDefs/Needs.xml`
- `game/Data/Core/Defs/MentalStateDefs/MentalStates_Mood.xml`, `MentalStates_Special.xml`
- `game/Data/Ideology/Defs/MentalStateDefs/MentalStates_Mood.xml`, `MentalStates_Special.xml`
- `game/Data/Biotech/Defs/MentalStateDefs/MentalStates_BabyFits.xml`, `MentalStates_Special.xml`
- `game/Data/Anomaly/Defs/MentalStateDefs/MentalStates_Mood.xml`, `MentalStates_Special.xml`
- `game/Data/Royalty/Defs/MentalStateDefs/MentalStates_Special.xml`

### Öffentliche Modding-API (RimWorld 1.5/1.6 stabil)

Aus `https://rimworldwiki.com/wiki/Modding` und `https://ludeon.com/forums/index.php?board=14.0`:

- `Need` (Basisklasse): `pawn` (`Pawn`), `def` (`NeedDef`), `CurLevel` (float), `CurLevelPercentage`, `MaxLevel`; Lifecycle `SetInitialLevel`, `NeedInterval`, `DoInterval`.
- `Need_Food`, `Need_Rest`, `Need_Comfort`, `Need_Beauty`, `Need_Recreation`, `Need_Mood` als namentlich bekannte Spezialisierungen.
- `Pawn_NeedsTracker` (`Pawn.needs`): `Needs` (Liste), `Mood` (direkter Zugriff auf `Need_Mood`), dynamisches Hinzufügen/Entfernen über `AddOrRemoveNeed(NeedDef, bool checkConfigure = true)` bzw. `TryAddNeed(NeedDef)`.
- `Thought` / `ThoughtDef` / `ThoughtStage`: Stimmungsoffsets (`moodOffset`), situativ oder Memory; Mods erweitern via `ThoughtWorker_*`.
- `MentalStateDef` / `MentalState`: aktiver Laufzeitzustand, verwaltet über `Pawn.MentalState`. Auslöserstufe `MentalBreakIntensity` (Minor/Major/Extreme).
- Mood-Modifikatoren: `Trait`/`TraitDef` (statisch oder konditional, Optimist/Pessimist/Depressive), `Gene`/`GeneDef` (Biotech, u.a. `Gene_Mood`-Ableitungen), Ideology-`Precept` (situative Thoughts), `Hediff`/`HediffDef` (Schmerz, Krankheit, Zustände), `PawnCapacityUtilities` (Consciousness/Pain/Moving als Eingang in Effizienz-/Mood-Berechnung).

### Quellen, die noch vor `READY` zu prüfen sind

- Wiki-Seiten zu `Modding`, `Thoughts`, `MentalStates`, `Need`, `Mood`.
- Ludeon-Foren, board 14.0, mit Entwickleraussagen zu 1.6.
- Lokale Decompile-/Reflection-Prüfung der Felder und Methodensignaturen (`Pawn.needs.Mood.thoughts.memories`, `MentalStateHandler.CurState`, `MentalBreaker.TryAdd`).

## Belegschema

- Symbol gesucht: `Need`, `Pawn_NeedsTracker`, `Mood`, `MentalState`/`MentalBreak`, Trait-/Gene-/Ideology-/Hediff-Einflüsse
- Symbol gefunden: statisch lokal bestätigt (Strings, Core-/DLC-Def-Pfade) und Doku-konsistent; genaue 1.6-Feld-/Methodensignaturen noch nicht durch Decompile/Reflection belegt
- Def-/XML-Beleg: `mods/VANILLA_DLC_RESEARCH_BASELINE.md`, lokale `game/Data/{Core,Royalty,Ideology,Biotech,Anomaly}/Defs/NeedDefs/Needs.xml`, `…/MentalStateDefs/*.xml` (Existenz bestätigt)
- Testaktion: oben beschrieben; nächster sicherer statischer Schritt ist eine Compilierprobe gegen `Assembly-CSharp.dll` für die Surrogate `Pawn_NeedsTracker` und `Need_Mood`, getrennt von jedem Spielstart
- Ergebnis: UNVERIFIED (Spike-Status bleibt bis Save-/UI-/Runtime-Beleg)
- Belegpfade: `mods/FALSIFICATION_REPORTS/rimconemy.survivalprogression__Needs.md`, `mods/02-Rimconemy-Survival-Progression/BLUEPRINT.md`
- Offene Gegenbeweise: Doppelbesitz mit Vanilla-Mood und bestehenden Needs, DLC-Override-Pfade, Save-/Map-Lifecycle, UI-Ursache und -Trend, Mentalstate-Reaktion auf Rimconemy-Need-Änderungen

## Exit-Kriterium

Der Spike darf erst `READY` werden, wenn ein lokaler Assembly-/Def-Beleg die verwendbaren Anker nennt, der Ownership-/Einflussmatrix-Entscheid dokumentiert ist und ein reproduzierbarer Pawn-Test mit UI-/Save-Beleg vorliegt. Bis dahin bleibt der Status `UNVERIFIED`; Q14-T1 ist nicht über die Spike-Vorbereitung hinaus abgeschlossen.
