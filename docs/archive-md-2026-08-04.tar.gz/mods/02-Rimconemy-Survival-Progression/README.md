# Rimconemy Survival & Progression

> Blueprint: [`BLUEPRINT.md`](BLUEPRINT.md) · zentrale Vision: [`../PRODUCT_VISION.md`](../PRODUCT_VISION.md) · Research: [`../VANILLA_DLC_RESEARCH_BASELINE.md`](../VANILLA_DLC_RESEARCH_BASELINE.md)

## Kurzbeschreibung

Rimconemy Survival & Progression ist ein eigenständiges Survival-RPG für RimWorld 1.6. Es macht Nahrung, Sicherheit und Soziales zu den sichtbaren Kernbedürfnissen und verbindet tatsächliche Arbeit mit Erfahrung, Spezialisierung und Forschung.

## Was das gesamte Paket bietet

- Kernbedürfnisse: Nahrung, Sicherheit und Soziales
- angepasste Mood-/Mental-Break-Anbindung
- Arbeit-zu-Erfahrung-System
- Bereichsspezialisierung und Effizienz
- Forschungs- und Technikstufen
- eigener Start-/Szenario-Rahmen
- klarer Game-Over-Zustand, wenn alle direkt kontrollierbaren Spielerbewohner tot sind
- UI für Bedürfnisse, XP, Fortschritt, Engpässe und Game Over
- Vanilla-kompatibler Standalone-Modus

## Wichtig: Mod-Aktivierung in RimWorld

Eine DLL oder ein Mod-Ordner im RimWorld-`Mods/`-Verzeichnis ist **noch nicht geladen**. Für einen Paket-02-Runtime-Test muss `Rimconemy Survival & Progression` im RimWorld-Hauptmenü unter **Mods** ausdrücklich aktiviert werden. Danach:

1. `Harmony` vor Paket 02 in der Load Order belassen.
2. Foundation nur aktivieren, wenn die optionale Integration mitgetestet wird; Paket 02 bleibt ohne Foundation standalone.
3. **Apply/Übernehmen** wählen.
4. RimWorld vollständig beenden und anschließend neu starten — unabhängig davon, ob RimWorld dazu auffordert.
5. Erst nach diesem Neustart `Player.log` auf die Paket-02-Scaffold-Zeilen und die sichtbare Paket-/Scaffold-Funktion prüfen.

Das bloße Ablegen der DLL im Ordner erzeugt keinen Runtime-Beleg.

## Was es alleine bietet

Allein mit Vanilla-Ressourcen und Vanilla-Gebäuden entsteht ein vollständiger zusätzlicher Spielkreislauf:

```text
Bedürfnisse beobachten
→ Arbeitsbereiche wählen
→ Erfahrung sammeln
→ Spezialisieren
→ Forschung freischalten
→ Kolonie stabilisieren
```

Der Spieler erhält einen eigenständigen Survival-RPG-Mehrwert, auch wenn Bauschutt, Outposts und Infizierte nicht installiert sind.

## Verhalten ohne andere Rimconemy-Pakete

- verwendet Vanilla-Ressourcen, Gebäude und Arbeitsarten
- verwendet einen kompatiblen Vanilla-Storyteller
- nutzt Vanilla-Bau- und Nahrungssysteme
- zusätzliche Infrastruktur-Boni werden nicht erfunden
- fehlende Infizierten-, Economy- oder Outpost-Funktionen werden im UI als nicht aktiv angezeigt

## Integration im Full Overhaul

- Arbeit an Scavenger-Gebäuden gibt passende Erfahrung.
- Farm- und Energiearbeit kann den eigenen Skill-/XP-Bereich nutzen.
- Forschung schaltet Bauschuttbau, Wasser, Strom, Pfeilturm, Mechadroids und Outposts frei.
- Sicherheit wird durch Basis, Verteidigung, Infizierten-Druck und territoriale Verbindung beeinflusst.
- Game Over bleibt lokal an direkt kontrollierbare Spielerbewohner gebunden; abstrakte Outpost-Bevölkerung rettet die Kolonie nicht.

## Abhängigkeiten

- RimWorld 1.6
- Harmony als externe Laufzeitabhängigkeit
- Foundation optional für gemeinsames Dashboard und Log
- **Foundation-Servicebus** erforderlich, wenn dieses Paket im Full Profile mit den anderen Paketen integriert werden soll; ohne Foundation bleibt der Standalone-Modus
- gemeinsamer Interface-Vertrag: [`../INTERFACE_CONTRACT.md`](../INTERFACE_CONTRACT.md)
- Scavenger optional für neue Arbeits- und Bauinhalte
- keine direkte Pflichtabhängigkeit von Economy, Territory oder Infected

## Save-Risiko

Hoch. Needs, XP, Forschung, Szenariozustände und Game-Over-Status müssen versioniert gespeichert werden. Entfernung aus einem Save mit eigenen Need-/XP-Daten darf nicht still erfolgen.

## Definition of Done für dieses Paket

- Standalone-Spiel mit Vanilla-Ressourcen ist nachvollziehbar
- jede der drei Kernbedürfnisse ist sichtbar und erklärbar
- Arbeit verändert messbar XP oder Effizienz
- Forschung schaltet mindestens einen überprüfbaren Fortschritt frei
- letzter direkt kontrollierbarer Bewohner löst Game Over aus
- fehlende Feature-Pakete verursachen keine kaputten Referenzen
