# Package 02 patch scope

Status: NOT_REQUIRED_FOR_Q13_SCAFFOLD
Owner: Survival & Progression
DLC condition: none for the standalone bootstrap scaffold.
Load-order assumption: Core/DLCs -> Harmony -> optional Foundation -> Survival & Progression.
Runtime prerequisite: the package must be explicitly enabled in RimWorld's main-menu Mods list, Harmony must remain before it in Load Order, **Apply/Übernehmen** must be selected, and RimWorld must then be fully exited and restarted regardless of whether it requests a restart. Only afterward may the user check both the Package-02 `Player.log` lines and the visible package/scaffold function. A DLL merely present in `Mods/` is not loaded.

The Q13 scaffold contains no gameplay hook and therefore adds no Harmony patch or
PatchOperation. Needs, job completion, research and Game Over hooks are deferred
to Q14 and must first be classified through `API-NEED-01` and `API-JOB-01`.

Exit criterion: add only the smallest documented vanilla Def/Patch/Source hook once
the relevant spike is supported by the local research baseline and its falsification
report contains the required A–G test plan.
