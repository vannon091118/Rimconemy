# Rimconemy Foundation

> Blueprint: [`BLUEPRINT.md`](BLUEPRINT.md) · zentrale Vision: [`../PRODUCT_VISION.md`](../PRODUCT_VISION.md) · Research: [`../VANILLA_DLC_RESEARCH_BASELINE.md`](../VANILLA_DLC_RESEARCH_BASELINE.md)

## Kurzbeschreibung

Rimconemy Foundation ist die gemeinsame technische und diagnostische Basis der Rimconemy-Paketfamilie. Allein installiert ist es ein nutzbares Vanilla-Informationspaket; zusammen mit den übrigen Paketen stellt es gemeinsame UI-, Save-, Versions- und Integrationsdienste bereit.

## Was das gesamte Paket bietet

- zentrales Kolonie-Dashboard
- Ressourcen-, Produktions- und Verbrauchsübersicht
- Ereignis- und Transaktionslog
- Modus-/Profilanzeige: Vanilla, Teilprofil oder Full Overhaul
- Diagnose fehlender oder inkompatibler Rimconemy-Pakete
- Save-Schema-Version und Migrationsstatus
- gemeinsame UI-Komponenten
- gemeinsame stabile IDs und Capability-Prüfungen
- gemeinsame Ereignis- und Datenverträge für Feature-Pakete

Foundation simuliert selbst keine Wirtschaft, keine Infizierten und keine Outposts. Es stellt dafür die nachvollziehbare Infrastruktur bereit.

Im Full Profile stellt Foundation zusätzlich den **Foundation-Servicebus** als late-bound Registry-/Servicebus bereit. Ohne Foundation bleibt das Paket standalone; Feature-Pakete dürfen dann keine Cross-Paket-Integration behaupten.

## Wichtig: Mod-Aktivierung in RimWorld

Eine DLL oder ein Mod-Ordner im RimWorld-`Mods/`-Verzeichnis ist **noch nicht geladen**. Für jeden Runtime-Test muss der Mod im RimWorld-Hauptmenü unter **Mods** ausdrücklich aktiviert werden. Danach:

1. `Harmony` vor `Rimconemy Foundation` in der Load Order belassen.
2. `Rimconemy Foundation` aktivieren; optionale Pakete nur aktivieren, wenn sie mitgetestet werden.
3. **Apply/Übernehmen** wählen.
4. RimWorld vollständig beenden und anschließend neu starten — unabhängig davon, ob RimWorld dazu auffordert.
5. Erst nach diesem Neustart `Player.log` und den sichtbaren Foundation-Tab prüfen.

Das bloße Ablegen der DLL im Ordner erzeugt keinen Runtime-Beleg.

## Was es alleine bietet

Mit `Harmony` und RimWorld 1.6 kann Foundation allein geladen werden und bietet:

- Profil-, Mod- und DLC-Diagnose-Dashboard
- Vanilla-Ressourcen-/Power-Anzeige erst nach bestätigtem `API-RESOURCE-01`-Anker
- keine erfundenen Nullwerte; nicht belegte Domänen erscheinen als `Unavailable`/offener Spike
- Spielereignis-Log
- aktive Mod- und DLC-Übersicht
- Save-/Versionsdiagnose
- Debug-/Diagnoseansicht für Entwickler, ohne Gameplay-Cheats vorauszusetzen

Damit ist Foundation ein eigenständiges Informations- und Planungsmod und keine unsichtbare Bibliothek.

## Verhalten ohne andere Rimconemy-Pakete

- Vanilla-Ereignisse sowie bestätigte Vanilla-Read-Models werden angezeigt; Ressourcen-/Power-Read-Models bleiben bis `API-RESOURCE-01` offen.
- Nicht vorhandene Rimconemy-Funktionen werden als `nicht installiert` dargestellt.
- Foundation erzeugt keine Ersatz-Wallets, keine Ersatz-Outposts und keine simulierten Infizierten.
- Das Dashboard nennt immer die aktive Profilart.

## Integration im Full Overhaul

Foundation verbindet die sichtbaren Zustände der übrigen Pakete:

```text
Survival/Progression → Bedürfnisse, XP, Forschung
Scavenger            → Bauschutt, Farmen, Strom
Economy/Territory     → Wallets, Märkte, Outposts, Proxies
Infected/Automation   → Druck, Raids, Mechadroids
```

Jede Integration wird über Capability-Prüfung aktiviert. Direkte Referenzen auf fehlende optionale Pakete sind verboten.

## Abhängigkeiten

- RimWorld 1.6
- Harmony als externe Laufzeitabhängigkeit
- keine Pflichtabhängigkeit von XML Extensions, HugsLib, VEF oder Vehicle Framework
- **Foundation-Servicebus** im Full Profile: late-bound, versionierte Contracts; Feature-Pakete werden nicht direkt referenziert
- gemeinsamer Interface-Vertrag: [`../INTERFACE_CONTRACT.md`](../INTERFACE_CONTRACT.md)

## Save-Risiko

Niedrig bis mittel. Dashboard-Einstellungen und Log-Konfiguration sind persistent. Foundation darf keine Feature-Daten löschen, wenn ein Feature-Paket fehlt.

## Definition of Done für dieses Paket

- lädt alleine mit Vanilla und Harmony
- zeigt den aktiven Modus sichtbar
- zeigt fehlende optionale Pakete ohne Fehlerdialog-Spam
- speichert und lädt Einstellungen
- erkennt eine inkompatible Save-Schema-Version
- kann im Full Overhaul Daten aller vier Feature-Pakete anzeigen
