# Build-Vertrag – Rimconemy Foundation

## Ziel

Foundation wird als eigene RimWorld-Mod mit eigener Assembly gebaut und darf unabhängig von den vier Feature-Paketen kompiliert und validiert werden.

## Ausgabe

```text
Assemblies/Rimconemy.Foundation.dll
```

## Source-Verantwortung

`Source/` enthält ausschließlich Foundation-Code:

- Profil- und Capability-Prüfung
- Save-/Versionsvertrag
- Dashboard und Diagnose
- gemeinsame stabile IDs und Datenverträge
- Log-/Snapshot-Infrastruktur

Feature-spezifische Regeln gehören nicht in Foundation.

## Referenzen

Die konkreten Referenzpfade werden in der Build-Konfiguration der Zielumgebung eingetragen. Verbindlich sind nur:

- RimWorld-1.6-Assemblys
- Harmony-Referenz für Laufzeit-Patches
- keine Referenz auf eine andere Rimconemy-Assembly als Pflicht für den Standalone-Build
- Full Profile stellt den Registry-/Servicebus als Laufzeitdienst bereit; Feature-Pakete werden late-bound über Vertragsnamen und Versionen erkannt

## Validierung

- kompiliert ohne Source-Dateien der Feature-Pakete
- XML/Defs laden mit Foundation allein
- Save-/Profilprüfung kann einen fehlenden Feature-Paketstatus anzeigen
- keine direkten Klassenreferenzen auf optionale Pakete
