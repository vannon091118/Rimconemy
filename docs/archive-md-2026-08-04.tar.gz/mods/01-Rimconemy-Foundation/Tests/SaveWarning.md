# F4 – Save-/Migrationswarnung

Status: IMPLEMENTED_UNVERIFIED
Owner: Foundation

## Startzustände

- Neues Foundation-Spiel mit Schema v1.
- Separater Testsave ohne Foundation-Schema (v0/fehlender Block).
- Eventlog-Nachricht mit Pipe-Zeichen und UTF-8-Inhalt.

## Aktion

1. Foundation-Event erzeugen und Save schreiben.
2. Spiel vollständig beenden und Save laden (`SAVE_LOAD`).
3. Dashboard öffnen und Schema-/Migrationsstatus prüfen.
4. Alten Save laden und danach erneut speichern.
5. Bei fehlendem Feature-Paket prüfen, dass keine Feature-Daten erzeugt oder gelöscht werden.

## Erwarteter UI-/Log-/Save-Beleg

- `foundationSchemaVersion` und `foundationProfileStatus` werden geladen.
- v0 wird kontrolliert als `Migrated` mit sichtbarer Begründung dargestellt.
- Eventlog-Einträge inklusive Pipe/UTF-8 bleiben inhaltlich und mit ursprünglicher Sequenz erhalten.
- Profilstatus, fehlende Paket-IDs und registrierte Paketversionen werden gemeinsam aktualisiert.
- Kein stilles Löschen, kein Phantomzustand, keine wiederholte Event-Aufblähung.

## Aktueller Nachweis

- Scribe-/Migration-/historische Eventpfade sind im Source implementiert.
- Tatsächlicher Save/Load-Zyklus bleibt `UNVERIFIED` und muss vom User ausgeführt werden.
- GameComponent-Registrierung ist separat in `Tests/Spikes/API-FOUNDATION-GAMECOMP-01.md` erfasst.
