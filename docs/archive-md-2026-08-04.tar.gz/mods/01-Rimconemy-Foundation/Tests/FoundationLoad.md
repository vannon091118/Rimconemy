# F1 – Foundation standalone load

Status: IMPLEMENTED_UNVERIFIED
Owner: Foundation

## Startzustand

- RimWorld `1.6.4566 rev575` (lokale Research-Baseline; Buildabweichung zu rev579 bleibt im Bericht offen).
- Core plus optional Harmony, danach ausschließlich `rimconemy.foundation`.
- Keine Pakete 02–05 aktiviert.
- Erwartete Load Order: Core/DLCs → Harmony → Foundation.

## Aktion

1. Die Foundation-DLL im Mod-Ordner allein reicht nicht: RimWorld öffnen und `Rimconemy Foundation` im Hauptmenü unter **Mods** aktivieren.
2. Load Order prüfen: `Harmony` steht vor `Rimconemy Foundation`; danach **Apply/Übernehmen** wählen.
3. **Apply/Übernehmen** wählen.
4. RimWorld vollständig beenden und anschließend neu starten — unabhängig davon, ob der Modbildschirm dazu auffordert. Erst dieser Neustart ist der zu prüfende Load-Vorgang.
5. Neues Spiel anlegen (`NEW_GAME`).
3. Debug-Log auf XML-, TypeLoad- und Bootstrap-Fehler prüfen.
4. Foundation-Tab öffnen.
5. Foundation erneut mit einem Core-only-Profil ohne optionale DLCs prüfen (`DLC_SCOPE`).

## Erwarteter Beleg

- Log enthält genau einen Foundation-Bootstrap-Zyklus mit Registry, Profil und ServiceBus.
- UI zeigt `Standalone (Foundation only)` und fehlende optionale Pakete/DLCs explizit.
- Kein Def referenziert Paket 02–05.
- Fehlende DLCs führen zu `Partial`/Diagnose, nicht zu einem stillen Full Profile.

## Aktueller Nachweis

- Lokaler Release-Build: aus HANDOFF_QUEUE.md übernommen, 0 Warnungen/0 Fehler.
- Echter Spielstart und UI-/Log-Beleg: `UNVERIFIED`; ausschließlich User darf ihn ausführen.
- Def-/Tab-Auflösung ist separat in `Tests/Spikes/API-FOUNDATION-UI-01.md` erfasst.
