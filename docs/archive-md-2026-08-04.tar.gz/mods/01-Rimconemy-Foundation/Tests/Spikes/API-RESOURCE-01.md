# API-RESOURCE-01 – Foundation Vanilla-Ressourcen-/Power-Read-Model

Status: UNVERIFIED
Owner: Foundation
RimWorld-Build: 1.6.4566 rev575 (lokale Baseline; Runtime-Build muss User klären)
DLC: Core, Royalty, Ideology, Biotech, Anomaly, Odyssey

## Symbol-/Def-Suche

Noch nicht als konkrete 1.6-Signatur bestätigt. Die lokale `Assembly-CSharp.dll` und Core-/DLC-Defs sind Referenzmaterial, kein fertiger API-Beleg.

## Minimaler Test

1. Lokalen Assembly-/Def-Anker für Colony-Ressourcenbestand, Verbrauch/Produktion und Power-Zustand identifizieren.
2. Foundation allein mit einem neuen Spiel laden.
3. Einen Ressourcen-/Power-Zustand mit vorhandenem Input, fehlendem Input und nicht verfügbarer Domäne beobachten.
4. Dashboard muss Wert, Ursache und Status (`Unavailable`/`Blocked` statt erfundener `0`) zeigen.
5. Save/Load und identische Eingaben vergleichen.

## Erwartetes Ergebnis

Nur bestätigte, read-only Vanilla-Daten werden angezeigt. Foundation schreibt keine Ressourcen, Powernetze oder Featurezustände.

## Aktueller Stand

Der Foundation-MVP zeigt Profil-, DLC-, Paket-, Save- und Eventdiagnose. Ressourcen-/Power-Abfragen bleiben bis zum lokalen API-/Def-Beleg absichtlich offen; der Agent rät keine 1.6-Signatur.

## Belegpfade

- `mods/01-Rimconemy-Foundation/Tests/SnapshotUnavailable.md`
- `mods/FALSIFICATION_REPORTS/rimconemy.foundation__Servicebus.md`
- lokale Assembly-/Def-Pfade aus `mods/VANILLA_DLC_RESEARCH_BASELINE.md`
