# API-FOUNDATION-INVENTORY-01

Status: **UNVERIFIED**
RimWorld-Build: 1.6.4566 rev579 (user-bestätigt)
DLC: Core, Royalty, Ideology, Biotech, Anomaly, Odyssey
Owner: Foundation
Blockiert: Q15 (Foundation Def-Inventur) bis User-Runtime-Beleg
Bezug: `mods/01-Rimconemy-Foundation/Source/Catalog/FoundationDefInventory.cs` · `mods/01-Rimconemy-Foundation/Source/UI/FoundationDashboard.cs` · `mods/01-Rimconemy-Foundation/Languages/{English,German}/Keyed/Foundation.xml`

## Zweck

Stabile Verse.\*/Assembly-CSharp-Read-only-Verkettung, die ohne Reflection und ohne private Felder für jeden Rimconemy-Paket-Eigentümer (`rimconemy.foundation`, `rimconemy.survivalprogression`, `rimconemy.scavengerinfrastructure`, `rimconemy.economyterritory`, `rimconemy.infectedautomation`) zählt, wie viele Defs aus jeder unterstützten Def-Subklasse das Paket tatsächlich beigetragen hat. Vorbereitung für `P28` (Def-Inventur in FoundationDashboard) und die spätere Auflösung von `API-RESOURCE-01` (gleiche DefDatabase-Lesepfad-Mechanik).

## Gesuchte Anker

- `Verse.LoadedModManager.RunningMods` – stabile öffentliche Liste derzeit laufender Mods (RimWorld 1.5+/1.6+ Modding-API).
- `Verse.ModContentPack.PackageId` (string) und `.Name` (string) – stabile öffentliche Identitäts- und Anzeigefelder.
- `Verse.Def.modContentPack` – stabile öffentliche Rückreferenz vom Def auf den Eigentümer-Modcontent.
- `Verse.DefDatabase<T>.AllDefsListForReading` – stabile öffentliche Read-only-Liste für jede konkrete Def-Subklasse (RimWorld Wiki Modding bestätigt für 1.5+/1.6+).
- 12 konkrete Def-Subklassen:
  - `RimWorld.ThingDef`
  - `RimWorld.RecipeDef`
  - `RimWorld.ResearchProjectDef`
  - `RimWorld.ScenarioDef`
  - `RimWorld.IncidentDef`
  - `RimWorld.PawnKindDef`
  - `RimWorld.FactionDef`
  - `RimWorld.WorldObjectDef`
  - `RimWorld.HediffDef`
  - `RimWorld.TraitDef`
  - `RimWorld.ThoughtDef`
  - `RimWorld.NeedDef`

## Gefundene Symbole/Defs

- `LoadedModManager` und `LoadedModManager.RunningMods` aus lokalem `Assembly-CSharp.dll`-`strings`-Dump bestätigt.
- `ModContentPack`, `PackageId`, `Name` sind Property-only und fehlen im `strings`-Dump; Compile-Bestätigung über Build 0W/0E gegen lokale Assembly-CSharp.dll.
- `Def.modContentPack` ist Property-only und fehlt im `strings`-Dump; Compile-Bestätigung über Build 0W/0E.
- `DefDatabase<T>.AllDefsListForReading` ist generisch-typisiert und fehlt im `strings`-Dump; Compile-Bestätigung über Build 0W/0E.
- Die 12 konkreten Def-Subklassen sind alle über `Assembly-CSharp.dll`-`strings`-Dump bestätigt; Aufzählung via `DefDatabase<T>.AllDefsListForReading.Count` und `.Where(d => d.modContentPack.PackageId == expectedOwnerId)` ist die kanonische 1.6-Modding-Konvention.

## Def-/XML-Beleg

- Pipeline-Quelle: `mods/01-Rimconemy-Foundation/Source/Catalog/FoundationDefInventory.cs` (NEU, kompiliert 0W/0E gegen lokale Assembly-CSharp.dll).
- Pipeline-Bindung: `mods/01-Rimconemy-Foundation/Source/UI/FoundationDashboard.cs` ruft `FoundationDefInventory.EnsureCaptured()` an Draw-Stelle lazy und one-shot auf.
- Keyed-Strings: fünf neue Keys `RimconemyFoundation.Inventory.{Title,TotalOwners,TotalDefs,Empty,NotLoaded}` in `Languages/English/Keyed/Foundation.xml` und parallel in `Languages/German/Keyed/Foundation.xml`.
- SPIKE-Kommentar im Source: jeder nicht im `strings`-Dump bestätigte Property-Aufruf ist im Klassen-XML-Kommentar von `FoundationDefInventory.cs` mit `SPIKE: API-FOUNDATION-INVENTORY-01 – …` markiert.

## Minimaler Test (code-only, ohne Spielstart)

1. Build 0W/0E für alle 5 Pakete gegen lokale Assembly-CSharp.dll und Harmony: bestätigt am 2026-08-02.
2. Validator 0/10 aktive reguläre Tasks: bestätigt.
3. Defs/About/Keyed XML parsen sauber (11/11 · 5/5 · 10/10): bestätigt.
4. Code-Reviewer ohne Critical/Important-Befund über `Catalog/FoundationDefInventory.cs`: bestätigt.

## Testaktion (geplant, user-only)

1. Aktuelle `Rimconemy.Foundation.dll` aus `mods/_invbuild/01-Rimconemy-Foundation/Rimconemy.Foundation.dll` über `/home/vannon/GOG Games/RimWorld/game/Mods/Rimconemy-Foundation/Assemblies/Rimconemy.Foundation.dll` ersetzen.
2. RimWorld-Hauptmenü → Mods → Apply/Übernehmen → vollständig beenden → neu starten.
3. Ein neues Spiel mit mindestens einem Rimconemy-Feature-Paket aktivieren.
4. Foundation-Tab (untere Tab-Leiste) anklicken → „Loaded Def Inventory"-Abschnitt muss erscheinen.
5. Pro Rimconemy-Paket-Zeile: Owner-Anzeige + Per-Def-Typ-Counts (z. B. `rimconemy.foundation: 1 defs → ThingDef: 1`, `rimconemy.survivalprogression: 1 defs → ScenarioDef: 1` oder leer, …).
6. Screenshot vom Tab-Abschnitt machen und `Player.log` ziehen.

## Ergebnis (lokal erwartet, nicht Runtime-belegt)

- `Player.log` enthält Foundation-Bootstrap-Zeilen wie bisher; **keine** Foundation-NRE/`TypeLoadException`/XML-Fehler durch Inventur.
- FoundationTab zeigt im UI-Bereich „Loaded Def Inventory" pro Rimconemy-Paket die addierten Counts (Owner > 0 → grün, Owner = 0 → grau).
- Bei initialem Single-Survivor-Profil (nur Foundation + Survival geladen) muss Paket 02 mindestens 1 Scenario-Def anzeigen.

## Belegpfade

- `mods/01-Rimconemy-Foundation/Source/Catalog/FoundationDefInventory.cs` (NEU, kompiliert).
- `mods/01-Rimconemy-Foundation/Source/UI/FoundationDashboard.cs` (NEUE Draw-Sektion in Q15).
- `mods/01-Rimconemy-Foundation/Languages/English/Keyed/Foundation.xml` (NEUE Keys in Q15).
- `mods/01-Rimconemy-Foundation/Languages/German/Keyed/Foundation.xml` (NEUE Keys in Q15).
- `mods/HANDOFF_QUEUE.md` §2/§3 (Q15 Eintrag), §10.8 (P28 Eintrag), §6 (Status-Erweiterung), §7 (Anweisung).
- `mods/TASK_CACHE.json` `lastCompleted=Q15`, `admissionRule.lastAdmission.admittedTaskId=null` (User-Gate offen).
- `mods/SPIKE_INDEX.md` Zeile `API-FOUNDATION-INVENTORY-01` und Code-Stand-Sektion am Ende.

## Offene Gegenbeweise

- Foundation-Inventur-Sektion noch nicht durch User-Player.log belegt.
- Screenshot der Inventur-Sektion fehlt.
- 12 konkrete Def-Subklassen wurden im Framework-Modul-Code aufgezählt, aber kein User-Paketset hat diese Counts bisher im UI gezeigt.
- Build-Nummer-Inkonsistenz: SPIKE_INDEX.md-Lokal-Baseline zeigt `rev575`, dieser Spike referenziert `rev579` (user-bestätigter Player.log). Konsistenz wird mit Q16-Reeval-Lauf formalisiert.

## Unblockt

- Code-/Defs-/Keyed-Implementierung von P28 (Def-Inventur) im Rahmen von Q15 ist `DONE`.
- Q16+ blockiert: Admission erfordert User-Runtime-Beleg für Q15 (siehe `mods/TASK_CACHE.json/#/admissionRule`).

## Online-/Doku-Recherche

- RimWorld Wiki Modding-Übersicht: https://rimworldwiki.com/wiki/Modding
- Ludeon-Foren, Modding-Brett: https://ludeon.com/forums/index.php?board=14.0
- PatchOperations: https://rimworldwiki.com/wiki/Modding_Tutorials/PatchOperations
- Harmony: https://github.com/pardeike/Harmony

Die Doku-Recherche bestätigt `DefDatabase<T>.AllDefsListForReading`, `modContentPack.PackageId` und `LoadedModManager.RunningMods` als 1.5+/1.6+ stabile Modding-API. Sie ersetzt keinen lokalen Runtime-Beleg und keine Decompile.
