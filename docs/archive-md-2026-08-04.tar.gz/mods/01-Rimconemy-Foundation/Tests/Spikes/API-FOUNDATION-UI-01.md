# API-FOUNDATION-UI-01 – Foundation dashboard registration

Status: UNVERIFIED
Owner: Foundation

## Claim under test

`Defs/MainButtonDefs/FoundationTab.xml` with stable `defName` `RimconemyFoundation` resolves `Rimconemy.Foundation.UI.FoundationDashboard : MainTabWindow` in the target RimWorld 1.6 build.

## Current implementation

- Def: `Defs/MainButtonDefs/FoundationTab.xml`
- Source: `Source/UI/FoundationDashboard.cs`
- Owner: Foundation; DLC condition: none; expected load order: Core/DLCs → Harmony → Foundation.

## Minimal test

1. Start Foundation alone (`NEW_GAME`).
2. Confirm no XML/TypeLoad errors.
3. Confirm the Foundation tab is visible and opens the dashboard (`UI_REASON`).
4. Resize/scroll through all sections and confirm dynamic content height.

## Exit criterion

User log and UI evidence confirm Def resolution and visible tab. If an additional 1.6 field is required, document the exact field from the local assembly before editing the Def.
