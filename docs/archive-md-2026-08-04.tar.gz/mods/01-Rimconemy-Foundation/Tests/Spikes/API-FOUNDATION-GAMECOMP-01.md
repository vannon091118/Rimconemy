# API-FOUNDATION-GAMECOMP-01 – FoundationSaveData registration

Status: UNVERIFIED
Owner: Foundation

## Claim under test

`FoundationSaveData : GameComponent` is instantiated and attached to each `Game` by the target RimWorld 1.6 lifecycle without a dedicated Foundation `GameComponentDef`.

## Current implementation

- Source: `Source/Save/FoundationSaveData.cs`
- Hook reason: `GameComponent.ExposeData()` is the intended save anchor.
- No `GameComponentDef` is present in `Defs/`.

## Minimal test

1. Start Foundation alone with a new game (`NEW_GAME`).
2. Open the dashboard and confirm Save Status is not `main menu`.
3. Save, fully exit, reload (`SAVE_LOAD`).
4. Confirm schema, migration detail, package versions, and event history remain visible.

## Exit criterion

User log/UI/Save evidence confirms construction, `ExposeData`, `FinalizeInit`, and reload. If target 1.6 requires explicit registration, add the smallest Def/registration path and update the Def cross-check.
