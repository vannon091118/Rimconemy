# API-FOUNDATION-DLC-01 – RunningMods DLC discovery

Status: UNVERIFIED
Owner: Foundation

## Claim under test

`LoadedModManager.RunningMods` exposes stable `ModContentPack.Name` and `PackageId` values for Royalty, Ideology, Biotech, Anomaly, and Odyssey in the target RimWorld 1.6 build.

## Current implementation

- Source: `Source/Profile/ProfileDetector.cs`
- Detection is late-bound and checks display name plus two package-ID forms.
- No DLC gameplay assembly is referenced at compile time.

## Minimal test

1. Run Foundation with all five DLCs (`DLC_SCOPE`).
2. Repeat with one DLC disabled.
3. Compare the per-DLC match log and Dashboard status.
4. Confirm the profile never becomes Full when a DLC is absent.

## Exit criterion

User log records which matching form succeeded for each DLC without exceptions. Any mismatch becomes a targeted adapter change; no guessed package ID is promoted to confirmed status.
