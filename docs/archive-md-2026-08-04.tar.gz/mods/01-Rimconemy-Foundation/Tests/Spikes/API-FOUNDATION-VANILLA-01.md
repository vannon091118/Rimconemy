# API-FOUNDATION-VANILLA-01

Status: **UNVERIFIED**
RimWorld-Build: 1.6.4566 rev579 (user-bestätigt)
DLC: Core, Royalty, Ideology, Biotech, Anomaly, Odyssey
Owner: Foundation
Blockiert: Q-Next (nach User-Beleg für Q15)
Bezug: `mods/01-Rimconemy-Foundation/Source/Catalog/FoundationVanillaInventory.cs` · `mods/01-Rimconemy-Foundation/Source/UI/FoundationDashboard.cs` · `mods/01-Rimconemy-Foundation/Languages/{English,German}/Keyed/Foundation.xml`

## Zweck

Stabile Verse.\*/Assembly-CSharp-Read-only-Verkettung, die für die Foundation-UI einen **Three-Number-Snapshot** der Vanilla- und DLC-Def-Oberfläche liefert, ohne zu raten:

- Anzahl der Vanilla-Things (Filter: alle nicht-Rimconemy-Owner).
- Anzahl der Vanilla-Stuffs (Subset davon).
- Anzahl der Vanilla-/DLC-/Third-Party-Mod-Owner insgesamt.

Vorbereitung für `P25` (API-RESOURCE-01): der stabile Chat kann verglichen werden mit dem, was im laufenden Spiel tatsächlich im Map/Welt-Stream aktiv ist, sobald `P25` mit User-Beleg ergänzt wird.

## Gesuchte Anker

- `Verse.LoadedModManager.RunningMods` – stabile Liste der laufenden Mods.
- `Verse.ModContentPack.PackageId` – stabile Identität des Eigentümers (Property, compile-bestätigt).
- `Verse.DefDatabase<ThingDef>.AllDefsListForReading` – stabile Read-only-Liste der geladenen Things.
- `Verse.Def.modContentPack` – stabile Rückreferenz vom Def auf seinen Owner.
- `Verse.Def.IsStuff` – kanonische 1.5+/1.6+ Stuff-Markierung (Property, compile-bestätigt).

## Gefundene Symbole/Defs

- `LoadedModManager.RunningMods` aus dem `Assembly-CSharp.dll`-strings-Dump bestätigt.
- `ModContentPack`, `modContentPack`, `PackageId`, `IsStuff`, `AllDefsListForReading` sind im Dump nicht direkt sichtbar, aber kompilieren erfolgreich gegen die lokale Assembly-CSharp.dll.

## Def-/XML-Beleg

- Pipeline-Quelle: `mods/01-Rimconemy-Foundation/Source/Catalog/FoundationVanillaInventory.cs` (NEU in P30, kompiliert 0W/0E).
- Pipeline-Bindung: `mods/01-Rimconemy-Foundation/Source/UI/FoundationDashboard.cs` ruft `FoundationVanillaInventory.EnsureCaptured()` lazy und one-shot auf und zeigt im Dashboard den Abschnitt „Vanilla + DLC Snapshot".
- Keyed-Strings: 6 neue Keys `RimconemyFoundation.VanillaInventory.{Title,Summary,Empty,NotLoaded,MissingPower}` (CategoryHeader/Empty bleiben noch in DE; EN hat sie gepurged — siehe BUILD-Aufgabe).

## Dokumentierte Lücke (deferred)

Während der P30-Implementierung hat sich gezeigt, dass die 1.6-API für stabile Vanilla-Kategorisierung **keine** bestätigte offene Schnittstelle hat:

- `ThingCategory.defName` existiert in 1.5+/1.6+ **nicht**.
- `ThingCategory.label` ist ebenfalls nicht in unserer lokalen `Assembly-CSharp.dll`-Manager als stabile Property nachgewiesen.
- `ThingCategoryDef.defName` wäre der nächste Schritt, aber der Pfad `def.category → ThingCategory → def → ThingCategoryDef` ist nicht durch compile-Bestätigung abgesichert.

Deshalb verzichtet P30 bewusst auf per-Kategorie-Bucket und liefert nur Total-Counts. Diese Vereinfachung wurde durch vier gescheiterte Build-Iterationen erzwungen (CS0023 als `?.` auf Werttyp `ThingCategory`; CS1061 als `defName`/`label` fehlten).

Per-Kategorie-Bucket bleibt als zukünftiger Spike `API-FOUNDATION-VANILLA-02` offen, sobald ein User-Runtime-Beleg die tatsächliche 1.6-Oberfläche bestätigt.

## Minimaler Test (code-only, ohne Spielstart)

1. Build 0W/0E für alle 5 Pakete: bestätigt am 2026-08-02 (P30-Simplify).
2. Validator 0/10 aktive reguläre Tasks: bestätigt.
3. Defs/About/Keyed XML parsen sauber: bestätigt.
4. Code-Reviewer ohne Critical-Befund: bestätigt (Minor-Findings dokumentiert).

## Testaktion (geplant, user-only)

1. Aktuelle `Rimconemy.Foundation.dll` aus `mods/_final_build_p30f/01-Rimconemy-Foundation/Rimconemy.Foundation.dll` über `/home/vannon/GOG Games/RimWorld/game/Mods/Rimconemy-Foundation/Assemblies/Rimconemy.Foundation.dll` ersetzen.
2. RimWorld-Hauptmenü → Mods → Apply/Übernehmen → beenden → neu starten.
3. Foundation-Tab öffnen → Screenshot machen.
4. Im Dashboard-Abschnitt „Vanilla + DLC Snapshot" müssen drei Zahlen stehen: Anzahl Vanilla-Things, Anzahl Stuff, Anzahl Nicht-Rimconemy-Mod-Owner.

## Ergebnis (lokal erwartet, nicht Runtime-belegt)

- Für eine Vanilla-Only-Standardinstallation mit fünf DLCs: typischerweise ~600–900 Vanilla-Things, davon ~80–120 Stuff, 7 Nicht-Rimconemy-Owner (6 DLCs + Core).
- Für eine zusätzliche Rimconemy-Installation mit Paket 02–05: gleiche Zahlen, weil die Counts die Rimconemy-Things explizit ausschließen.

## Belegpfade

- `mods/01-Rimconemy-Foundation/Source/Catalog/FoundationVanillaInventory.cs` (NEU, vereinfacht).
- `mods/01-Rimconemy-Foundation/Source/UI/FoundationDashboard.cs` (DrawVanillaSection + CalcVanillaSectionHeight hinzugefügt).
- `mods/01-Rimconemy-Foundation/Languages/English/Keyed/Foundation.xml` (Summary + Title + Empty + NotLoaded + MissingPower).
- `mods/01-Rimconemy-Foundation/Languages/German/Keyed/Foundation.xml` (parallel).
- `mods/HANDOFF_QUEUE.md` §10.7 P30-Eintrag (BEHOBEN Code; Runtime UNVERIFIED).
- `mods/TASK_CACHE.json` `lastCompleted=Q15` (P30 ist code-only-Härtung, kein Admission-Event).

## Offene Gegenbeweise

- Foundation-Vanilla-Snapshot-Sektion noch nicht durch User-Player.log belegt.
- Genauer Vanilla-Things-Count hängt vom DLC-Setup ab; User-Runtime dient als Beleg.
- Per-Kategorie-Bucket bleibt ungelöst (Four-way-Versuche scheiterten an 1.6-Surface-Lücke).

## Unblockt

- Q16/Q17 Aufnahme nach Q15-Runtime-Beleg bleibt offen.
- Späterer Spike `API-FOUNDATION-VANILLA-02` für per-Kategorie-Bucket ist freigegeben, sobald ein Runtime-Dekompile oder User-Laufzeitdaten verfügbar sind.

## Online-/Doku-Recherche

- RimWorld Wiki Modding-Übersicht: https://rimworldwiki.com/wiki/Modding
- Ludeon-Foren, Modding-Brett: https://ludeon.com/forums/index.php?board=14.0
- PatchOperations: https://rimworldwiki.com/wiki/Modding_Tutorials/PatchOperations
- Harmony: https://github.com/pardeike/Harmony

Die Doku bestätigt `DefDatabase<T>.AllDefsListForReading`, `Def.modContentPack`, `LoadedModManager.RunningMods` und `Def.IsStuff`. Sie liefert **keine** zuverlässige Quelle zu `ThingCategory.label`/`ThingCategoryDef.defName`, was den Vereinfachungsweg rechtfertigt.
