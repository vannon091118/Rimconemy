# F3 – Snapshot-/Unavailable-Read-Model

Status: IMPLEMENTED_UNVERIFIED
Owner: Foundation

## Startzustand

- Foundation allein, ohne optionale Feature-Pakete.
- Erwartete Paket-IDs aus `BLUEPRINT.md` sind bekannt, aber nicht registriert.

## Aktion

1. Foundation-Dashboard öffnen.
2. Paketliste, DLC-Liste, ServiceBus und Eventlog prüfen.
3. Fehlende Pakete/Domänen gegen erfundene Nullwerte abgrenzen (`UI_REASON`).
4. Identischen Start erneut ausführen und Log-/UI-Ausgabe vergleichen (`DETERMINISM`).

## Erwarteter Beleg

- Nicht installierte Domänen erscheinen als `Not installed`/`Unavailable` mit Ursache.
- Foundation erzeugt keine Wallet-, Outpost-, Infizierten- oder sonstigen Feature-Daten.
- Deduplizierte Diagnose-/Eventlog-Einträge bleiben bei unverändertem Zustand stabil.

## Scope-Grenze

Die aktuelle Foundation-Implementierung besitzt neutrale `PackageSnapshot`-Read-Models, aber noch keine bestätigte Vanilla-Ressourcen-/Power-Abfrage. Ein solcher API-Anker bleibt offen und darf nicht geraten werden; siehe `SPIKE_INDEX.md` und Handoff.
