# F2 – Profile- und DLC-Erkennung

Status: IMPLEMENTED_UNVERIFIED
Owner: Foundation

## Startzustände

| Fall | Registrierte Feature-Pakete | DLCs | Erwartetes Profil |
|---|---:|---:|---|
| Standalone | 0 | beliebig | `Standalone` |
| Partial-Package | 1–3 | vollständig/teilweise | `Partial` |
| Partial-DLC | 4 | mindestens 1 fehlt | `Partial` |
| Full | 4 | alle fünf | `FullOverhaul` |

## Aktion

1. Je Fall mit definierter Load Order starten.
2. Registry-/Profil-Log lesen.
3. Dashboard öffnen und Paket-/DLC-Gründe prüfen (`UI_REASON`, `DLC_SCOPE`).
4. Ein fehlendes Paket oder DLC bewusst nicht aktivieren und den Fall wiederholen.

## Erwarteter UI-/Log-Beleg

- Jede fehlende Paket-ID und jeder fehlende DLC-Name ist konkret aufgelistet.
- `FullOverhaul` erscheint nur bei allen vier Feature-Paketen und allen fünf DLCs.
- Foundation selbst bleibt sichtbar und funktionsfähig, wenn optionale Pakete fehlen.

## Aktueller Nachweis

- Codepfade vorhanden: `Source/Registry/PackageRegistry.cs`, `Source/Profile/ProfileDetector.cs`.
- Laufzeitmatrix und tatsächliche UI-Belege: `UNVERIFIED`.
- RunningMods-Metadaten-Spike: `Tests/Spikes/API-FOUNDATION-DLC-01.md`.
