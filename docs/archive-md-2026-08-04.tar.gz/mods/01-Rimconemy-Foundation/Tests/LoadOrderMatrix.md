# F5 – Foundation Load-Order- und Lifecycle-Matrix

Status: IMPLEMENTED_UNVERIFIED
Owner: Foundation

## Matrix

| Fall | Load Order | Testbelege |
|---|---|---|
| L1 minimal | Core/DLCs → Harmony → Foundation | `NEW_GAME`, `DLC_SCOPE`, `UI_REASON` |
| L2 partial | Core/DLCs → Harmony → Foundation → ein Featurepaket | `UI_REASON`, `SAVE_LOAD` |
| L3 full | Core/DLCs → Harmony → Foundation → 02 → 03 → 04 → 05 | `SAVE_LOAD`, `MAP_CHANGE`, `DLC_SCOPE`, `DETERMINISM` |
| L4 ohne optionale DLCs | Core → Harmony → Foundation | `NEW_GAME`, `DLC_SCOPE`, `UI_REASON` |
| L5 wiederholtes Laden | gleicher Save zweimal laden | `SAVE_LOAD`, `DETERMINISM` |

## Aktion

1. Jeden Fall mit dokumentierter Paket-/DLC-Liste starten.
2. Foundation-Bootstrap, Def-Load, Dashboard und ServiceBus prüfen.
3. Save schreiben, vollständig beenden, laden und die aktive Map verlassen/zurückkehren (`MAP_CHANGE`).
4. Gleiche Eingaben/Seed erneut ausführen und Event-/Profilstatus vergleichen (`DETERMINISM`).

## Erwarteter Beleg

- Keine direkten Assembly-Referenzen auf optionale Pakete.
- Foundation bleibt im Standalone-/Partial-Profil diagnostisch sichtbar.
- Kartenwechsel und wiederholtes Laden erzeugen keine doppelte Registrierung oder Event-Aufblähung.
- Fremdmodfälle L4–L7 der globalen Matrix bleiben offen, solange sie nicht ausgeführt wurden.

## Aktueller Nachweis

- Build-/Codebeleg vorhanden.
- Alle Laufzeitfälle: `UNVERIFIED`; kein RimWorld-Start durch den Agenten.
