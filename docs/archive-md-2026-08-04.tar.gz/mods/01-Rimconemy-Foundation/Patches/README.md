# Foundation patches

Status: NOT_REQUIRED_FOR_MVP
Owner: Foundation

Foundation uses the vanilla `[StaticConstructorOnStartup]`, `GameComponent`, `MainButtonDef` and `MainTabWindow` anchors. No Harmony patch or PatchOperation is required for the current dashboard, registry, service bus, event log, or save contract.

- DLC condition: none; Foundation is Core-compatible and does not require a DLC.
- Load-order assumption: Core/DLCs → Harmony → Foundation; feature packages may load after Foundation and register late-bound descriptors.
- Def anchor: `Defs/MainButtonDefs/FoundationTab.xml`, stable `defName` `RimconemyFoundation`.
- Exit criterion for adding a patch: a documented 1.6 API spike proves that the native anchor cannot provide the required behavior. Until then, no patch is silently assumed.
