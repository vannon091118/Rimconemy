# Rimconemy Economy & Territory

> Blueprint: [`BLUEPRINT.md`](BLUEPRINT.md) · zentrale Vision: [`../PRODUCT_VISION.md`](../PRODUCT_VISION.md) · Research: [`../VANILLA_DLC_RESEARCH_BASELINE.md`](../VANILLA_DLC_RESEARCH_BASELINE.md)

## Kurzbeschreibung

Rimconemy Economy & Territory erweitert RimWorld von der lokalen Kolonie zu einer verbundenen Weltkarten-Wirtschaft. Credits sind Wallet-Daten, Waren bleiben physische Gegenstände, und Outposts benötigen echte Investitionen, Verteidigung und territoriale Verbindung.

## Was das gesamte Paket bietet

- Credits als reine Wallet-Währung, nicht als Item
- Spieler-, Fraktions- und Outpost-Wallets
- lokale Märkte
- Angebot, Nachfrage, Preis und Preisverlauf
- Transaktionsbuch
- Survivor-Fraktionen und wirtschaftliches Interesse
- Outpost-Gründung durch konkrete Investition
- stetige Credits- und Bauressourcen-Erzeugung
- automatische Verteidigungs- und Wartungskosten
- Produktions-/Verteidigungsverteilung
- Proxies und zusammenhängendes Territorium
- World-Map-Symbole, Einheitennummern und sichtbare Pfade
- Verbindungsverlust mit sichtbarem Drei-Tage-Countdown
- Outpost-Verlust zur Ruine nach Ablauf der Frist
- spätere Rückeroberung/Wiederaufbau
- automatisierte Weltkarten-Raids als Verwaltungsentscheidung

## Was es alleine bietet

Allein mit Vanilla-Ressourcen und Vanilla-Fraktionen entsteht ein eigenständiger Wirtschafts- und Gebietskontroll-Loop:

```text
Ware handeln
→ Wallet aufbauen
→ Standort auswählen
→ Outpost investieren
→ Proxy-Verbindung sichern
→ Produktion gegen Verteidigung abwägen
→ Weltkarte verwalten
```

Ohne Infizierte können Vanilla-Fraktionen und vorhandene Weltkarten-Gefahren als Gegner dienen. Ohne Scavenger werden Vanilla-Güter produziert.

## Verhalten ohne andere Rimconemy-Pakete

- verwendet Vanilla-Güter statt Bauschutt, wenn Scavenger fehlt
- verwendet Vanilla-Fraktionen und Vanilla-Raids als Standalone-Kontext
- Outposts erzeugen keine nicht vorhandenen Mechadroids
- Credits bleiben getrennt von Silber und Inventargegenständen
- fehlender Infizierten-Druck wird nicht vorgetäuscht
- fehlendes Foundation-UI wird durch eine eigene minimale Verwaltungsansicht ersetzt

## Integration im Full Overhaul

- Bauschutt, Nahrung, Erze und Brennstoffe werden regionale Waren.
- Survivor & Progression kann Wirtschaftsforschung und Arbeitserfahrung liefern.
- Scavenger liefert die physischen Bau- und Upgrade-Ressourcen.
- Infected & Automation liefert Bedrohung, Mechadroids und Outpost-Raids.
- Die Hauptbasis bleibt der Game-Over-Anker; Outpost-Bevölkerung rettet nicht automatisch.
- Ein abgeschnittener Outpost hat drei Tage zur Wiederherstellung; danach wird er zur Ruine.

## Abhängigkeiten

- RimWorld 1.6
- Harmony als externe Laufzeitabhängigkeit
- Foundation optional im Standalone-Modus
- **Foundation-Servicebus** erforderlich für die geschlossene Full-Profile-Integration
- gemeinsamer Interface-Vertrag: [`../INTERFACE_CONTRACT.md`](../INTERFACE_CONTRACT.md)
- Survival, Scavenger und Infected optional im Standalone-Modus

## Save-Risiko

Hoch. Wallets, lokale Märkte, Preisverläufe, Outposts, Proxies, Pfade, Countdown-Zustände und Ruinen benötigen stabile IDs, Save-Versionen und Migration. Das Entfernen aus einem aktiven Wirtschaftssave muss blockiert oder ausdrücklich migriert werden.

## Definition of Done für dieses Paket

- Credits sind niemals als physisches Item im Inventar
- mindestens ein lokaler Markt berechnet nachvollziehbare Preisänderungen
- jede Transaktion besitzt einen Eintrag
- Outpost produziert Brutto- und Nettoertrag getrennt
- Verteidigungsanteil reduziert Nettoertrag sichtbar
- Proxy-Verlust startet einen sichtbaren Drei-Tage-Countdown
- Ablauf erzeugt eine Ruine statt eines stillen Datenverlusts
- World-Map-Raid zeigt Symbol, Anzahl, Ziel, Pfad und ETA
