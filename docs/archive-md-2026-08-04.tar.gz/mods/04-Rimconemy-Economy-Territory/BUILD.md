# Build-Vertrag – Rimconemy Economy & Territory

## Ausgabe

```text
Assemblies/Rimconemy.EconomyTerritory.dll
```

## Source-Verantwortung

`Source/` enthält Wallets, Märkte, Angebot/Nachfrage, Transaktionen, Fraktionen, Outposts, Proxies, Verbindungsgraph, World-Map-Overlay und Raid-Verwaltung.

## Standalone-Build

Der Build darf ohne Survival, Scavenger und Infected kompiliert werden. Standalone verwendet Vanilla-Güter, Vanilla-Fraktionen und dokumentierte Vanilla-Bedrohungen. Im Full Profile werden Integrationen über den Foundation-Servicebus und versionierte Capabilities geladen; ohne Foundation bleibt der Standalone-Modus.

## Validierung

- Credits sind nur Wallet-Daten.
- Marktpreise reagieren reproduzierbar auf Angebot und Nachfrage.
- Outpost-Brutto-, Verteidigungs- und Nettoertrag sind getrennt.
- Proxy-Ausfall startet den Drei-Tage-Countdown.
- Ablauf erzeugt eine Ruine.
- World-Map-Ziel, Einheitenzahl, Pfad und ETA sind sichtbar.
