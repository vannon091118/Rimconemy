# API-TRADE-01 – Wallet, MarketValue und Trade-Semantik

Status: UNVERIFIED
Owner: Economy & Territory

## Zweck

Bevor Credits-Wallets und Rimconemy-Marktpreise in den Code fließen, muss geklärt sein, wie RimWorlds `MarketValue` und Trader-/TradeSession-Pfade verhalten. Der Spike grenzt Wallet als nicht-Item gegen `TradeSession`/`Trader`-Flows ab.

## Gesuchte Anker

- `MarketValue` (Vanilla-Schema)
- `TradeSession`, `TradeDeal`, `Trader`
- Pawn-`Wallet`-Datenraum (kein ThingDef)

## Besitzentscheidung

- Economy & Territory besitzt `CreditsLedger`, `MarketStub`, `OutpostStubRecord`, `TerritoryNode` als Datenrecords.
- Vanilla besitzt Markt-Mechanik, Trader-Definitonen, WealthWatcher.
- Credits sind niemals ein `ThingDef`; sie sind reine Wallet-Daten.
- Outpost-IDs bleiben stabil über Save/Load, Kartenwechsel und GC.

## Minimaler Spike-Test

1. Wallet передачи und LockedBalance über Save/Load testen.
2. Markt-Bestand/Preis deterministisch aus Wallets und Nachfrage berechnen.
3. Reserve/Execute/Cancel einer Transaktion mit doppel-(PackageId, RequestId) → identisches Resultat.
4. Outpost-Brutto/Netto unter Last P1/P2/P3.
5. UI zeigt Wallet, Bilanz, Transfergrund, Blockadeursache.

## Belegschema

- Symbol gesucht: MarketValue, TradeSession, TradeDeal
- Symbol gefunden: UNVERIFIED
- Def-/XML-Beleg: `game/Data/Core/Defs/ThingDefs/Item/Trade/`, `DefOf-Lookup` per Reflection (zu Q14)
- Testaktion: oben beschrieben
- Ergebnis: UNVERIFIED
- Belegpfade: `mods/FALSIFICATION_REPORTS/rimconemy.economyterritory__WalletCredits.md`, `...__Market.md`, `...__ReservePhysicalTransfer.md`, `...__OutpostProduction.md`, `...__TerritoryCountdown.md`

## Exit

`READY` erst nach lokalem 1.6-Ankerbeleg für `TradeSession` und dem Nachweis, dass Wallet/Market den Vanilla WealthWatcher nicht verdeckt oder late-bound überschreiben würden.
