# API-WORLD-01 – WorldObject/Lifecycle/Save

Status: UNVERIFIED
Owner: Economy & Territory

## Zweck

Outposts, Proxies und Territory-Graphen benötigen savebare World-Objekte. Vor Mapping wird geprüft, ob Vanilla 1.6 `WorldObject` direkt ableitbar ist und ob Save/Load ohne Ghost-Duplikation gelingt.

## Gesuchte Anker

- `WorldObject` (Basisklasse)
- `WorldObjectDef`, `WorldComponent`
- Cleanup/GC-Semantik
- Caravan Camp / Odyssey-Transporter Lifecycle

## Besitzentscheidung

- Economy & Territory besitzt `OutpostStubRecord` und `TerritoryNode` im Domain-Namespace; `Rimconemy_OutpostWorldObject` ist ein savebarer Eintrag in `Defs/Outposts/Outposts.xml`.
- Vanilla-World-Objekte bleiben unberührt.
- Site/Caravan-Camp werden nicht heimlich als Outpost-Stub missbraucht.

## Minimaler Spike-Test

1. Outpost in Karte setzen, Karte verlassen, auf World-Map zurückkehren.
2. Save/Load über `WorldObject`, dann Karte laden.
3. Proxy-Verbindung trennen, Countdown starten.
4. Nach 3 in-game Tagen (30 000 Ticks) Ruine erzeugen.
5. Kartenwechsel darf das Ergebnis nicht verändern.

## Belegschema

- Symbol gesucht: WorldObject, WorldObjectDef, WorldComponent
- Symbol gefunden: UNVERIFIED
- Def-/XML-Beleg: `mods/04-Rimconemy-Economy-Territory/Defs/Outposts/Outposts.xml`
- Testaktion: oben beschrieben
- Ergebnis: UNVERIFIED
- Belegpfad: `mods/FALSIFICATION_REPORTS/rimconemy.economyterritory__TerritoryCountdown.md`, `...__OutpostProduction.md`

## Exit

`READY` erst nach lokalem Save-/Load- und Mapwechsel-Beleg ohne Ghost-Outpost oder Doppel-Profit im selben Save.
