# Rimconemy — Root Roadmap

> **Stand:** 2026-08-04 (Update nach Live-Test + Idempotenz-/Save-Roundtrip-Falsifizierung)  
> **Zielplattform:** RimWorld 1.6.4566; Royalty, Ideology, Biotech, Anomaly, Odyssey  
> **Status:** Phase 1 Coding-Cut abgeschlossen (§1–§7). Erstmaliger Live-Test (Spielstart) erfolgreich: alle 5 Mods laden, Foundation erkennt FullOverhaul, alle Bootstraps laufen, StoryDirector initialisiert. 3 Runtime-Bugs nach Live-Test behoben (XML-Format, Version-Mismatch, Idempotenz). Build alle Pakete 0W/0E. Runtime-Beleg (Save/Load, Event-Feuerung) noch ausstehend.

## 1. Verbindliche Priorität

Die neue Produktpriorität überschreibt die bisherige Paket-Reihenfolge für die nächste Entwicklungsphase:

```text
Story Writer + Difficulty + Eventkatalog
        ↓
Setting-Ideologie als Verhaltensadapter
        ↓
Storage-only-Ressourcen-Snapshot
        ↓
Character Setup: Bio → Skillbudget → Traits
        ↓
Vanilla-/DLC-Adapter und echte Gameplay-Events
        ↓
Wirtschaft, Outposts, Infizierte, Mechadroids und Endgame
```

Die Paketnummern bleiben Eigentumsgrenzen. Sie sind aber nicht automatisch die Implementierungsreihenfolge. Story- und Ideology-Verträge müssen zuerst geklärt werden, weil sie spätere Charakter-, Ressourcen- und Evententscheidungen bestimmen.

## 2. Produktentscheidung für Phase 1

### 2.1 Story-Modell

Der Story Writer bewertet eine dynamische Lage und wählt daraus ein passendes Ereignis. Er ist zunächst ein **Setting-Director mit Vanilla-Adaptern**, nicht automatisch ein direkt implementierter Vanilla-`StorytellerDef`.

Ein direkter Storyteller wird erst nach einem lokalen API-/Def-/Runtime-Spike freigegeben. Assembly-String-Treffer gelten nicht als Signatur- oder Runtime-Beweis.

### 2.2 Difficulty-Profile

Schwierigkeit wird als benanntes Setting-Profil statt als unverständliche globale Zahl geführt. Die folgenden Namen und Regeln sind der Phase-1-Startpunkt; Zahlen werden erst nach dem Balance-Gate verhärtet:

| Profil-ID | Spielerlesbare Bedeutung | Eventdruck | Ressourcenregel | Ideologie-Regel | Ruhefenster |
|---|---|---|---|---|---|
| `Rimconemy_Refuge` | Aufbau einer kleinen Zuflucht | niedrige Eskalation; frühe Krisen bleiben begrenzt | Grundversorgung bleibt verfügbar, Engpässe werden angekündigt | Konflikte überwiegend als Dialog-/Thought-Folgen | lang |
| `Rimconemy_Survival` | hartes tägliches Überleben | mittlere Eskalation; Versorgung und Bedrohung konkurrieren | Lagerbestand ist entscheidend; Krisen können Folgeevents erzeugen | Konformität und Ressourcenentscheidungen erzeugen sichtbare soziale Folgen | mittel |
| `Rimconemy_Collapse` | Zusammenbruch unter permanentem Druck | hohe Eskalation; Wendepunkte früher möglich | keine kostenlose Erholung; knappe Lager verschärfen Eventgewicht | Konflikte können Rollen, Mood und Folgeevents stärker verändern | kurz |

Jedes Profil definiert zusätzlich:

- Eventfamilien und erlaubte Eskalationsstufen,
- Ruhe- und Schutzfenster,
- Bedrohungsdruck und Intensitätsgrenzen,
- Ressourcenknappheit als erklärbare Regel,
- Ideologie-Spannung und Konfliktfolgen,
- zulässige Wendepunkte,
- deterministische Version und Seed-Regeln.

Jede sichtbare Änderung muss im UI als Regel erklärt werden. Es gibt keine stillen globalen Multiplikatoren. Die konkrete Gewichtungs-/Cooldown-Tabelle wird im Phase-1-Story-Gate festgeschrieben.

### 2.3 Eventkatalog

Die Phase-1-MVP-Liste ist verbindlich als Content-Startpunkt:

| Event-ID | Familie | Mindestlage | Ausschluss/Cooldown | Primäre Folge |
|---|---|---|---|---|
| `Rimconemy_SupplyShortage` | Versorgungskrise | ein Storage-Snapshot unterschreitet das Profilminimum | nicht während aktiver Versorgungserholung; einmal pro Krisenfenster | Lagerentscheidung, Kosten oder Hilfsangebot |
| `Rimconemy_IdeologyConflict` | ideologischer Konflikt | Setting-Regel verletzt oder Ideologie-Spannung über Profilgrenze | kein zweites Konfliktereignis vor Auflösung des ersten | Thought-/Rollen-/Gruppenentscheidung |
| `Rimconemy_ExternalThreat` | äußere Bedrohung | Threat-Snapshot überschreitet die Profilschwelle | keine Doppelung mit aktivem Raid-/Threat-Event | Warnung, Vorbereitung oder Incident-Adapter |

Jedes Event erhält vor Implementierung konkrete Gewichtungs-, Cooldown- und Folgewerte pro Profil. Ein Event-Spec besitzt mindestens:

```text
EventId
EventVersion
EventFamily
Prerequisites
Exclusions
Weight
Cooldown
EscalationBand
TextKey
Choice/FollowUpIds
Effects
DeterminismKey
```

Eventauswahl folgt dieser Reihenfolge:

1. harte Profil-/DLC-/Lage-Ausschlüsse,
2. Save-/Cooldown-/Idempotency-Prüfung,
3. gültige Eventkandidaten,
4. deterministische Gewichtung,
5. Auswahlgrund und erwartete Konsequenz speichern,
6. genau einmal ausführen,
7. Folgeevents nur über gespeicherte IDs planen.

Erste Eventfamilien:

- Versorgungskrise,
- ideologischer Konflikt,
- äußere Bedrohung,
- Entdeckung,
- technische Chance,
- moralische Entscheidung,
- Ruhe-/Erholungsereignis,
- Wendepunkt.

### 2.4 Setting-Ideologie

Das Setting besitzt die Regeln. RimWorld Ideology dient als technischer Träger über einen Adapter:

| Setting-Konzept | Technischer Träger | Belegpflicht |
|---|---|---|
| gemeinsame Regel | `PreceptDef`/Precept | lokale Def-/API-Prüfung plus Pawn-/UI-Fall |
| soziale Verantwortung | `RoleDef`/Role | Rollenvergabe und Verhalten testen |
| Gruppenerfahrung | `RitualDef`/Ritual | Ritual lädt, wirkt und speichert |
| unmittelbare Reaktion | `ThoughtDef`/ThoughtWorker | Mood-/Social-Effekt reproduzieren |
| Verhaltenspriorität | native Ideology-/AI-Adapter oder expliziter Director-Command | keine Behauptung aus Precept allein |

„Ideologie“ bedeutet in diesem Projekt kein zusätzliches Religionssystem. Das vorhandene Ideology-Fenster wird als **Setting-/Erfahrungsfenster** genutzt: Regeln, Rollen, Gemeinschaftsreaktionen und Konsequenzen werden dort verständlich angezeigt.

Vanilla-Ideologie wird im Zielprofil nicht als primäre Spielerlogik vorausgesetzt. Ob technische Vanilla-Elemente geerbt, ersetzt oder nur adaptiert werden, wird pro Precept-/Role-/Ritual-Familie dokumentiert. Keine globale, stille Löschung fremder Ideology-Inhalte.

## 3. Phasen

### Phase 0 — Root-Verträge und Beweisgrenze

**Ziel:** Die Dokumentation wird wieder auffindbar und widerspruchsfrei.

**Aufgaben:**

- ✅ Root-`AUDIT.md`, `ROADMAP.md` und `docs/tasks.md` (vormals `HANDOFF.md`) als kanonische Übergabe verwenden.
- ✅ fehlende Referenzdokumente entweder anlegen oder alle Links ausdrücklich als offen markieren.
- ✅ Paket-README/ROADMAP-Overclaims als `planned`/`scaffold` kennzeichnen (AUDIT §E2/E3).
- ✅ Definition von `SettingProfile`, `SituationSnapshot`, `StoryEventSpec`, `IdeologySnapshot` und `StorageSnapshot` festschreiben (H1–H5 Docs).

**Gate:** ✅ Erfüllt. Kein Root-Dokument stellt nicht Implementiertes als geliefert dar.

### Phase 1 — Story Writer, Difficulty und Eventkatalog

**Besitzer:** zunächst Paket 05 als Bedrohungs-/Eventdomäne; gemeinsame Read-Models über Foundation-Verträge, ohne direkte Pflicht-Compile-Abhängigkeit.

**Artefakte (Stand 2026-08-04):**

- ✅ `SettingProfile` mit Difficulty-Regeln (`mods/05/.../Source/Story/SettingProfile.cs`)
- ✅ `SituationSnapshot` mit Storage-/Survivor-/Threat-/Ideology-Aggregaten (`SituationSnapshot.cs`)
- ✅ `StoryEventSpec` und Eventfamilien (`StoryEventSpec.cs`, `StoryEventCatalog.cs`)
- ✅ pure deterministische Auswahlfunktion (`StorySelector.cs`)
- ✅ Cooldown-/Idempotency-State (`StoryState.cs` mit `IExposable` + `ExposeData()`)
- ✅ Storage-Adapter (`mods/03/.../Source/Storage/StorageQuery.cs`)
- ✅ Ideology-Adapter, 1 Regel (`mods/02/.../Source/Ideology/ThoughtWorker_ResourceFairness.cs`)
- ✅ Unit-Tests, 12 Tests (`mods/05/.../Tests/StorySelectorTests.cs`)
- ✅ Incident-Ausführung (`StoryDirector.cs` + `InfectedRaidWorker.cs` Rewrite)
- ⬜ UI-Read-Model mit Auswahlgrund (nicht in Phase 1)
- ✅ drei testbare Event-Specs (`Defs/StoryEvents/` XMLs + `StoryEventCatalog.cs`)

**MVP-Events:**

1. Versorgungskrise,
2. ideologischer Konflikt,
3. äußere Bedrohung.

**Nicht in Phase 1:** vollständiger Raid-Spawn, Mechadroids, Hauptstädte, Endgame, automatische globale Storyteller-Übernahme.

**Gate:** ✅ Code-seitig erfüllt. Gleicher Snapshot + Profil + Seed → gleicher `DeterminismKey`. `StorySelectorTests` verifiziert Determinismus (×3 Profile) und Idempotenz (×2). 

**Runtime-Beleg (2026-08-04):** ⬜ Spielstart ✅ — alle 5 Mods laden, FullOverhaul erkannt, Bootstrap-Kette komplett. ⬜ Save/Load + Event-Feuerung noch ausstehend.

**Bugfixes nach Live-Test (2026-08-04):**
- XML-Format-Fehler (18×): `StoryEventDef.weights`/`cooldownDays` von `Dictionary` auf `List<string>` (`Key=Value`) umgestellt
- Version-Mismatch: `PackageRegistry.cs` hartcodierte Versionen auf `VERSION`-Stand gebracht
- Idempotenz-Test (2 fails): Cooldown-Filter aus Kandidatenauswahl entfernt, stattdessen nach Idempotenz-Prüfung angewendet
- `StoryState.GetCooldownUntil()` ergänzt

### Phase 2 — Setting-Ideologie

**Besitzer:** Survival & Progression für Pawn-/Mood-/Setting-Reaktionen; Ideology-Adapter als klar getrennte Schnittstelle.

**Aufgaben:**

- Setting-Regeln als versionierte IDs definieren.
- Precepts, Roles, Rituals und Thoughts nur über belegte native Träger anbinden.
- Einflussmatrix anlegen: Regel → Träger → Pawn-Zielgruppe → Thought/Mood-/Social-/AI-Wirkung → UI-Erklärung.
- festlegen, welche Vanilla-Precepts geerbt, ersetzt, neutralisiert oder nur beobachtet werden.
- Ideologie-/Erfahrungsfenster anzeigen.
- Konflikt-, Konformitäts- und Rollenreaktionen speichern.

**Gate:** Mindestens drei Setting-Regeln erzeugen reproduzierbar dokumentierte Charakterreaktionen; kein globales Verhalten wird nur aus einem Namen oder Assembly-String abgeleitet.

### Phase 3 — Storage-only-Ressourcenmodell

**Besitzer:** Scavenger Infrastructure für physische Bestände; Foundation für Read-only-Snapshots.

**Regel:** Survivor-Ressourcen werden ausschließlich aus tatsächlichen RimWorld-Storage-/Map-Beständen gelesen. Kein zweites abstraktes Survivor-Inventar und kein paralleles Ledger für dieselben physischen Items.

**Snapshot enthält:**

- stabile Ressource-/ThingDef-ID,
- aggregierte Menge,
- Map-/Storage-Ort,
- Qualitäts-/Verderbsklasse, soweit relevant,
- Timestamp,
- Availability (`Available`, `Blocked`, `Unavailable`, `Frozen`).

Credits bleiben davon getrennt und dürfen nicht als physische Lagerware ausgegeben werden.

**Gate:** UI, Story Writer und spätere Economy lesen dieselbe Storage-Snapshotquelle; Kartenwechsel und Save/Load erzeugen keine abweichenden Bestände.

### Phase 4 — Character Setup und Bio-Remap

**Besitzer:** Survival & Progression.

**Startregeln:**

- biologisches und chronologisches Startalter immer **18**, sofern der lokale Generatorvertrag dies nach Spike bestätigt;
- Bio-Generator liefert Herkunft, Ton, Backstory und Auswahlkontext;
- Bio-Text darf nicht unkontrolliert zusätzliche Werte erzeugen;
- feste Gesamtzahl an Skillpunkten, die der Spieler vor Spielbeginn verteilt;
- neutrale Pufferzone ohne Trait-Strafe und ohne Trait-Bonus;
- Unterdeckung erzeugt definierte negative Traits;
- Überdeckung erzeugt definierte positive Traits;
- Trait-Grenzen, Ausschlüsse und DLC-Kompatibilität sind explizit.

**Empfohlenes Berechnungsmodell:**

```text
skillBudget = feste Startsumme
spentPoints = Summe der verteilten Punkte
balance = spentPoints - neutralCenter

balance < negativeThreshold → negative Trait-Kandidaten
negativeThreshold <= balance <= positiveThreshold → neutral
balance > positiveThreshold → positive Trait-Kandidaten
```

Der Neutralbereich muss breit genug sein, dass normale Spielerentscheidungen nicht sofort bestraft oder belohnt werden. Die konkrete Punktzahl und Schwellen werden erst nach einer Balance-Entscheidung festgeschrieben.

**Gate:** Drei identische Bio-/Skill-Eingaben erzeugen dieselben Skills, Trait-Kandidaten und Startalterwerte; keine zufällige nachträgliche Trait-Änderung außerhalb des dokumentierten Seeds.

### Phase 5 — Story-Ausführung und Vanilla-/DLC-Adapter

**Aufgaben:**

- entscheiden, ob der Setting-Director genügt oder ein direkter Vanilla-Storyteller benötigt wird;
- `StorytellerDef`, `StorytellerComp`, `IncidentDef`, `IncidentWorker` und Difficulty-Anker lokal per Reflection/Decompilation/Def-Load prüfen;
- Vanilla-Wealth-Raids, Quest- und DLC-Incidents separat klassifizieren;
- genau einen Infizierten-Provider im Full Profile aktivieren;
- keine globale Raiddeaktivierung ohne Kompatibilitätsmatrix;
- Auswahl, Ausführung, Letter, Spawn und Auflösung idempotent speichern.

**Gate:** Ein Druckanstieg erzeugt höchstens ein vorgesehenes Event, Vanilla-/Quest-/DLC-Ereignisse bleiben nach Policy korrekt, und der Ausführungsfall überlebt Save/Load ohne Doppelauflösung.

### Phase 6 — echte Gameplay-Schichten

Erst danach:

- Infizierten-Raids,
- Mechadroid-Aufträge,
- Outposts und Proxy-Graph,
- Wirtschaft und Wallet-Transaktionen,
- Bauschutt-Baukosten,
- Produktionsketten,
- World-Map- und Endgame-Systeme.

Jede Domäne bleibt standalone-fähig und erhält eigene Save-, Performance- und Falsifizierungs-Gates.

## 4. Globale Verträge

### Ownership

- Foundation: Registry, Diagnose, gemeinsame Read-Models, Capability-/Save-Metadaten.
- Story Writer/Threat: SettingProfile, StoryEventSpec, StoryState und Eventauswahl.
- Survival & Progression: Character Setup, Skill-/Trait-Regeln, Setting-Reaktionen für Pawns.
- Scavenger Infrastructure: physische ThingDefs, Lagerbestände, StorageSnapshot.
- Ideology-Adapter: technische Bindung der Setting-Regeln an native Ideology-Träger; keine eigene parallele Religionseinheit.
- Economy & Territory: Credits, Märkte, Outposts und Transport; liest physische Ressourcen, besitzt sie nicht doppelt.

### Determinismus

- expliziter Seed oder deterministische Auswahl-ID,
- stabile Sortierung der Kandidaten,
- keine Systemzeit als Spielinput,
- keine Hintergrundthreads für Spielzustand,
- Auswahlgrund und Eingangs-Snapshot speichern,
- Idempotency-Key pro Eventausführung.

### Save

Mindestens versionieren:

- `SettingProfileId` und Version,
- `StoryStateSchemaVersion`,
- letzte Auswahl-/Event-ID,
- Cooldowns,
- Auswahlseed,
- Ideology-Rule-Version,
- Character-Setup-Version,
- Storage-Snapshot-Timestamp beziehungsweise Rebuild-Markierung.

Fehlende oder inkompatible Zustände werden migriert, eingefroren mit Warnung oder kontrolliert abgelehnt. Niemals still löschen.

### Performance

- Story Writer arbeitet auf aggregierten Snapshots und definierten Intervallen.
- Storage wird nicht bei jedem UI-Frame und nicht mehrfach von jedem Paket gescannt.
- UI liest Snapshots und mutiert keine Simulation.
- Runtime-Gates müssen echte Ingame-/Save-/Load-Belege besitzen; Kompilierung allein reicht nicht.

## 5. Definition of Done für Full-Profile-Übergabe

- [x] Story Writer besitzt ein versioniertes Difficulty-/Event-/State-Modell (`SettingProfile`, `StoryEventSpec`, `StoryState` mit Schema-Version).
- [x] mindestens drei Eventfamilien mit Voraussetzungen, Auswahlgrund, Cooldown und Folgepfad beschrieben (`StoryEventCatalog` + `StoryEventSpec`).
- [x] deterministische Auswahl und genau-einmalige Ausführung durch 12 Unit-Tests nachgewiesen (`StorySelectorTests`).
- [x] Ideology-Regeln: 1 von 3 MVP-Regeln implementiert (ResourceFairness). Vollständige Matrix in H3 spezifiziert, restliche 2 Regeln (RoleHierarchy, RitualTrigger) in Phase 2.
- [ ] das Setting-Ideologie-Fenster erklärt Regeln und Charakterreaktionen ohne zusätzliche Religionssimulation.
- [x] Storage-only-Read-Model implementiert (`StorageSnapshot` + `StorageQuery` + `ReadStorage()`). Einzige Snapshotquelle für Paket 03; Integration in StoryDirector/UI/Economy in späteren Phasen.
- [~] Character Setup: kostenbewusste Skill-/Trait-Pure-Logik ist implementiert und deterministisch getestet; Startalter-Generator-Hook, Save-State und Runtime-Gate bleiben offen.
- [x] Skillbudget 30, NeutralCenter 25, Neutralzone [-5, +3] und Trait-Schwellen sind im H5-Vertrag und Code dokumentiert; Balance-Gate bleibt offen.
- [x] Vanilla-/Quest-/DLC-Incidents: `InfectedRaidWorker` rewritten — sendet Letter statt Spawn, deaktiviert keine Vanilla-Incidents. Vollständige Klassifikation in Phase 5.
- [ ] Save-Migration, Kartenwechsel, unloaded Maps und Game-Over-Fälle sind geprüft.
- [ ] alle relevanten Falsifizierungsberichte besitzen echte Belege und `SURVIVED`; fehlende Berichte gelten als Blocker.
- [x] alle fünf Pakete kompilieren; die betroffenen Pakete 01/04/05 kompilieren nach dem Falsifizierungsfix 0W/0E gegen lokale RimWorld 1.6.4566.
- [x] Erstmaliger Live-Test (Spielstart): alle Mods laden, Foundation erkennt FullOverhaul, Bootstraps erfolgreich.
- [ ] Runtime-Standalone-Fähigkeit: Save/Load, Event-Feuerung, Kartenwechsel noch nicht verifiziert.

## 6. Harte Stop-Gates

Arbeit stoppt vor der nächsten Phase, wenn:

- ein Dokument ein Scaffold als geliefert bezeichnet,
- eine API-Annahme nur durch `strings` begründet wird,
- der Story Writer mehr als eine Eventausführung für denselben Idempotency-Key erzeugt,
- Story-/Ideology-State nach Save/Load driftet,
- Lagerbestand und UI-/Economy-Snapshot voneinander abweichen,
- Charaktere ohne explizite Regel außerhalb der Trait-Pufferzone landen,
- ein Mechadroid oder abstrakter Outpost ein Game Over verhindert,
- ein fehlendes DLC/Paket Phantomdaten erzeugt.

## 7. Infrastruktur & Werkzeuge

| Werkzeug | Pfad | Beschreibung |
|---|---|---|
| Version-Bump | `scripts/bump_version.sh` | Bumpt `VERSION`-Datei eines Pakets um +0.0.1 |
| Deploy | `scripts/deploy.sh` | Baut + deployt Pakete per `rsync --delete` in RimWorld Mods |
| Gesamt-Plan | `docs/PLAN_GESAMTAUFGABEN.md` | Kanonische Aufgabenliste für alle Phasen |

**Aktuelle Paket-Versionen (Stand 2026-08-04):**

| Paket | Version |
|---|---|
| 01-Rimconemy-Foundation | 0.1.36 |
| 02-Rimconemy-Survival-Progression | 0.1.30 |
| 03-Rimconemy-Scavenger-Infrastructure | 0.0.23 |
| 04-Rimconemy-Economy-Territory | 0.0.25 |
| 05-Rimconemy-Infected-Automation | 0.0.32 |
