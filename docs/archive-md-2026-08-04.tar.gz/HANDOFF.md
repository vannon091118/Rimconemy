# HANDOFF — Nächste Schritte (TODO)

> **Erstellt:** 2026-08-04 (nach Coding-Cut §1)
> **Letztes Update:** 2026-08-04 (nach Falsifizierungsfix für Ledger, StoryState und EventLog)
> **Modus:** Aktive TODO-Liste — nach Bearbeitung in `docs/handoff-YYYY-MM-DD-*.md` archivieren und neues HANDOFF schreiben.
> **Vorgänger:** `docs/tasks.md` (H1–H5), `docs/handoff-2026-08-04-story-models.md` (Coding-Cut §1), `docs/handoff-2026-08-04-sprint-2.md` (Sprint 2)

## Vorgabe

Dieses Dokument wird als **TODO-Liste** genutzt. Nach Abschluss eines Sprints:
1. Sprint-Ergebnis in `docs/handoff-YYYY-MM-DD-beschreibung.md` archivieren
2. Dieses HANDOFF mit verbleibenden TODOs aktualisieren
3. Alle betroffenen Docs (AUDIT, ROADMAP, tasks.md, VORGEHEN) auf neuen Stand bringen

## Versionierung

Jedes Paket besitzt eine eigene `VERSION`-Datei im Wurzelverzeichnis des Pakets (z. B. `mods/05-Rimconemy-Infected-Automation/VERSION`).

**Regel:** Nach JEDER Code-, Def- oder XML-Änderung an einem Paket wird dessen `VERSION` um `+0.0.1` gepumpt — individuell pro Paket. Kein globaler Monolith-Version-Bump.

**Script:**
```bash
# Einzelnes Paket:
./scripts/bump_version.sh 05

# Alle 5 Pakete:
./scripts/bump_version.sh --all
```

**Aktuelle Versionen (Stand 2026-08-04):**

| Paket | Version |
|---|---|
| 01-Rimconemy-Foundation | 0.1.36 |
| 02-Rimconemy-Survival-Progression | 0.1.30 |
| 03-Rimconemy-Scavenger-Infrastructure | 0.0.23 |
| 04-Rimconemy-Economy-Territory | 0.0.25 |
| 05-Rimconemy-Infected-Automation | 0.0.32 |

---

---

## Deployment (Live-Test in RimWorld)

Wenn ein Paket für Live-Tests bereit ist, wird es per `deploy.sh` gebaut und direkt in den RimWorld-Mods-Ordner kopiert. **Bestehende Dateien werden automatisch überschrieben.**

**Script:**
```bash
# Alle 5 Pakete bauen + deployen:
./scripts/deploy.sh

# Nur Paket 05:
./scripts/deploy.sh 05

# Nur kopieren (ohne Build):
./scripts/deploy.sh --no-build
```

**Zielverzeichnis:** `/home/vannon/GOG Games/RimWorld/game/Mods/`

**Deploy-Ablauf:**
1. `dotnet build` mit Release-Konfiguration
2. `rsync --delete` kopiert alles **außer** `Source/`, `obj/`, `.build*/`, `*.csproj`, `Tests/`, `.gitkeep`
3. Alte DLLs/Defs/Texturen werden überschrieben, gelöschte Dateien werden entfernt

**Ausschlüsse vom Deploy:** `Source/` `obj/` `.build/` `.buildV2/` `.buildV3/` `*.csproj` `Tests/` `.gitkeep` `mods/`

## Aktueller Sprint — Character Setup Hybrid (2026-08-04)

> Teilabnahme dokumentiert in `docs/handoff-2026-08-04-character-setup.md`.
>
> Implementiert: kostenbewusste Default-Allocation für UI und Runtime, atomare Ablehnung überbudgetierter Allocations, deterministische Pure-Trait-Auswahl mit explizitem Seed, H5-Grenz- und Reproduzierbarkeitstests. Paket 02 steht aktuell auf Version `0.1.30`; die Need-Def-Instanziierungsregression ist in `Need_SettingIdentity` und dem NeedDef-Vertragstest abgesichert.
>
> Offen: `API-START-01` (konkreter PawnGenerator-/PawnGenerationRequest-Beleg), CharacterSetupState/Scribe-Schema, persistenter Runtime-Seed, Bio-Remap- und Save/Load-Live-Test. Der bestehende `FixAge`-Pfad bleibt ein dokumentierter Workaround und ist kein Generator-API-Beleg.

## Aktive TODOs (aus tasks.md §6)

### ✅ §1 — Pure Datenmodelle und Auswahlfunktion

> Erledigt. Siehe `docs/handoff-2026-08-04-story-models.md`.

### ✅ §2 — Save-/Schema-Modell mit Scribe-Anbindung

> Erledigt. `StoryState` implementiert `IExposable` + `ExposeData()` mit parallelen Listen für Dictionary/HashSet und persistierten Insertions-Ticks. Alters-Pruning behandelt unbekanntes Legacy-Alter konservativ; Regressionstests decken Save/Load-Semantik und Count-Cap ab. Build: 0W/0E.
> Code: `mods/05/.../Source/Story/StoryState.cs`.

---

### ✅ §3 — Drei Event-Defs als XML

> Erledigt. 3 `StoryEventDef`-XMLs existieren in `Defs/StoryEvents/`:
> SupplyShortage, IdeologyConflict, ExternalThreat + TEMPLATE + README.
> Deklarative Specs gemäß H2 §2. `StoryEventDef` C#-Klasse folgt in §7.

---

### ✅ §4 — Read-only StorageSnapshot-Adapter

> Erledigt. 3 Dateien in `mods/03/.../Source/Storage/`:
> `StorageSnapshot.cs` (Datenmodell + Entry + Quality/Rot-Aggregation),
> `StorageScope.cs` (Enum + ResourceFilter), `StorageQuery.cs` (ReadStorage + Cache + Hash).
> `Map.listerThings.AllThings` kompiliert gegen lokale 1.6-Assembly ✅.
> Build: 0W/0E.

---

### ✅ §5 — Ideology-Adapter für eine Regel

> Erledigt. `ThoughtWorker_ResourceFairness.cs` in Paket 02 (`Source/Ideology/`),
> 2 ThoughtDef-XMLs (`FairDistribution` + `UnfairDistribution`) in `Defs/ThoughtDefs/`.
> Tägliche Fairness-Prüfung via Pawn-Inventar (Food/Medicine). Build: 0W/0E.
> `IdeoDef`-DLC-Spike weiterhin offen (PreceptDef folgt in Phase 2).

---

### ✅ §6 — Test-/Diagnostics-Ausgabe

> Erledigt. `StorySelectorTests.cs` in `mods/05/.../Tests/` mit 12 Test-Methoden:
> Determinismus ×3 (Refuge/Survival/Collapse), Idempotenz ×2, Profile ×2, RNG ×2,
> Diagnostics ×1, Edge-Cases ×2. `RunAll()` via Bootstrap aufrufbar. Build: 0W/0E.

---

### ✅ §7 — Incident-/Storyteller-Ausführung

> **Stand 2026-08-04 (Audit-Korrektur).** Erstmals implementiert via
> Coding-Cut §7; Vertikalschnitt war unvollständig: niemand füllte
> `Find.Storyteller.incidentQueue`, der Letter wurde nicht angezeigt,
> weil `Rimconemy_InfectedRaidIncident` `<baseChance>0.0</baseChance>`
> hat und niemand die Def erzwingt. Korrektur:
>
> - `StoryDirector.GameComponentTick` setzt nach Stage der
>   Pending-Felder explizit `Find.Storyteller.incidentQueue.Add(...)`
>   mit minimalen `IncidentParms { target = AnyPlayerHomeMap, points = 50f }`.
>   (`Source/Story/StoryDirector.cs` -- `QueueSelectedIncident`).
> - `InfectedRaidWorker` bleibt unverändert: `CanFireNowSub` ueber
>   `HasPendingIncident(defName)`, `TryExecuteWorker` ruft
>   `Find.LetterStack.ReceiveLetter(...)`.
> - `Defs/Incidents/InfectedRaid.xml` ist geladen,
>   `<baseChance>0.0</baseChance>` bleibt gesetzt (keine Vanilla-Spontanauslösung).
> Reconstruction-Pfad: Phase 2 ersetzt Letter-Stage durch Raid-Spawn ueber
> den gleichen Queue-Pfad.
>
> Code: `mods/05/.../Source/Story/StoryDirector.cs`,
> `mods/05/.../Source/Incidents/InfectedRaidWorker.cs`,
> `mods/05/.../Defs/Incidents/InfectedRaid.xml`.

### ✅ §7-Seed-Formel (Audit-Korrektur)

> `DeterministicRng.BuildSeed` löst jetzt `{MapID}` (aus `map.uniqueID`)
> sowie `{PawnId}` (aus `snapshot.DeterministicTargetPawnId`, durch
> `StoryDirector.BuildLiveSnapshot` deterministisch gefüllt) auf statt
> `{PawnId}` als leeren String. `StorySelector` benutzt
> `"{ProfileId}+{MapID}+{GameTickDay}"` als globalen Seed wie in H2 §1
> spezifiziert. Per-Event-Templates bleiben unverändert.
> Code: `Source/Story/StorySelector.cs` Step 4,
> `Source/Story/DeterministicRng.cs` BuildSeed.

### ✅ §7-Skeleton-Säuberung (Audit-Korrektur)

> Drei strukturelle Konsolidierungen, alle Module kompilieren weiter
> mit 0W/0E:
>
> 1. **ServiceBus gelöscht.** `FoundationServiceBus.cs` ist entfernt;
>    `FoundationDashboard.cs`/`Bootstrap.cs`/`PackageRegistry.cs`
>    bereinigt. `INTERFACE_CONTRACT.md` §1 markiert das Schema als
>    Phase-3-Plan (kein Konsument bisher); Capability
>    `rimconemy.foundation.servicebus` aus §2 entfernt. Code lebt zur
>    Zeit nur ueber `PackageRegistry.IsRegistered` /
>    `HasCapability`-Prüfungen.
> 2. **Storyteller-/Story-Event-XMLs als inert markiert.**
>    `Defs/Storyteller/Rimconemy_Storyteller.xml` und
>    `Defs/StoryEvents/Rimconemy_*.xml` tragen einen INERT-Kommentar:
>    die StoryDirector-Auswahl greift auf den hartkodierten
>    `StoryEventCatalog` (12 Events) zurück, XML ist reiner Spec-Anker.
>    Reconciliation-Pfad ist Phase 3.
> 3. **Family-Cross-Walk.** `Source/Story/EventFamilyMap.cs` führt das
>    4-Familien-Vokabular des Codes (`Supply`/`Social`/`Raid`/`Collapse`)
>    und das 8-Familien-Vokabular der H2-Spec zusammen
>    (`CodeToH2`, `CodeToH2All`, `H2ToCode`).

---

## ✅ Abgeschlossene Bugfixes (GESAMTREPORT F1–E3)

| ID | Fix | Datei |
|---|---|---|
| F1 | Tick-Kommentar: 30.000 = 0,5 Tage (nicht 3) | `TerritoryNode.cs` |
| B1 | Erfolgs-Lüge: `TryExecuteWorker→false` + `Log.Warning` | `InfectedRaidWorker.cs` (rewritten) |
| F6 | GameOver: `PawnsFinder.AllMapsCaravansAndTravellingTransportPods` | `GameOverDetector.cs` |
| F2 | Tick-XP dokumentiert, `ClassifyJob` Def-basiert | `ProgressionGameComponent.cs` |
| C2 | Thread-Maschinerie dokumentiert (kein Runtime-Eingriff) | `FoundationServiceBus.cs` |
| C3 | Base64→Scribe-Notation | `FoundationSaveData.cs` |
| C4 | `catch(NullReferenceException)`→spezifische Exceptions | `EventLog.cs` |
| E2 | `_invbuild/` gelöscht | `rm -rf mods/_invbuild` |
| E3 | `.gitignore` für `obj/`-Ordner | `.gitignore` |

---

## Quick-Reference: Wichtige Pfade

| Was | Wo |
|---|---|
| Root-TODO (dieses Dokument) | `HANDOFF.md` |
| Gesamt-Aufgabenliste | `docs/PLAN_GESAMTAUFGABEN.md` |
| Sprint-Archiv (Coding-Cut §1) | `docs/handoff-2026-08-04-story-models.md` |
| Tasks-Übersicht | `docs/tasks.md` |
| Root-Audit | `AUDIT.md` |
| Root-Roadmap | `ROADMAP.md` |
| Vorgehen-Doku | `docs/VORGEHEN-H1-H5.md` |
| Story-Modelle (Code) | `mods/05-Rimconemy-Infected-Automation/Source/Story/` |
| H2 Spezifikation | `docs/H2-story-contract.md` |
| H3 Ideology-Matrix | `docs/H3-ideology-influence-matrix.md` |
| H4 Storage-Vertrag | `docs/H4-storage-query-contract.md` |
| H5 Character-Formel | `docs/H5-character-setup-formula.md` |
| Version-Bump-Script | `scripts/bump_version.sh` |
| Deploy-Script | `scripts/deploy.sh` |
| Build (Paket 05) | `cd mods/05-... && dotnet build -p:RimWorldManagedPath=... -p:HarmonyAssembliesPath=...` |
