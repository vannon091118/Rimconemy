# Rimconemy — Root Audit

> **Stand:** 2026-08-04 (Update nach Live-Test + Bugfixes)  
> **Basis:** aktueller Checkout, RimWorld 1.6.4566 als lokale Zielinstallation, vorhandene Paket-Roadmaps/Blueprints und `docs/GESAMTREPORT_2026-08-04.md`  
> **Methodik:** 4-Quadrate (USER×UX, USER×TECHNICAL, CODER×UX, CODER×TECHNICAL) plus Truth-Pass gegen den aktuellen Quellbaum  
> **Fokus:** Story Writer mit Schwierigkeitsprofilen und Event-Katalog, settingersetzende Ideologie als Verhaltensadapter, spätere Charakter-/Skill-/Trait-Generierung und Lager-basiertes Ressourcenmodell  
> **Ausschlüsse:** kein Save-/Load-Lauf, keine UI-Abnahme  
> **H1–H5 Status:** Alle 5 Research-/Design-Dokumente abgeschlossen. Siehe [`docs/tasks.md`](docs/tasks.md) und `docs/H1-*.md` bis `docs/H5-*.md`.  
> **Coding-Schnitte:** Sprint 1 (§1 Datenmodelle + Auswahlfunktion) + Sprint 2 (§2–§7 Save/Defs/Adapter/Tests/Incident-Ausführung) abgeschlossen. Build alle 0W/0E. Siehe [`docs/handoff-2026-08-04-story-models.md`](docs/handoff-2026-08-04-story-models.md) und [`docs/handoff-2026-08-04-sprint-2.md`](docs/handoff-2026-08-04-sprint-2.md).  
> **Bugfixes:** 9 GESAMTREPORT-Findings + 3 Runtime-Bugs nach Live-Test behoben (XML-Format 18×, Version-Mismatch, Idempotenz 2×). Build alle Pakete 0W/0E.  
> **Live-Test (2026-08-04):** Erstmaliger Spielstart — alle 5 Mods laden, Foundation FullOverhaul erkannt, Bootstrap-Kette komplett, StoryDirector initialisiert.

## Beweisgrenze

Dieser Audit trennt konsequent zwischen **lokal bewiesen**, **statischem Befund**, **Anforderung** und **Hypothese**.

- Vor dem Anlegen dieser Root-Dokumente betrug die Dateizählung **43 Markdown-, 46 C#- und 28 XML-Dateien** unter `mods/` und `docs/`. Nach allen Sprints (H1–H5, §1–§7, Bugfixes, Live-Test-Fixes, Scripts) sind es **58+ Markdown-, 60+ C#- und 35+ XML-Dateien** plus 3 Shell-Scripts.
- Alle fünf `.csproj` wurden in der aktuellen Prüfung erfolgreich kompiliert: jeweils Exit 0, 0 Warnungen, 0 Fehler. Das beweist Kompilierbarkeit gegen die lokale Referenz, nicht Def-Loading, Spielstart oder Runtime-Semantik.
- Die lokale Installation enthält RimWorld 1.6.4566. Assembly-String-Treffer sind nur Namensbelege; sie beweisen keine Signatur, Zugänglichkeit, Vererbungskompatibilität oder Laufzeitwirkung.
- Die Root-Dokumente `ROADMAP.md`, `docs/tasks.md` (vormals `HANDOFF.md`) und `AUDIT.md` wurden in diesem Auftrag neu angelegt und schließen den Audit-/Roadmap-/Handoff-Pfad auf Root-Ebene. Die Research-/Design-Schritte H1–H5 sind in `docs/H1-api-def-gate.md` bis `docs/H5-character-setup-formula.md` dokumentiert.
- Die in Paketdokumenten referenzierten Meta-Dokumente (`PRODUCT_VISION.md`, `INTERFACE_CONTRACT.md`, `SAVE_CONTRACT.md`, `COMPATIBILITY_MATRIX.md`, `HANDOFF_QUEUE.md`, `SPIKE_INDEX.md` und weitere) sind im aktuellen Checkout nicht vorhanden.
- In dieser Session erstellt/gefixt: H1-H5 Research-Dokumente (5), Story-Modelle §1 (7 C#), §2 Scribe-Anbindung, §3 3 XML-Defs (bereits vorhanden), §4 Storage-Adapter (3 C#), §5 Ideology-Adapter (1 C# + 2 XML), §6 Tests (1 C#), §7 StoryDirector (1 C#), InfectedRaidWorker-Rewrite, 9 GESAMTREPORT-Bugfixes (4 C#, 1 Env, 4 Docs), .gitignore, 2 Sprint-Archive, 3 Runtime-Bugfixes nach Live-Test, Version-Bump-Script, Deploy-Script, PLANGESAMTAUFGABEN.md. Alle 5 Pakete kompilieren 0W/0E. Erstmaliger Live-Test (Spielstart) bestanden.

## Executive Summary — Top-Risiken vor der nächsten Phase

| # | Risiko | Severity | LOC-Impact | Phase-Blocker |
|---|---|---:|---:|---:|
| 1 | Story Writer: Datenmodelle, Auswahlfunktion, Scribe-Save, Event-Defs, Storage-Adapter, Ideology-Adapter, Unit-Tests, Incident-Ausfuehrung (StoryDirector) und Idempotenz-Fix implementiert (§1–§7 ✅). Live-Test (Spielstart) bestanden. Build 0W/0E. | low | — | no |
| 2 | Die bestehende Dokumentation widerspricht der neuen Priorität: Paket 02 hält Vanilla-Storyteller als Standalone-Autorität fest, während das neue Setting einen eigenen Story-/Ideologie-Director verlangt. | crit | Dokumente + Verträge | yes |
| 3 | Ideologie ist bislang nur als API-/DLC-Anker geplant. Es gibt keinen entschiedenen Ownership-Vertrag für Precepts, Roles, Rituals, Thoughts und AI-/Mood-Effekte. | high | mittel | yes |
| 4 | Ressourcen-Tracking ist nicht als einheitlicher Lager-Read-Model-Vertrag eingefroren. Eine zweite abstrakte Survivor-Inventarliste würde Bestandsdrift erzeugen. | high | mittel | yes |
| 5 | Charakter-Bio, Startalter 18, feste Skillpunkte und Trait-Ausgleich sind nicht implementiert; die vorhandene Scenario-Def erlaubt nur einen Pawn und acht Auswahlkandidaten. | high | mittel | yes |
| 6 | Mehrere Dokumente behaupten geplante Features als geliefert; Falsifizierungsberichte und die meisten kanonischen Referenzdateien fehlen. | high | Dokumente | yes |

## Aktueller Code-/Dokumentbefund

### Bestätigte Scaffold-Anker

- `mods/05-Rimconemy-Infected-Automation/Source/Incidents/InfectedRaidWorker.cs` wurde im Sprint 2 (§7) neu implementiert: `CanFireNowSub` prüft `StoryDirector.HasPendingEvent()`, `TryExecuteWorker` sendet echten `Find.LetterStack`-Letter mit Event-Daten. Build 0W/0E.
- `mods/05-Rimconemy-Infected-Automation/Source/Story/StoryEventDef.cs` — `weights`/`cooldownDays` nach Live-Test von `Dictionary<string,float>` auf `List<string>` umgestellt (RimWorld-XML-kompatibel).
- `mods/05-Rimconemy-Infected-Automation/Source/Story/StorySelector.cs` — Idempotenz-Fix: Cooldown aus Kandidaten-Filter entfernt, stattdessen nach Idempotenz-Prüfung angewendet.
- `mods/01-Rimconemy-Foundation/Source/Registry/PackageRegistry.cs` — Versionen auf VERSION-Stand gebracht (Foundation 0.1.4, Survival 0.1.1, Scavenger 0.0.1, Economy 0.0.1, Infected 0.0.2).
- `scripts/bump_version.sh` — Bumpt VERSION-Datei eines Pakets um +0.0.1.
- `scripts/deploy.sh` — Baut + deployt Pakete per `rsync --delete` in RimWorld Mods.
- `docs/PLAN_GESAMTAUFGABEN.md` — Kanonische Aufgabenliste für alle Blöcke A–F.
- `mods/05-Rimconemy-Infected-Automation/Defs/Incidents/InfectedRaid.xml:13-23` definiert den Incident mit `baseChance` `0.0`.
- `mods/05-Rimconemy-Infected-Automation/BLUEPRINT.md` beschreibt Storyteller/Incident als Planungsanker und lässt die Runtime-Validierung offen.
- `mods/02-Rimconemy-Survival-Progression/Source/Progression/ProgressionGameComponent.cs:16-18,161-190` — Tick-XP dokumentiert (F2-Fix): Kommentar erklärt Warum-Tick-Sampling, `ClassifyJob` auf Def-basierte Prüfung umgestellt (kein Substring). Build 0W/0E.
- `mods/02-Rimconemy-Survival-Progression/Defs/Scenarios/SingleSurvivor.xml:11-41` definiert einen Single-Survivor-Scenario-Scaffold mit `pawnCount=1` und `pawnChoiceCount=8`; die Beschreibung nennt ausdrücklich den Vanilla-Storyteller.
- `mods/02-Rimconemy-Survival-Progression/Source/Scenarios/SingleSurvivorScenario.cs:7-21` loggt „Vanilla storyteller authority retained“.
- `mods/02-Rimconemy-Survival-Progression/Tests/Spikes/API-NEED-01.md` markiert Needs/Mood/Ideology-Einflüsse als `UNVERIFIED` und verbietet, nicht bestätigte Signaturen direkt in `Source/` zu übernehmen.
- `mods/01-Rimconemy-Foundation/Source/Catalog/FoundationDefInventory.cs:149-157` zählt bereits `IncidentDef`, `TraitDef`, `ThoughtDef` und `NeedDef`; das ist ein möglicher read-only Diagnoseanker, keine Ideologie-Implementierung.
- `mods/04-Rimconemy-Economy-Territory/Source/Wallet/CreditsLedger.cs`, `MarketStub.cs`, `OutpostStub.cs` und `TerritoryNode.cs` sind Daten-/Stubpfade. `TerritoryNode.cs` Tick-Kommentar gefixt (F1: 30.000 Ticks = 0,5 Tage, nicht 3 Tage). Sie bilden keinen belastbaren Storage- oder Survivor-Ressourcenvertrag.

## TEIL A: Q1 — USER × UX (Spieler-Erleben)

| ID | Befund | Evidenz | Severity | Phase-Blocker |
|---|---|---|---:|---:|
| Q1-01 | Story-Writer-Vertikalschnitt implementiert: `StoryDirector` (GameComponent) → `StorySelector` → `StoryState` (Scribe) → `InfectedRaidWorker` (Letter). Profil, Lage, Event, Cooldown und Folgeentscheidung als Code vorhanden. Live-Test (Spielstart) erfolgreich. Save/Load-Verifikation noch offen. | `mods/05/.../Source/Story/StoryDirector.cs`, `StorySelector.cs`, `StoryState.cs`; `InfectedRaidWorker.cs`. Build 0W/0E. | medium | no |
| Q1-02 | „Schwierigkeit“ ist nicht als erklärbares Profil definiert. Ein Spieler könnte nur Zahlenmultiplikatoren sehen, aber nicht verstehen, welche Ruhe-, Eskalations- oder Ideologie-Regeln gelten. | Neue Anforderung; bestehende Roadmaps nennen Storyteller-/Raidstärke, aber kein zentrales Profilmodell. | high | yes |
| Q1-03 | Das Ideologie-/Glaubensfenster besitzt noch keine entschiedene Funktion im Setting. | `API-NEED-01` klassifiziert Ideology als Einflussquelle; keine eigene Ideology-UI-/Setting-Schicht vorhanden. | high | yes |
| Q1-04 | Bio- und Skill-Entscheidungen sind nicht als Spieleraktion modelliert. | Scenario erlaubt einen Pawn und acht Kandidaten, aber keine feste Skillpunkt-Budgetierung oder Trait-Ausgleichs-UI. | high | yes |
| Q1-05 | Lagerbestand und Survivor-Ressourcen können für den Spieler unterschiedliche Wahrheiten darstellen, wenn ein abstraktes Ledger parallel zum Storage geführt wird. | Neue Anforderung; bestehende Economy-Stubs besitzen Wallet-/Marktbegriffe, aber keinen Storage-Read-Model-Vertrag. | high | yes |

### UX-Zielbild

Der Spieler soll in dieser Reihenfolge verstehen können:

```text
Setting-Profil → aktuelle Lage → verfügbares Event → Konsequenz
→ Ideologie-Reaktion → Charakter-/Lagerauswirkung
```

Das Ideology-Fenster wird als **Setting-/Erfahrungsfenster** verwendet. Es muss keine Religion simulieren. Es zeigt Regeln, Rollen, Gemeinschaftsreaktionen und die daraus entstehenden Verhaltensfolgen. Begriffe und Texte müssen klarstellen, dass es sich um ein Setting-System handelt, nicht um eine zusätzliche religiöse Metaebene.

## TEIL B: Q2 — USER × TECHNICAL (Spieler unter Last)

| ID | Befund | Evidenz | Severity | Phase-Blocker |
|---|---|---|---:|---:|
| Q2-01 | Story-Entscheidungen könnten bei zu häufigem Polling Event-Spam und UI-Flut erzeugen. | Der aktuelle `ProgressionGameComponent` arbeitet bereits intervallbasiert; ein Story-Director existiert noch nicht. | high | yes |
| Q2-02 | Ein globaler Story-/Ideologie-Director könnte aktive Map, World-Map und unloaded Zustände mehrfach auswerten. | Architekturhypothese; kein Lastlauf vorhanden. | high | yes |
| Q2-03 | Lager-Scanning über alle Maps, Lagerbereiche und Itemstacks kann bei jedem Story-Schritt teuer werden. | Architekturhypothese; die Anforderung verlangt Storage-only-Tracking. | high | yes |
| Q2-04 | Save-/Load-Verhalten von Event-Cooldowns und Idempotenz: `StoryState` implementiert `IExposable` + `ExposeData()` mit allen 13 Feldern. Idempotenz-Fix: Cooldown nach Idempotenz geprueft (nicht in Kandidaten-Filter). Ideology/Trait/Skill-Save noch offen. | `mods/05/.../Source/Story/StoryState.cs`; Build 0W/0E. | medium | yes |
| Q2-05 | Der aktuelle Game-Over-Pfad verwendet `FreeColonistsSpawned` auf Maps und wartet vier 250-Tick-Intervalle; Karawanen-/Transporter-Semantik ist nicht runtime-verifiziert. | `ProgressionGameComponent.cs:98-131`, `GameOverDetector.cs:24-28`; lokaler Assembly-String belegt höchstens einen möglichen Helpernamen. | crit | yes |

### Last-/Recovery-Gates

Der Story Writer darf nur auf **aggregierte Snapshots** zugreifen. Er darf nicht pro Pawn und nicht pro Itemstack eigene dauerhafte Tick-Schleifen erzeugen. Jeder Evententscheid benötigt:

- einen Spielzeit-Timestamp,
- eine deterministische Auswahl-ID oder einen Seed,
- einen Cooldown-/Idempotency-Key,
- einen Save-/Load-Zustand,
- eine sichtbare Ursache und ein Ergebnis.

## TEIL C: Q3 — CODER × UX (UI-Code-Pfad)

| ID | Befund | Evidenz | Severity | Phase-Blocker |
|---|---|---|---:|---:|
| Q3-01 | Story- und Ideologie-UI-Verträge fehlen. | Vorhandene Foundation-UI ist Diagnose-/Snapshot-orientiert; kein Story-/Ideology-Read-Model gefunden. | high | yes |
| Q3-02 | Paket-Roadmaps besitzen widersprüchliche Autorität: Paket 02 behält Vanilla-Storyteller, Paket 05 plant einen eigenen Storyteller. | `mods/02.../ROADMAP.md` Abschnitt 8; `mods/05.../ROADMAP.md` Abschnitte 1, 3 und 6.3. | crit | yes |
| Q3-03 | Ein eigener Storyteller würde als direkte 1.6-API-Lösung überbewertet, weil die vorhandenen Spikes nur Planungsanker und keine Signatur-/Runtime-Belege sind. | `API-INCIDENT-01.md` und `BLUEPRINT.md` markieren den Pfad als `UNVERIFIED`. | high | yes |
| Q3-04 | Charaktergenerator, Bio-Remap und Trait-Ausgleich haben keine getrennten Read-/Write-Grenzen. | Keine `Source/Start/`, `Source/Character/` oder entsprechende Defs im aktuellen Paket-02-Baum. | high | yes |

### Empfohlene UI-Grenze

```text
Lage-/Setting-State
   ↓
StorySnapshot + IdeologySnapshot + CharacterSetupSnapshot
   ↓
Dashboard / Story-Fenster / Ideology-Fenster / Startkonfiguration
```

Die UI liest Snapshots. Sie berechnet weder Eventgewicht, Trait-Ausgleich noch Lagerbestand selbst.

## TEIL D: Q4 — CODER × TECHNICAL (System-Stabilität)

| ID | Befund | Evidenz | Severity | Phase-Blocker |
|---|---|---|---:|---:|
| Q4-01 | Story Writer besitzt kanonische IDs (SettingProfile, StoryEventSpec, StoryState mit Schema-Version). Ideologie und Character Setup noch offen. | `mods/05/.../Source/Story/` (7+2 Dateien), Build 0W/0E. | medium | yes |
| Q4-02 | Die geplante Ideologie-Ownership ist offen: Vanilla-Systeme sollen genutzt werden, aber kein direkter Remapping-Vertrag entscheidet, was ersetzt und was nur adaptiert wird. | `API-NEED-01` nennt Einflussklassifikation; Paket-Roadmaps behandeln Ideology als Kompatibilitätsbereich. | crit | yes |
| Q4-03 | Storage-only-Ressourcen sind nicht als Single Source of Truth festgelegt. | Economy besitzt Credits-/Markt-Stubs; Scavenger besitzt Ressourcendefs; kein gemeinsamer Storage-Query-Vertrag. | crit | yes |
| Q4-04 | Skillpunkt- und Trait-Schwellen können Charaktere durch unbounded oder nicht reproduzierbare Bio-Logik verzerren. | Neue Anforderung; keine Berechnung oder Testmatrix vorhanden. | high | yes |
| Q4-05 | Referenzkette und Falsifizierungs-Gates sind strukturell gebrochen. | Root-Meta-Dokumente und `FALSIFICATION_REPORTS` fehlen; Blueprints referenzieren sie dennoch. | high | yes |

### Nicht zulässige Annahmen

- Assembly-Strings sind kein Beweis für `StorytellerComp`-, `IdeoDef`-, `PawnGenerator`- oder `PawnFinder`-Signaturen.
- Ein `WorldObjectComp`-Name ist kein fertiger Outpost-Mechanismus.
- Ein Ideology-Def ist kein Beweis, dass ein Precept das gewünschte KI-Verhalten beeinflusst.
- Ein sichtbares Lager-UI ist kein Beweis für atomisches oder savebares Ressourcen-Tracking.
- Ein Bio-Text ist kein Beweis für eine reproduzierbare Skill-/Trait-Verteilung.

## TEIL E: Risiko-Heatmap & empfohlene Reihenfolge

| Rang | Risiko/Entscheidung | Severity | Phase-Blocker | Nächster Beleg |
|---:|---|---:|---:|---|
| 1 | Story-Writer-Ownership und Difficulty-/Event-Vertrag | crit | yes | Root-Roadmap + Story-Spike |
| 2 | Ideology-Remap als Setting-/Verhaltensadapter | crit | yes | lokaler Def-/Reflection-Spike + Einflussmatrix |
| 3 | Storage-only-Read-Model | crit | yes | Storage-Query-Spike + Karten-/Save-Fälle |
| 4 | Character Setup: Bio → feste Skillpunkte → Traits | high | yes | Pawn-Generator-/Start-Spike + pure Berechnungstests |
| 5 | Story-/Ideology-Save- und Determinismusvertrag | high | yes | Save-/Seed-Test |
| 6 | erster dynamischer Event-Vertikalschnitt | high | no | 3 Event-Defs + ein ausführbarer Adapter |
| 7 | direkte Vanilla-Storyteller-Integration | high | no | erst nach erfolgreichem API- und Runtime-Spike |
| 8 | Story-Ausbau, Mechadroids, Hauptstädte und Endgame | medium | no | nach MVP-Gates |

### Schärfste Entscheidung

Wenn nur **eine** Sache zuerst entschieden und gebaut werden darf, dann der **Story-Writer-Vertrag mit einem einzigen dynamischen Lage-Snapshot**. Ohne ihn bleiben Difficulty, Eventliste und Ideology-Reaktionen Textlisten; mit ihm entsteht ein testbarer Kern, an den Charaktere und Lagerbestände angeschlossen werden können.

## Statuswortschatz

Alle drei Root-Dokumente verwenden diese Begriffe verbindlich:

- `PLANNED`: beschlossen, aber noch nicht implementiert;
- `SCAFFOLD`: Code-/Def-Gerüst vorhanden, Verhalten nicht geliefert;
- `UNVERIFIED`: statischer Anker oder Behauptung vorhanden, aber kein ausreichender Def-/Runtime-Beleg;
- `IMPLEMENTED`: Code und Defs vorhanden, aber Runtime-Gate noch offen;
- `RUNTIME-VERIFIED`: Def-Load, Spielstart, Save-/Load- und relevanter Verhaltenstest belegt.

## Definition of Done für die nächste Phase

- [x] Root-Roadmap und Root-Tasks sind die kanonische Reihenfolge; H1–H5 Research/Design abgeschlossen.
- [ ] Fehlende Referenzdokumente (INTERFACE_CONTRACT, SAVE_CONTRACT, COMPATIBILITY_MATRIX) als `OPEN/MISSING` markiert oder angelegt.
- [x] `SettingProfile` mit stabiler ID, Version, Difficulty-Regeln und Eventfamilien.
- [x] `SituationSnapshot` mit Spielzeit, Survivor-/Threat-, Ideology- und Storage-Aggregaten.
- [x] `StoryEventSpec` mit ID, Voraussetzungen, Gewicht, Cooldown, Eskalationsstufe, Textschlüssel.
- [x] Eventauswahl als pure/deterministische Funktion (StorySelector + 12 Tests).
- [x] Idempotenz-Fix: Cooldown nach Idempotenz-Prüfung, nicht im Kandidaten-Filter.
- [x] Live-Test (Spielstart): alle 5 Mods laden, FullOverhaul erkannt.
- [ ] Ideology-Ownership entschieden: Setting-Profil besitzt Regeln; Ideology als Adapter.
- [x] Ideology-Adapter: 1 von 3 Regeln (ResourceFairness) implementiert.
- [ ] Survivor-Ressourcen ausschließlich über Storage-Snapshots; kein paralleles Ledger.
- [ ] Character Setup: Bio-Quelle, Startalter 18, Skillbudget, Trait-Grenzen.
- [ ] Save-Schema, Migration und Determinismusfälle dokumentiert.
- [ ] Storyteller-Entscheidung: Setting-Director oder direkter `StorytellerDef`-Adapter.
